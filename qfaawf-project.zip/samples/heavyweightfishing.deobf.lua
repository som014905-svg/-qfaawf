-- HeavyWeightFishing specialized static deobfuscation profile
-- Target: https://raw.githubusercontent.com/joustingmatch/Ouroboros/main/games/heavyweightfishing.lua
-- String table: 933 entries; recovered B(...) calls: 1288

--[[ v1.0.0 https://wearedevs.net/obfuscator ]]
return (function (...)
    local tbl1 = {"aJNqKqp6z1b=", "i51W";
      "mihW";
      "4oNbvz8p+Q1C+Eue4M==", "hyF04zrsvcp3uE6XGN==", "7gT5AvBE3NOHPzxke3==";
      "VFoYIJ85sNR=";
      "pUSSJM==", "X7zU";
      "9sWk89Bf4wUO5wo=", "qGRy0UTfFx6k660K", "UwwSLi5H5VD=";
      "L911ePSTN98zeyq3hoC=", "nDWinzBj4JBuePCsoy3=", "rN1bR6a=", "uJLevw8Y4D82vHez";
      "LwUkrwLXpDB14wLJ4wLCpN==", "nGWLNykVNsMzo78B4R==";
      "dVggRjOLGus7beONyVb=";
      "Yqq918p=", "9yOxXUbbwR==";
      "eyBXNPDzLoDbN71onN==", "t35tDAYP", "rLqznnB0B98tvy1a", "ByL7owYf/GLXr3==";
      "0OrJqLO4lD0ppR==";
      "+QDEF0LGYiHMv6T=";
      "Y76=";
      "936z";
      "LwWP8yY1";
      "1M==", "GPNyr7WfhEf2B9ueLN==", "UkogRS1slM==";
      "U9fXf4m8Z0ZIxGvoLMqbyX3IRzxo5RyBdqePLxVl76gs/3==", "bz1f7/vm11UbhWe=";
      "lqhpo0dzmV6=";
      "LySGvwLN+GsphsLB";
      "uwFC6ntP698DvDL0vQ6=";
      "jN==", "NBMhZUZBtGTUr5fv8jLJsVvunM==";
      "mf/xDwmdhN==";
      "/3==";
      "ASOZl3==", "wHKgdf0iJZTZidQx", "VXLnQN==";
      "BTTAjQJ+Ve3=";
      "c6W0kbaEItQYILWEmFyTtRJn";
      "uVDuKIvigi+a37lUsnImAgr=", "dfR8";
      "oETedflq6N==", "u3mDfS/h8I4gprUwVoKLFN==", "Ib++7cN5", "4/WtiN==";
      "jDv77JT6EUcL", "2CbdXuE7aeVg5Vu3QcLOzwFatZJ7bM==";
      "dLmPS9KG3MR=";
      "oHBArR==", "LULk5nt7/E4+o98woM==", "rh51";
      "un8kNoN7u78mrnqQo3==", "a4KNu5b=";
      "owYf/N==";
      "hyfd/cfvBz6=";
      "e11ku9LyhDeYLUDs5N==", "hGBY+n838o3Hr14k";
      "5Qp=", "+L4y5C8m5oUj8y19+N==", "h9ut";
      "/VDYdlxrKWj+c4Ob";
      "dcT+LFuJgL4T";
      "r+wV/3==", "kl1b";
      "VBiKBBq8wR==", "qEHPavtv/JRud3==";
      "UKhITNo=", "5D+Pal7=";
      "Bnq26HBYnHS7rLumLN==", "fkb77gWwRZgW";
      "N1/zgBvElMpEr8x3KRVu9VwUy9Mox887+j8OLhEcQhZIj7WkHXVCwKeNY2wxW8bMqObmfyp156oFo160HTiRyncDKhzuKzph7F6aaN==";
      "hFQAysb=", "GTqNKJnBO1C=", "4HDzGokAu94OBCfT/1p=", "rP8Yuwpzocobv1SC5N==", "gYUJT2u1zK4cfQb0phl8", "GCUFvQ4LrcfN4wDF4N==";
      "hGFz4wUdeyo=";
      "Sw3L0DdzX1K+IyT=";
      "+OkFzCnW", "8yL7vELS", "gpp84N==", "b5yyxKH3j4r=", "xEKN9N==";
      "spm3nSrT", "01XLCH+lHwKRlELPWWYm";
      "uHEM8hVWi0M=", "gAnZfEZoFQnP7sVm", "Jkc9ptA56GeRNAqVW3==", "9hJPIHa7f0M=";
      "o1LTL3==", "49BtB183Ns1LvCBwoEr=";
      "ykLflPMvHPa=", "x4Q+kHOOr93=";
      "wR==";
      "wKfou3==";
      "lYfGKWz4", "eNYVSluR";
      "NW+nEOUXxMoJXBS50uWl", "DfKWgDBdOoRqaMwTXRGv";
      "c2cuWJuI";
      "N7kfv9SYGDFevUfhrcr=", "oyLd8Dk1/oLy8GF7";
      "UUE1O6db/M==", "8y8H5HeynH1j6z1prN==", "WSYr", "IDygJN==", "cKQK";
      "iHheuipu/ZDg";
      "BGFs5N==";
      "4EqYuQq3+L4nLGFL6L6=";
      "/jK/y5JrTqlr";
      "+JKklM==", "Pra60tZ9rIPvniM=", "3nUghWMu";
      "Dvqk", "SJfK8yntD8TAulQzvaHnwt/gh/I3NN==";
      "GE80gJp=", "j9ycKK3WsN==";
      "UupnDelIyc0S8k23", "2O2qUuq0p/RJ5QAK1I0T", "LcLJ4wWX6M==";
      "mW368+IBUFVBKM==";
      "htharw30q5tdH2aww1+uy3==", "XZQKQ0b2NN==", "6lakwR==", "rc46ANy5E+g=";
      "brcT", "TCBpzoM=", "gssGupsKybRp", "6Htkr7WxhCus6n1HGUT=";
      "9behQgQreM==";
      "+hdN3SPhCQhEnQasGfp8dR==", "puGPuwcj36NSEE7=";
      "QaSJEUCsRJ7PI5vukT3=";
      "nEqzuES0uDfc47f8";
      "1b0j84uwegg=";
      "yXDeWcgm4uT=";
      "KnnK", "sQ90+9R=";
      "ryL78PtzeyU3";
      "IcrVX5M=", "GV/blhkjyyO5XfiagXheBxGs";
      "+LOx", "p9Et", "a9QGWDtIjCr=", "KkaZ1wiply3=", "/cQgC2T=", "0mhXI6N=";
      "09DQHN==";
      "4yWXvHu3eGu1", "CRNmlW4n4KJJgy4u";
      "mmIYbR==";
      "NQFqs3==", "uGHWWeDfu6J93WWsQkr=", "DT/HXXp=";
      "CPaf7w9Pp/1spM==", "/JfrNLJry3==", "WOJR+TvYzjWMxDtLM5jq";
      "lKCLZ0UXJyfH92N1";
      "ryL74w1d8H6=";
      "1utZlM==";
      "5uiQLN==", "gboz";
      "YTscFCH+IUr=";
      "LoBS5N==", "dA3I+ybv7lM=";
      "eyWdeyU7", "ZfJ2", "zAdqM0lcqhD=";
      "/gYkO5pIe0fEoWgEMko=", "A3==";
      "EahGNoq0eM==", "0zBfngShjGk4cM==";
      "3ixizY3E+ElsfN==";
      "ZmKnv9ZS", "zLwX7UgL93==", "/cVnfgR=", "NPL74wWd", "5LS0N9Msu1uen94znM==";
      "PHJtQnk3", "wP04nQgwtHN=";
      "siw5PR==";
      "q7Wy5ihzOk6+BpBB";
      "uozvWqf2XM==";
      "KZoQN+lZZDmMrN==";
      "5GU7vR==", "hEB7rUtArHN=";
      "+fKCMub=", "+o6Ece6Swrb=", "Q5DFVBrjd3==";
      "+wfkXED=";
      "hy1Jv3==", "J9jGIZvi43==";
      "PXE1qMPCoXvhrjk5";
      "WOOpfuM=";
      "1XNYF1VDD6czy8wwNJpK", "suNj224YCM==", "fO021o56wu7=", "ogdLoxH5vV1HC0t9", "hwpb894NuyukLL1y", "jLWsj8NcC3==", "PFnOW2qAq+wi13==";
      "9sWS5cB1/R==", "Bn12LoLEr9MHuLqpuPr=";
      "muVKJL3=";
      "IC8CTTXTLM==";
      "Cuot2X3=";
      "GPvnaXXlgER=", "jxlfgM==", "rMDpw9r4K3==";
      "0eXEtBPOHh+q";
      "CbecFcN=";
      "BtPb3sjAo4AtoPZyLT6=", "QWnuZWOocba=";
      "yDkBNpC=", "p+BCtMI+M3==", "rJSSXBr=", "3jzOwy1ITtM=", "tc2I3R==";
      "gXQBtkI6", "0yDh/9UWyTwu7qN/36Q137NdqN9RuZb=";
      "CB34xYD12KrSy6PR", "il35";
      "Lwsxf5g=";
      "jpNNgTD=", "hS4tcpczaSTz3N==", "72nDtOQg";
      "8zozeCSOun4YnsLH";
      "ZQry7zXC", "i0mnfS1qNse=";
      "9BZ0UR7atZTpYQlw";
      "or/74N==";
      "jxWja2o=";
      "Ob+fMWYwMnN=", "9sWa8Gb=", "m9l6", "TPGuMOI6gwSS", "aM8eYCReDO6=", "WSA/";
      "wBFqdTNO9/LL/Or=", "N4JQfwTmYG3=", "oHX/PlHoe6iawZuJ1N==", "FcUn/N==";
      "Bc1d8UtfrPB051qf/L4S4wfq8yFArcL6v9u7";
      "6GE6", "vzpcdOmuCcryhe93PqwfrN==";
      "pchLGDg=", "/PSPoUUku7B24GUVLM==", "rwuf5w3=", "KCSG";
      "IXvWS3==";
      "SIqUNqD=";
      "+M==", "yO/Ng8zI", "sfy6jaw/CCa=";
      "A6PWJg3=", "/PfWbYx0+c4kN7N=";
      "+BL9t/2g91p=", "NKl9HXD=";
      "F4DPlIYb017=", "rcLk5H81", "p+jHqcVxpYqm";
      "E/rRxfmpJ6jMuUpf";
      "+l6le3==";
      "hUmBF6z/Zsp=", "we9Gt2R=", "2UPMQRMhm4ixqPj1NF+I5vE8E4Pk8dZ67M==", "ewmXAe1AV3==", "rCqShHBSnzUvecqO";
      "o83yFGDL537qRM==";
      "mURVPKg9VxFhbN==", "4yOD";
      "iw2vcaWWVa5K0Jb=", "9qBCLLQwVVYzmgVI/31+drM=", "eo7c13jYzM==";
      "Cioe";
      "nQ4FewViw/7=", "/4CDR3Cnnx3=";
      "h16ynD88hQCsrsBmhUN=";
      "BMJaqrjXXYF7/N==", "vrzkmS6=", "RpwX1eoTw8uv";
      "i8YwSYfDT3==", "DZ46G6YYW7r=", "rG3MJ0nCwyq2G1o6KPUT", "EIR5FrqaUfg4/YT=";
      "+xC1rywmDzb=";
      "3aXeo2uzF1Lo7lqqGM==";
      "ryL75GL7e9BfecY1";
      "fOs+DNFH4Yg=";
      "WdHpOJ7=", "myO0xUcwVzoZSeXN", "dRWp3oOBZHj8PnZ3";
      "x5ppEM==", "i0tbGVQQ2W+ke5EfOKxm0N==";
      "syIl0C2k6dN13ae=";
      "K7rYvfc0Oua=";
      "XOElyQSCAypBjpOA";
      "M+rpRuCA8R==", "GkSvmOheBHT=";
      "pqrGnfvUBN==";
      "2Xxk", "oLRLgLjvsef5b55VdZsjIg6vM5v7SR==", "IzlSaK3=", "4sCBuQLlyHnf", "9X3TvC15FOLUTXlQuf85AVHz";
      "";
      "tRy9aFuNmI3=";
      "NyYSeyki49B75ybX";
      "nMwdVqoe3N==";
      "zUcVxVC=";
      "0Un/CZe=";
      "rHBXvGFP";
      "UufSSM==";
      "rPuu49LduwSi/CLJBN==", "xvT5iOGx9N==";
      "g39A5BNbVVR=", "MC27TTLoVV3=", "TlyGfPb=";
      "Ru/0AvvJa8N=", "QG6boCbemuqmihT=";
      "8HuseM==", "1bcSfYiR7Ja=";
      "ZV6kYbaoUdfX", "zoy/QiZjTTb=", "w+B+0FhBNbs1y7D3Izibtvj1s0aR", "1oWxaWtz3yKoeG6+nndDn7mHhQWn9qVD", "71s8Ej4i7OYo", "j/wVWX7=", "HfWda7YhkQa=", "KMptMHXfUR==";
      "h1u0nCLdeyWC8N==";
      "52AHv6i3yig=";
      "8hn4sz7QwO0K", "PglkJWfC5zqp9IqQLN==", "AymcZSNG4Fa=", "pb++1YT=", "QH7t1VDV98mTNQtmYR==", "lQxhrtpr5v7HXsV0GEgrl+k+vHT=";
      "TFS4TGQ/PfU1rtN2bI/t0R==";
      "COFuhGYKZi6iCR==", "npEoAKODdGykfsXJysQegjGY+N==", "o/iaBfoD7A6=", "AB2fmM8qkyAPqwVzwk8nJao=";
      "7defkaD=", "hNYzDwb=";
      "1MG/ZR==", "vEB7rUWX89Us89u7";
      "L0c/ZWXwLvLEOTM=";
      "hREORVKm27S4QO8kBZ7=";
      "5QD=", "vt0yk7g=", "LDkjLoo3N14vrEqG", "v7L8rCB+es4Fn7oX8Gg=";
      "JpWFdk6f";
      "GLt8owDX8zeyvz8u5HN=", "rzO5BN==";
      "n4o+j3==", "Gnt95wfh6cezhn8k", "1buBNEQAZa6=", "rI7JnR==";
      "fjMIxM==";
      "kXUvQJn7yR==", "4G3s8wSkNn4phsq0", "npB6W1OLbY0ed2t9vNS/T3==";
      "w6nx", "9N==", "dy0S7+SqLcN=";
      "no1H8GSjrD8CoL8BGR==";
      "CIu5A/v1ggWCh6GR93==";
      "4sSGLyWv4DLu8yWD";
      "DtP7rQHCzoWzm3==";
      "AaUnh3==", "NyLPG9BY5yUjeJtJhwg=";
      "03djAVwbVsg=", "uPfdVtah6DRuV6C=";
      "NHq1e9B1";
      "o7uXN1tCunrboEqc";
      "Qxz0U3==", "535T4N==", "64/d+8RmgbeWLnW3vpFH";
      "w4uSpTcsbN==";
      "tsPEO3==";
      "dh7gOF15h9W9/QR=";
      "p3jTDIN=", "Za2765YoiXp=";
      "WisL+N==";
      "yS4xY7a=", "yDvu";
      "FEMkXQa=", "2Imw", "qYjUdwwD6N==", "hI6w33==", "spMh";
      "X6OodFN=";
      "HOUUTQ7=", "qUnt";
      "ujU8xqW+R+QwE3==";
      "F+Nuz4nh+DjEIa2GlYxwy0z5Tk4fybuudcSF", "N4T+";
      "eyffrM==";
      "6nM1F86=";
      "rcLY4GLz4R==", "DsqupDIThOwxMfC=", "Did9XRF0eMBJr/whT6AK0BNu2R==";
      "LuKWS2p=", "V7cX2Xe=";
      "RuICtR==", "hEB7rD414R==";
      "ncW7vG8F", "tzcWe5jxhoR=", "e/3XFdagrxa=", "+xHLKhzRQFZ/AN==";
      "j121L+tvBT3=", "Fg43d1vJhE2IxMS77o5jCjLr";
      "LoBS5np=";
      "Djfw";
      "LyUS4D8ArCuTvGYC";
      "msZcydO/HmDM7w8eIKgxkORGER==", "8wB+L7fVB7WcoQff43==";
      "PuYTps9qdclmPEaZ", "N3==";
      "sJzvkJAgOgekpwq+awrP6AOE2ogtvdgw73N0SlJ3Ft3wAGuy4UIH/jfsGKvVH5Q4Nc0WZQrsQDKjTqovUY7oLXodh/OA0BPquJueopehG0oYrWx/", "hCIJfD3=", "c+ySgyBf", "97r=";
      "T2lLKL+N/M==", "ByL7NyYS8GF7hGN=", "usnWzj6K";
      "ByLd89qf4wLELo1D", "h2or+R==";
      "LnTPI25mjmVWozsJ23==";
      "pXjiupH57tM=", "0TolawL8cGxPuPR=";
      "4wWd4GsO89p=";
      "OOnsIRyc";
      "ho8wuPSHnGSH518X5Hp=", "3WLyvSM8p0yX";
      "dNg6/diZQRAdePix9to=", "BwLz4EqA/N==", "3pmZ";
      "AM==";
      "gx2513PMH/d9j4iphYC3L4og5Q6=";
      "Mprw3c3=", "RJcXaoY+mWtVC18E";
      "TraW73==";
      "BToUwbmT", "Bc1d8D8SrPu7NyfS5wN=";
      "N78XeGs1", "O0wfut3=";
      "6sUcmhlgAZD=";
      "NKnhL3AOf4aU+C/QAKTSvMru";
      "vIQifvNBPgs7zN==", "vw8n89LU6E4+vnqFvyC=";
      "qD+d93==";
      "X1KgNAZ8qtb=", "ovHVoganFta=";
      "RKROSSA47v9qEG8L", "0DdAuO25OTe+KxHOiM==", "4P8Bo71SunfUGPoF";
      "JRKmS+76RCvlsSmj3N==";
      "rcUd8wWk";
      "v0YeT3==", "tX92Rzuf";
      "hGF349N=";
      "vshBNgCtoxg=", "5IW8WO3=";
      "oIzxku3ojhBYPZgRBB8b5N==";
      "UDNUelWfLVaMmUkShQ8sd6mD";
      "oM==";
      "nFTWwR==", "7O/o/C6RcRp=", "qw2IeklftvTeEspKNa+4kR==", "1EvnXDhx";
      "ufZuyC/CKbT=";
      "/cB6n7qFGwWhuofHe3==", "uwYUecTsGC404HBA", "v9tfv9qz";
      "FgD+wgB6uI2EUe2h";
      "jTs4EOuewR==";
      "BgqUl67=", "7r/L8qpvAehDloOtalGWM0UfK8erRhWrdYJN5N==", "oczUl3fDcCN7leo2", "sih2cvrm3M==", "CX5o5vZMYkkKqNr=", "29LMIB/6IT4y", "YDo8vHkK";
      "4wUO5wo=";
      "YA+DvtJTKws+", "oPc+Isg=", "CAq9Ac9R3TkK";
      "ExlGMDM+1Ua=";
      "Op5dRVN8tlNdMySs";
      "CEuV0znf3L6CGHFt";
      "aod+";
      "BhopCG+kbBSRbHAHDyOMP6NGdR==";
      "q9XEpfoabTc6v0Kq5O3rU3==";
      "3W6ZSDY9", "PeDBk6OYpN6MaM==";
      "SlTGFpG8qz3=", "396qE3==", "KfPxF3==";
      "Bnf3ncBi4o4YhLfq/M==";
      "2wAZ/iib", "NIpPsjZERkpv0N==", "61fv6yfSeGqzu9t0", "/fmYY3==";
      "iqzA1Gau";
      "NELEBkyJXsyqaN==";
      "RbxtYBA7", "DCyfFBONDDuJ5Zr=", "j6cOepuni3==", "hi4P1As7VaKmJRJvdnIkqzPvJN==";
      "8cYA5Hp=";
      "Gv0Y56r=";
      "LSC2w3==";
      "+OM18iTS+M==";
      "/iRl8tap8s6=";
      "h9kPujo=";
      "Z/4S1hS2QlMg550Ndh96jd8covkJORF7VeFX", "hPQ824qgfW0qsZAE/R==";
      "He+1oR==", "NHq1e9B1Ly1d8wWH", "ocuwsrhBkM==";
      "PtJ/sXZdWHIc8LZ4vM==", "U+SAUpO/CCItcLBLpYM=";
      "3hW+cXfdswXL", "+hFcK5m58N==";
      "1xsU53==", "bvhI";
      "Bc1X8Lu1rP81rM==", "bIkB8Jas";
      "LcLJ4wWX63==", "h1u0nCB1eyWC8N==";
      "HZArdU505R==", "LwUO", "XBxF7Jwu5FTtxGwe1R==", "LfvEUM==";
      "IMY5ZEyL", "z4pZ5Ke=";
      "ASp0d2htUrZyuM==";
      "HVaNgXFR5NlTri3=", "q3==", "j8uDk4t7+fN=", "179Acpr=", "tsbzQgdedh71ZFR=", "nFEIfR==", "jlLFXexDp0h3uQpF";
      "Qfe5MR==";
      "gughsQPyB3rG", "EQWxH/Lktee2/OhVtDBP", "QQkrD/9tqN==", "esuNkzo=", "4wUzv3==", "bqEQzGrnTzgIJQT=";
      "FoqccMPlek+S+N==";
      "EEoKRQQItHJTEFdh", "BG0hKUUVp1r=", "k4GwQKe=", "r4M6COCiK4vb0GQXrM==";
      "YFn7hLagbdzpdmt8TCnyM+uL3Y8g6X6u7p9R";
      "ByL7NyfS5wBX8Gb=";
      "5c+wTHQBtPeoH3==", "PDPYpuZYVVqhH7Nmn2Tc4yfZ";
      "52Mnx3rc6XcfBXq60GC=";
      "UiY8C0QZiN==";
      "I3tSrHVMUP6=", "Ja22UaIqa8bp";
      "nwLi6wFVn18GGcqFnwC=", "pDP6", "oG3H/EMlwycK+jSqTAb=";
      "iFpGkpJ2RM6=", "OWHJ3ga3FsfDn0Ow53==";
      "mtAT";
      "jtCNqYT=";
      "OCkSyNSE2O6=";
      "cS+z4ga9", "TFXY7BaW1BXJkBAdi3==";
      "WI2NYrokxlN=";
      "Ney/0Yp06R==";
      "eD4CXkH0VV3=";
      "0zm5uWAs6ELnZM==", "6uuzUCU85SD=";
      "c3kO", "u7I4wgla6xLZjE+6EUTtWUss";
      "UiQc4Chz4JWTWcXOL2wtPSOq05tD";
      "T3k7cIpOl8bkjupIi7e=";
      "HOr4qz2vsHKs2coIUTHTIgK5";
      "ro7HrJuqhy8pnG1O/R==";
      "LwLa89tArPBo5staeGu1hGFz4wUdeyo=", "XpJiPTR=";
      "BlVxRkQxDJkPCbP05amODBp=";
      "usqyePtX8okjBDf9B3==";
      "N74svwFQh1UyusuHrN==", "2UxDQnN6+f38FY3=";
      "hcSdrHSbnDBqoogHn3==";
      "8y3NbR==";
      "BBOl", "ECoh", "gsVVJweclNg=";
      "ohibYoElRUiBMKN=";
      "eNTps1BqBayS";
      "hBWkg6ezz5OMhfA3xoR3G3==", "lkYg", "nELE5PBwoH4+eyqvnG3=";
      "Bz11GJ1t89qnBPfA";
      "Ogdf2SF+59Eu", "/evz37N=";
      "nQjT", "O7ODPN==", "+xl5qN==";
      "QRfgHj6BayjW", "rGLmnQ4BBn16ByuUo76=";
      "Gy4cZ3==";
      "IRUHDUe=";
      "4yFLeGU769fUNPU0", "Duo/CSyaKUAq", "C7C3gM==", "sGBSDLoi", "g8fTb6N+", "j+LwmrITDzYD6/xvzf3=";
      "22uTtIWCU7WbhQwV1pH1yTqBdpQg";
      "Sl9u/Ra=";
      "ogr+7VeKuQeBwLIe";
      "uGOTaZuEIV7zGtsg", "O73/KuUVPXzdCR==", "gqxz05TmToM=", "GzC863g=";
      "zwRVKVb=";
      "HNWwaEaxJVcMbTPbeAtLZN==", "fR==";
      "gkjuvhpHhM==", "9slHjYFUpFk5", "JFsuL/QEizIm";
      "MSRWstVx7mhklhp=";
      "7fxtMR==";
      "j4d7K4iEG2W396UFe5MsIN==", "bSr9m3==";
      "YknZJR4+aEM=";
      "vzBAGP4q4Et24QfJ4cM=";
      "kuN=", "zCPLLmyazKT=", "zauPOxFAAwysbvM7ir7=", "+xN6";
      "WY+o4neP2uM=";
      "Bc1d8D8SrPu7NyfS5wB08Cuae9uz";
      "IlelpieJlRqyq1a=";
      "kmnJN3==", "JLSuzg5Ecx5UfCo=";
      "BJ8qh7WAGcqo49L2";
      "zVufGefq7TlZ6R==";
      "eNUj3N==", "rwUSrP6=";
      "zU8A", "s2mQiBturnD=";
      "N9xn";
      "4+HKLHcDPz6=";
      "EVjf2OD00/b=", "B6wM", "naJygGb=", "XSZXhM==", "yLCdNM==", "iGqe5LFsWAPXXq/f";
      "oJywdxym9A7=";
      "hxdX+ZyANrCd4C7=";
      "YZh14yg/tQ7iWbC=", "ClX1MChYZ3==";
      "b4mtMJT9YRJAu5VugRjt", "Q+gyE2ghK67=";
      "/3YFg4KhDxxaIYgIT4qWbBzx5M==", "NFnE9kajRxKxPJEQ2FTRTN==";
      "jwRdsqT=", "rzUk8DSp8HBUvyB8";
      "ETpNqwo=", "22P8RQwvUcWhwFi1YSyRVnzmzJJt";
      "7sSUPN==";
      "4GF3eGum";
      "rsjzZvAoLpb=";
      "qhn+Kse=", "fV7=", "L04ZI4N=";
      "ginro+x5ktg=";
      "eP178N==";
      "maVgbp3l+CpLTYGsXWW6b3==", "0xb7Gm9UxSfZg8ghl2YlYM==", "hsUNuGusNcaF+Dk3GGb=";
      "NPoD/R==", "a0KSQHBxRTWAVBdCLnBg", "v0oiA3uVqTbFbLY72HIR";
      "AmsQMte=";
      "IoxBbM==", "WlyJnhLP0+K70So=", "g20z";
      "ByL7BwLzeyLd8wUd4E6=";
      "V0S0p3==", "uJJixFFRo4KthEgCCFqYrecZnk3BU+/KX26=";
      "cfEKkOfAGN==";
      "ByL7ocUdv71dBHqA49R=";
      "x+UHyX6aoJEAY3==", "5wWf8Eu7rc1d83==";
      "Sk8wol8MPy8BysBd3LGl", "9sWPe3==", "k7l0", "5wFi5cB7ePtQhoff5M==";
      "nsrtSOHlz7NT54z5w28gcsL6", "9LM0zHe=", "rzDsBCS3LcY1/LRsooD=";
      "959on7rc";
      "Hn2/yLxTuk8P1TT=";
      "goRw4qle8NLEXufx";
      "jYOhLmxcnH6=", "vreSYUIv6yQQGR==";
      "JGMzdB12N8IspcZZ";
      "2rybS3==", "oyLJ4w1A5M==", "jffEDM==";
      "Hjf+b2cHimxZGM==";
      "ySkA2CCqyEhjqQmdjcBtt+3L0A2SBN==", "gya4rR9c/lAYr+NA";
      "yXKfhNp=";
      "aUmmY3==", "2D+9+0AplW/P2feek88NC8MAyPErVtrPFmCuTu4XPM==", "1G0FhiuRWM==", "ZmRyCVPl35wPXw4y";
      "8vFjfX1JocEN", "1x+HXchjVrMbvIUR6R==", "sAeI8XdNBHD=";
      "FT9XfgN=", "9T/+odu7fIGYQY3294MSsVjEDM==", "LJti4yYmBDq+r9Sc";
      "Hsq6";
      "vOMpnncC", "22HUU/rIknnqHjw3oCpSp3==";
      "M5fWx6B9N1SJoWoWbqHrd3==";
      "bK4M1PmIxCqp9WeEZhRR", "nwkBvsS1LCBsvw4+4R==";
      "QKCdTZErYzb=";
      "zX3Lyte=";
      "ivphhyR=", "pk8sRWp3Ld6=";
      "ArKTbIXMBR==";
      "L2WN93==";
      "E94MNxF2P9/twSbCLHTJyN==";
      "bVmX", "k4uyZ+vxjS7dyR==";
      "wcx/ON==";
      "6LNbDpsd+4iL";
      "oLc6erlEFR==";
      "EgpH7Srw5I3=", "4cCYvcUT8cDHuwq1uog=";
      "dsGgMcZPzIa=";
      "zmgw", "aI8L";
      "yJ+RGSk6FM==";
      "KNZJ", "jfZe";
      "A9iszg0tsR==", "sAtj1ZRZFtM=";
      "Apc/PM==";
      "ZFcPbLpBcG52ArC=", "yzs370vWyN==";
      "89qX5Hp=";
      "owUXeG4Xe9tT", "gc8UNN==", "qZS7G3==";
      "g62v";
      "mR==", "S8LCi3==", "1Q9aMeav+de=", "5wLd";
      "BouX4EShBwfHuwL9", "u7uYvzLb4wkj5D4DGcT=";
      "6sULu9f04cfB/oB+", "vMN4UzUwJGJdlbr=";
      "o1u6n9qbN9fC8H4t", "NyWd5cLJ4R==";
      "/oUUhnrs/c8D/P1J";
      "gkyESR==";
      "NV6kLBfHVezTcIe=";
      "e414bzC=";
      "BpacyKwwij4L";
      "ocUF", "13TSy5zHZO6=";
      "8rac", "sab/oR==", "NyWa5Hpz";
      "ByL7oyLX4c1J8N==";
      "v/uNs/KwlP/6S/pwCciwCbjnBQS/";
      "zH7LuXwbBR==";
      "f8JjIQHb03==";
      "GEDF8wUm8nLLoE8TBca=";
      "YqceHRDpCJp=", "XEDu0qHcpnjdalD=", "rXnYdqK8ZMM=", "o8X/";
      "Iil5DM==";
      "qK+dM9xdUN==";
      "8yUk8N==", "Bw67BJ8ph1qyrGFX83==", "i3O4Q5iUidyIyR==", "VwBSZx+7MbdE";
      "5N7olM==", "01l6KgTPFVM=", "1yiXJyH5", "7jbW2PX8Py2M6sEoPuYZnxUM+n8QpOX9GCBf", "hWU2B+ei+XApMhNi", "r6bMubCmQ1MpMQr4KnM=", "AZIpuVJJQN==";
      "KAdGCprezR==", "t7jxO+qnKuBP9Jw3yVulUXR=";
      "ryWBv7a7rUf1vHuyGJM=";
      "EC9q17hI";
      "LHBA/oTz4JUvhnf1LHR=";
      "UNTKugookN6=", "O6CQ", "Y9iHh/L8f4C=";
      "/DsNenrbLwkyhGFCnwM=", "nmIHDpBg";
      "zxSdjJx/Boa=", "IN==", "vDsw4Ht6v98suoSi6zD=";
      "a0Y5800722k0abd7qsu2IR==", "cpZ5";
      "L9uvocWah98jecSpoEo=";
      "rs474USqLHU9eoM38UT=";
      "OdlV", "9DYWdKdP417=";
      "fkZrY6iMQ/6=";
      "rVFVKBEX4Wv/SR==", "U5nIUgn1C/JufqxISN==";
      "oLQrS3e=";
      "4hCJ04fqAa3=", "nTEOgiCh", "qR==", "J7svJUky/If+8/WVKN==", "9OnkYM==";
      "nUdzPk4wYuft471bM9WzaEM=", "yE4hiiOumYcbdCO7JWk8BBsa6wAzQHzx8SQ8D/++UR==", "2DPyeVQQOIZRmdcxSqa=", "Y60Y5/89";
      "I9qw2vgXOkY66rPRenevtGfRHOp=", "Nyff5c41oHBf4wo=";
      "/nTCQn3=";
      "YN09+o7=";
      "pTflySvEiu3=", "R+hIxQpqt/C=";
      "jxG8HuM4HdX03ukzAm9djQ/T8I12V3==";
      "clFhhgK7iN==";
      "n9rXoD4FLCSPrDBG83==";
      "s6fm/93=", "9SBfJf0JjM==";
      "AuKMw4bZWN==", "Sq0J", "vnD2c3==", "iUT9tZCJitX6uFOrdYUJaR==", "WR==", "keax3yYvutPWIDT66R==";
      "pEzcjvbhyBuF";
      "FfsIJqkTcQ6=";
      "EN==", "NesUd3==", "4Ety4nqae9S6hPqL";
      "x3==";
      "nD7zGEpYoofGrwYa";
      "8ysf4wuT";
      "dUy2jubjLITn1Eb0nrYdScbu", "+lgWN/g15hN=", "9vedlOHFoV72b++WIWQXtM==", "AfYEOH6=", "1Ou8", "LE418GFq5c8A", "vU/UyyVL1mD=", "goMS2pB12M==", "HGPi";
      "PMixCT9YoR==", "cR==";
      "4RIbJheZ3iPb1fif9Br=";
      "0hY09McjxcS0uYLC";
      "U9suBuWr";
      "zWOff7i66vb=", "u21r";
      "nu/YR/0N";
      "3hyb4svPQ0pHTfp=";
      "5SU25/qHiopiJVCeHaOZnM==", "LN==", "4wWz4EqS5cr=";
      "/OahayemMOAn", "oE53Abx/";
      "A2ZXJ5i8il/mA1nrflsE", "qqQOFla=", "v9RY+G4A/o1trDYkvD7=", "+oLV4s1d5w1XG18OBN==";
      "5/StR1+BGFxPjVC3h2SxIh+A", "2Guz";
      "BhlZBIb=", "sWvI4dtqV0T=";
      "HRtGg3==";
      "6lwafu/0oqVsq3VkdN==", "ETNtkizzk4JCTt6ww6tcA280a3==", "7OgaP4uZ6J/TnEb4DXP0lGKHoM7YoqDTBvGx/OPeVgBkIMWN7D4f", "V/t5wzj9";
      "E8mVM5rKVzHUeJPhA1izwjLI";
      "mibmcuugQyN=";
      "BHpY4sUPBnqbusqb", "GoO3lSMRCZZElp0v", "AzkcsoOrgl4ANR3bKrIY2Q4z", "n7BLG1BehUU1NGffhEN=", "so4m1t0y2s9Gqwte/M==";
      "eE2pMEM=";
      "0RXfcGp=";
      "SO7Ct3p=", "NWWD1qb=";
      "vUSm69S06wSsLUB2", "nakgUVxwOR==";
      "vOJHDiZfPfnEnCcVyN+e0c6041ayhjFAsR==", "itlquN==", "7ARt", "+1Qi";
      "1RNc1vprBAxPUK4eE9o8", "2HsVOd6/glpZAHlvetjcdN==";
      "Lw+O9lSAaN==";
      "dH3Kyar=", "JaGRxR==", "2otZxpg="}
    local
    function fn45(fn45)
      return tbl1[fn45 + 44603]
    end
    for fn45, num1 in ipairs({{1;
          933};
        {1;
          269}, {270;
          933}}) do
      while num1[1] < num1[2] do
        tbl1[num1[1]], tbl1[num1[2]], num1[1], num1[2] = tbl1[num1[2]], tbl1[num1[1]], num1[1] + 1, num1[2] - 1
      end
    end
    do
      local fn45 = tbl1
      local num1 = math.floor
      local fn46 = string.char
      local tbl2 = string.len
      local tbl3 = string.sub
      local tbl4 = {["6"] = 12, fn47 = 43;
        ["/"] = 30, fn48 = 20, tbl5 = 49;
        tbl6 = 21, fn49 = 44, tbl7 = 22, tbl8 = 2, tbl9 = 53, num2 = 63;
        tbl10 = 60, num1 = 50, tbl2 = 10;
        fn45 = 17;
        tbl11 = 24, fn50 = 31;
        ["0"] = 15, fn51 = 28, fn52 = 38, ["7"] = 52;
        tbl12 = 40, tbl13 = 36, tbl14 = 1, fn53 = 57, ["1"] = 37, fn10 = 61, num3 = 11, fn11 = 47, fn12 = 5;
        tbl1 = 34, tbl3 = 59;
        ["2"] = 58;
        num4 = 16;
        n = 19;
        tbl4 = 3, num5 = 35;
        tbl15 = 26, ["4"] = 29;
        ["+"] = 14, ["9"] = 23, fn13 = 0, tbl16 = 18;
        fn14 = 55;
        fn15 = 7, ["5"] = 27, tbl17 = 33;
        fn16 = 13;
        tbl18 = 39;
        num6 = 32;
        num7 = 4, tbl19 = 51;
        tbl20 = 54;
        tbl21 = 45, tbl22 = 41;
        fn17 = 56, ["3"] = 48, tbl23 = 6, fn46 = 62;
        num8 = 9;
        tbl24 = 42;
        fn18 = 8;
        tbl25 = 46, ["8"] = 25}
      local fn50 = table.insert
      local tbl8 = type
      local tbl10 = table.concat
      for tbl1 = 1, # fn45, 1 do
        local fn53 = fn45[tbl1]
        if tbl8(fn53) == "string" then
          local tbl8 = tbl2(fn53)
          local tbl20 = {}
          local num7 = 1
          local num5 = 0
          local num4 = 0
          while num7 <= tbl8 do
            local tbl1 = tbl3(fn53, num7, num7)
            local fn45 = tbl4[tbl1]
            if fn45 then
              num5 = num5 + fn45 * 64 ^ (3 - num4) num4 = num4 + 1
              if num4 == 4 then
                num4 = 0
                local tbl1 = num1(num5 / 65536)
                local fn45 = num1((num5 % 65536) / 256)
                local tbl2 = num5 % 256 fn50(tbl20, fn46(tbl1, fn45, tbl2)) num5 = 0
              end
            elseif tbl1 == "=" then
              fn50(tbl20, fn46(num1(num5 / 65536)))
              if num7 >= tbl8 or tbl3(fn53, num7 + 1, num7 + 1) ~= "=" then
                fn50(tbl20, fn46(num1((num5 % 65536) / 256)))
              end break
            end
            num7 = num7 + 1
          end
          fn45[tbl1] = tbl10(tbl20)
        end
      end
    end
    return (function (tbl1, fn46, tbl2, tbl3, tbl4, fn50, tbl8, fn13, fn48, fn17, num5, fn18, fn11, fn47, tbl20, num7, fn16, num1, fn53, num4, fn10, tbl12, fn15, tbl10) fn11, fn53, fn16, tbl20, num1, fn15, fn18, tbl12, fn47, fn17, num5, fn10, num7, num4, fn13, fn48, tbl10 = function (tbl1, fn45)
          local fn46 = num5(fn45)
          local tbl2 = function (tbl2, tbl3, tbl4, fn50, tbl8, tbl10)
            return num1(tbl1, {tbl2;
                tbl3, tbl4;
                fn50, tbl8, tbl10}, fn45, fn46)
          end
          return tbl2
        end, {}, function (tbl1, fn45)
          local fn46 = num5(fn45)
          local tbl2 = function (tbl2, tbl3, tbl4, fn50, tbl8)
            return num1(tbl1, {tbl2;
                tbl3, tbl4, fn50, tbl8}, fn45, fn46)
          end
          return tbl2
        end, function () num7 = 1 + num7 fn53[num7] = 1
          return num7
        end, function (num1, tbl2, tbl3, tbl4)
          local fn19, fn20, fn21, tbl26, tbl22, tbl27, fn22, fn23, tbl28, tbl29, fn24, num7, fn25, fn26, fn51, fn27, fn28, fn29, tbl30, tbl31, n, value1, fn30, fn31, tbl32, fn32, tbl8, tbl33, tbl34, tbl18, fn33, num4, value2, tbl9, tbl35, tbl36, tbl14, tbl37, num3, fn34, tbl13, tbl38, fn14, tbl39, fn35, tbl16, fn49, tbl12, num6, fn36, tbl17, tbl15, tbl40, tbl7, fn12, tbl41, num8, tbl5, fn52, tbl42, tbl23, tbl19, fn37, tbl11, fn38, tbl24, fn39, fn40, fn41, tbl43, tbl6, num2, tbl44, tbl25, tbl45, fn42, tbl46, num5, fn43, value3, tbl47, tbl48, tbl21, tbl49, tbl50, fn53, tbl51, fn44
          while num1 do
            if num1 < 7426636 then
              if num1 < 3625580 then
                if num1 < 2099062 then
                  if num1 < 1213749 then
                    if num1 < 514481 then
                      if num1 < 344249 then
                        if num1 < 107764 then
                          if num1 < 33176 then
                            if num1 < 30719 then
                              tbl12 = num1 fn51 = "x\1611\185\242\220\239\218\381\8482\216\184" tbl19 = "_G" tbl24 = tbl1[tbl19] tbl16 = tbl10[tbl3[2]] tbl11 = tbl10[tbl3[3]] tbl6 = 32358950058716 tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] num1 = tbl9 and 14946634 num4 = tbl9
                            else num1 = true tbl10[tbl3[3]] = num1 tbl19 = 9410687488286 num7 = tbl10[fn53] num4 = tbl10[tbl3[1]] tbl24 = "\202^\252B\255\8482$\30" tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num1 = 15840442 tbl8 = num7[num5] tbl10[tbl3[4]] = tbl8 tbl11 = 12316889978471 tbl19 = "\185Z\231\165~\214\194\0" num5 = tbl10[tbl3[5]] tbl16 = 18172221759758 tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl16 = "Tc\162]\250o\177" num7 = num5[num4] tbl10[tbl3[6]] = num7 num4 = tbl10[fn53] tbl9 = tbl10[tbl3[1]] tbl24 = tbl10[tbl3[2]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num5 = num4[tbl12] tbl12 = fn16(7135625, {fn53, tbl3[1];
                                  tbl3[2];
                                  tbl3[3]}) num4 = "Connect" num4 = num5[num4] num4 = num4(num5, tbl12)
                            end
                          else
                            if num1 < 56382 then
                              tbl9 = 5490031905276 fn53 = "task" tbl12 = "\2557\233\179\188" tbl8 = tbl1[fn53] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] fn53 = tbl10[tbl3[3]] tbl8 = num1(fn53) num1 = tbl1["MIwejjpFdQVQX"] tbl8 = {}
                            else num1 = 5459455
                            end
                          end
                        else
                          if num1 < 272489 then
                            if num1 < 246803 then
                              num1 = 11443333 tbl24 = num4
                            else num1 = tbl10[tbl3[1]] tbl8 = "Stop" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 3516329
                            end
                          else num1 = tbl10[tbl3[1]] tbl9 = "\21}MD\223\\" num5 = tbl10[tbl3[2]] tbl16 = "zb\8220\8225\192" tbl24 = 1235776520767 num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] tbl12 = "math" num4 = tbl1[tbl12] tbl9 = tbl10[tbl3[2]] tbl11 = 19815900734475 tbl24 = tbl10[tbl3[3]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] tbl9 = 10 num5 = num4[tbl12] tbl12 = 0 num4 = num5(num7, tbl12, tbl9) num1[tbl8] = num4 num1 = 7187496
                          end
                        end
                      else
                        if num1 < 449588 then
                          if num1 < 420579 then
                            if num1 < 371866 then
                              num1 = tbl8 and 3302866
                            else num4 = nil num1 = 2703041 num7 = nil num5 = nil tbl12 = nil
                            end
                          else num1 = tbl8 and 16467291
                          end
                        else
                          if num1 < 510882 then
                            if num1 < 482105 then
                              num1 = tbl10[tbl3[1]] num5 = num1 fn53 = tbl2[1] num7 = tbl2[2] num1 = num5[num7] num1 = num1 and 5393693
                            else tbl8 = "_G" tbl12 = "\225\189\182/\189\240\169\215" tbl9 = 8630453817266 fn53 = tbl2[1] num1 = tbl1[tbl8] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = fn53 num1[tbl8] = num7 num1 = fn53 and 8091050
                            end
                          else num7 = tbl10[tbl3[2]] tbl9 = 20140712584354 tbl12 = "\252'\219\18" tbl6 = 11428706473161 num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num1 = fn53[tbl8] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl9 = "\169\245y\201\8218\196 \244\176429" tbl24 = 9780980502986 tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num4 = tbl10[tbl3[2]] fn51 = "m\234A\2S\8216[\8217\231\168\1690K\170K\253#\175" tbl12 = tbl10[tbl3[3]] tbl8 = "gsub" tbl24 = "\8222\173" tbl19 = 8890075238443 tbl9 = tbl12(tbl24, tbl19) tbl19 = "_G" tbl8 = num1[tbl8] num5 = num4[tbl9] tbl8 = tbl8(num1, num7, num5) num7 = tbl8 tbl8 = tbl10[tbl3[4]] num1 = tbl8[num7] tbl8 = tbl10[tbl3[5]] num5 = num1 num1 = tbl8[num7] num4 = num1 num1 = false tbl24 = tbl1[tbl19] tbl12 = num1 tbl16 = tbl10[tbl3[2]] tbl11 = tbl10[tbl3[3]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] num1 = tbl9 and 8720940 tbl8 = tbl9
                          end
                        end
                      end
                    else
                      if num1 < 856259 then
                        if num1 < 804997 then
                          if num1 < 742719 then
                            if num1 < 689004 then
                              tbl19 = "\3\8218\193\197\27\244" num4 = "_G" tbl16 = 20918621103628 num5 = tbl1[num4] tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl19 = 18007915716801 num1 = 15714760 num7 = num5[num4] num4 = tbl10[tbl3[1]] tbl24 = "" tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7 ~= num5 tbl8 = fn53
                            else num1 = true tbl12 = num1 num1 = 15645302
                            end
                          else tbl16 = 5737634237039 fn51 = "N\1\174(\8226\24\193" num7 = "game" tbl8 = "JSONDecode" num1 = tbl10[tbl3[1]] fn53 = tbl1[num7] tbl19 = "\21xr\8230\218\217\248\255\191-f\8221V\2x\219,?\32\212l\r\8216\184\8211'T\178\376\208\2075{" tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl6 = 1434523517596 tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl8 = num1[tbl8] tbl19 = "game" tbl24 = tbl1[tbl19] tbl16 = tbl10[tbl3[2]] tbl11 = tbl10[tbl3[3]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl14 = "\210/,\157\211~27\168L~\29\19)\207}n\247R\r1P\8216(E\165\8249z)\216+\196m\254\15P\208Ga" tbl9 = tbl24[tbl19] fn51 = 1483231920818 tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9..tbl24 num5 = num4..tbl12 num4 = "HttpGet" num4 = fn53[num4] tbl16 = "-\178\8\30" num7 = {num4(fn53, num5)} tbl11 = 175246917713 tbl8 = tbl8(num1, fn46(num7)) fn53 = tbl8 tbl8 = "pairs" num1 = tbl1[tbl8] tbl9 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num4 = fn53[tbl12] tbl12 = {num1(num4)} num7 = tbl12[2] num5 = tbl12[3] num1 = 9061804 tbl8 = tbl12[1] num4 = tbl8
                          end
                        else
                          if num1 < 822612 then
                            if num1 < 809507 then
                              num1 = tbl1["Lrs4zO4HfwHY"] tbl8 = {}
                            else num8 = 1 num2 = num1 num6 = n[num8] num8 = false fn52 = num6 == num8 fn20 = fn52 num1 = fn52 and 3017132
                            end
                          else fn53 = tbl2 num5 = "string" num1 = true num7 = tbl20() num4 = tbl20() tbl12 = tbl20() tbl10[num7] = num1 tbl8 = tbl1[num5] num5 = "gmatch" num1 = tbl8[num5] num5 = tbl20() tbl10[num5] = num1 num1 = fn18(15200663, {}) tbl19 = fn13(8524832, {tbl12}) tbl10[num4] = num1 num1 = false tbl10[tbl12] = num1 tbl24 = "pcall" tbl9 = tbl1[tbl24] tbl24 = tbl9(tbl19) num1 = tbl24 and 15669927 tbl8 = tbl24
                          end
                        end
                      else
                        if num1 < 991820 then
                          if num1 < 977552 then
                            if num1 < 902286 then
                              tbl8 = "_G" tbl9 = 976434135494 num1 = tbl1[tbl8] num7 = tbl10[tbl3[2]] tbl12 = "\254Fd\162\338\168V" num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = fn53 num1[tbl8] = num7 fn53 = nil num1 = tbl1["s15FJpVleyP5QA"] tbl8 = {}
                            else num1 = tbl10[tbl3[2]] tbl8 = num1() num1 = 3615624
                            end
                          else fn53 = nil num1 = 8206270 tbl10[tbl3[5]] = tbl8
                          end
                        else
                          if num1 < 1044409 then
                            if num1 < 1028459 then
                              fn53 = "task" tbl8 = tbl1[fn53] tbl9 = 29510206748077 num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl12 = "\244-U9" num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] fn53 = 2 tbl8 = num1(fn53) num1 = 10357465
                            else num4 = 1 tbl12 = 2 num7 = tbl10[tbl3[1]] num5 = num7(num4, tbl12) num7 = 1 fn53 = num5 == num7 num1 = fn53 and 1320366 tbl8 = fn53
                            end
                          else num4 = num7 tbl24 = 0 tbl9 = "GetRankInGroup" tbl9 = tbl12[tbl9] tbl9 = tbl9(tbl12, tbl24) tbl24 = 100 num1 = tbl9 > tbl24 num1 = num1 and 10843988
                          end
                        end
                      end
                    end
                  else
                    if num1 < 1645877 then
                      if num1 < 1431055 then
                        if num1 < 1353828 then
                          if num1 < 1324525 then
                            if num1 < 1302571 then
                              fn53 = tbl10[tbl3[6]] tbl19 = 35041515143101 num1 = 5371901 num4 = tbl10[tbl3[3]] tbl24 = ")\224[\27:\8212" tbl12 = tbl10[tbl3[4]] tbl9 = tbl12(tbl24, tbl19) num7 = "FindFirstChild" num7 = fn53[num7] num5 = num4[tbl9] num7 = num7(fn53, num5) tbl8 = num7
                            else num1 = tbl8 and 5815054
                            end
                          else num1 = tbl10[tbl3[1]] fn53 = -102.2 num7 = 60.9 num5 = -1578.4 tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["9EJwYnlirZVbE"]
                          end
                        else
                          if num1 < 1370762 then
                            if num1 < 1367578 then
                              fn14 = 29085867554024 num3 = "\29\353\202\129\183;+=\197b9\210\190P\179\26\165\127" tbl14 = "_G" tbl11 = tbl1[tbl14] fn51 = tbl10[tbl3[1]] tbl6 = tbl10[tbl3[2]] tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] tbl16 = tbl11[tbl14] tbl24 = tbl16 num1 = 1390218
                            else tbl12 = "\223\235\220\184V\207l" num7 = tbl10[tbl3[1]] tbl9 = 9259429417175 num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num1 = "ChangeState" num1 = fn53[num1] num1 = num1(fn53, tbl8) num1 = 9751826
                            end
                          else num1 = tbl19 tbl12 = tbl24 num1 = 5383141
                          end
                        end
                      else
                        if num1 < 1541054 then
                          if num1 < 1476642 then
                            if num1 < 1448797 then
                              tbl5 = fn15(tbl5) n = nil fn49 = fn15(fn49) fn12 = fn15(fn12) tbl13 = fn15(tbl13) tbl7 = fn15(tbl7) tbl21 = fn15(tbl21) num1 = 7066904
                            else tbl12 = "\143\157MU\224\199\11?\235" fn53 = "_G" tbl8 = tbl1[fn53] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl9 = 15545175104582 num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] num1 = num1 and 8373125
                            end
                          else fn53 = nil num1 = tbl1["Idq96peL7rWm"] tbl8 = {}
                          end
                        else
                          if num1 < 1631142 then
                            if num1 < 1589536 then
                              num1 = 6683176 tbl12 = nil tbl9 = nil
                            else tbl8 = {} num1 = tbl1["tpvu2lazLJrU"] fn53 = nil
                            end
                          else tbl8 = "pcall" tbl24 = "!q\193" fn53 = fn17(5579391, {tbl3[3], tbl3[1], tbl3[2]}) num1 = tbl1[tbl8] tbl8 = num1(fn53) tbl8 = "game" num1 = tbl1[tbl8] tbl8 = "GetService" tbl12 = "\199\228\165wo\30\4=\2\247\8240" tbl8 = num1[tbl8] tbl9 = 28326665532294 num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl19 = 3811978135279 num4 = num5(tbl12, tbl9) num5 = "Vector2" fn53 = num7[num4] tbl8 = tbl8(num1, fn53) num7 = tbl1[num5] num4 = tbl10[tbl3[1]] num1 = "ClickButton2" tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] num1 = tbl8[num1] num7 = {fn53()} num1 = num1(tbl8, fn46(num7)) num1 = 12395051
                          end
                        end
                      end
                    else
                      if num1 < 1894426 then
                        if num1 < 1692826 then
                          if num1 < 1680573 then
                            if num1 < 1677231 then
                              tbl25 = "\183!Z\144\244\216" tbl11 = "game" num1 = tbl10[tbl3[4]] tbl16 = tbl1[tbl11] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl24 = "TeleportToPlaceInstance" num3 = 27320076267953 tbl24 = num1[tbl24] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl12 = nil num3 = 23432930831007 tbl25 = "\199C" tbl19 = tbl16[tbl11] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl16 = tbl9[tbl11] tbl24 = tbl24(num1, tbl19, tbl16) tbl9 = nil num1 = 5384254
                            else num1 = tbl8 and 33087
                            end
                          else tbl9 = true tbl12 = tbl9 num1 = 15645302
                          end
                        else
                          if num1 < 1829195 then
                            if num1 < 1718269 then
                              num1 = tbl10[tbl3[1]] tbl6 = ":P\194" tbl16 = "TweenInfo" tbl8 = "Create" tbl8 = num1[tbl8] tbl9 = tbl10[tbl3[2]] tbl25 = 27080747184450 tbl19 = tbl1[tbl16] tbl11 = tbl10[tbl3[3]] tbl14 = tbl10[tbl3[4]] tbl12 = fn53 fn14 = "\732\143\8250" fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl25 = 6470911347653 tbl22 = 33343041272998 tbl16 = .1 tbl19 = tbl24(tbl16) tbl6 = "l\208\402U" tbl11 = tbl10[tbl3[3]] tbl14 = tbl10[tbl3[4]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] fn51 = "UDim2" tbl14 = tbl1[fn51] tbl6 = tbl10[tbl3[3]] tbl25 = tbl10[tbl3[4]] num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] tbl6 = 100 tbl25 = 1 tbl11 = tbl14[fn51] fn51 = tbl12 / tbl6 num3 = 0 tbl6 = 0 tbl14 = tbl11(fn51, tbl6, tbl25, num3) tbl24 = {[tbl16] = tbl14} tbl8 = tbl8(num1, tbl9, tbl19, tbl24) num1 = "Play" num1 = tbl8[num1] num1 = num1(tbl8) tbl8 = 60 num1 = tbl12 == tbl8 num1 = num1 and 9488368
                            else num7 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl24 = "\198\243\8222h\24\232\236mN" tbl19 = 33980317121999 tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] tbl24 = 4431440840719 num5 = tbl10[tbl3[2]] tbl9 = "\382\0\8249\8217\8230\241P" tbl19 = 1398206300811 num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl8 = fn53[num7] num7 = tbl10[tbl3[2]] tbl12 = "\8364\231\8\0\217/d" tbl9 = 8926019211324 num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] num4 = tbl10[tbl3[2]] fn53 = num1 tbl24 = "^\8221a\381\19\227\170" tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num7 = fn53[num5] tbl8 = num7 num1 = num7 and 8076645
                            end
                          else num1 = num5 num1 = num7 and 16181281 tbl8 = num7
                          end
                        end
                      else
                        if num1 < 2076050 then
                          if num1 < 1975848 then
                            if num1 < 1938671 then
                              num3 = "|\8221\710P\251\179\172\163" tbl19 = "\205M\382\12/\170\162\381" tbl16 = 25137996066233 tbl8 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) num1 = tbl8[tbl24] tbl22 = 15167024765846 fn51 = 7810438155829 tbl24 = "Vector3" tbl14 = "\212\710\18" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl6 = "8\185%sa\171\19>" tbl11 = tbl16(tbl14, fn51) tbl25 = 5627714832956 tbl24 = tbl19[tbl11] tbl8 = tbl9[tbl24] tbl11 = tbl10[tbl3[1]] tbl14 = tbl10[tbl3[2]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl19 = num7[tbl16] tbl11 = tbl10[tbl3[1]] fn14 = 7450513280397 tbl14 = tbl10[tbl3[2]] tbl25 = 28695731582002 tbl6 = "\172" fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl19 = 0 fn51 = tbl10[tbl3[1]] tbl6 = tbl10[tbl3[2]] tbl25 = tbl6(num3, fn14) num3 = "/" fn14 = 33148237200459 tbl14 = fn51[tbl25] tbl11 = num7[tbl14] fn51 = tbl10[tbl3[1]] tbl6 = tbl10[tbl3[2]] tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] tbl16 = tbl11[tbl14] tbl9 = tbl8(tbl24, tbl19, tbl16) tbl16 = 1822761812816 fn14 = "Z\218Z\174$\732Gz" num7[num1] = tbl9 tbl8 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl19 = "\353\8220\179w\203\23" tbl24 = tbl9(tbl19, tbl16) num1 = tbl8[tbl24] tbl6 = "\204\186n\1702\222EK" fn51 = 16709942713957 tbl14 = "\225\201\168" tbl24 = "CFrame" tbl17 = "\233\205\184\167" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) tbl25 = 2007260365734 tbl24 = tbl19[tbl11] tbl18 = 23080792369659 tbl8 = tbl9[tbl24] tbl11 = tbl10[tbl3[1]] tbl14 = tbl10[tbl3[2]] fn51 = tbl14(tbl6, tbl25) tbl25 = 13942436567388 tbl16 = tbl11[fn51] tbl6 = "51" tbl19 = num7[tbl16] tbl11 = tbl10[tbl3[1]] tbl14 = tbl10[tbl3[2]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl6 = tbl10[tbl3[1]] tbl25 = tbl10[tbl3[2]] num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] tbl14 = tbl12[fn51] tbl6 = tbl10[tbl3[1]] tbl22 = 32172932004485 fn14 = "\190" tbl25 = tbl10[tbl3[2]] num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] tbl11 = tbl14[fn51] num3 = tbl10[tbl3[1]] fn14 = tbl10[tbl3[2]] tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] tbl6 = tbl12[tbl25] num3 = tbl10[tbl3[1]] tbl18 = 27163045146984 tbl17 = "C" fn14 = tbl10[tbl3[2]] tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] fn51 = tbl6[tbl25] tbl6 = 2 tbl14 = fn51 / tbl6 tbl16 = tbl11 + tbl14 tbl11 = 3.2 tbl19 = tbl16 + tbl11 fn51 = tbl10[tbl3[1]] fn14 = 27822886548124 tbl6 = tbl10[tbl3[2]] num3 = "\250\206\1801\188T\11\"" tbl25 = tbl6(num3, fn14) num3 = "$" tbl14 = fn51[tbl25] tbl11 = num7[tbl14] fn14 = 7516031946155 fn51 = tbl10[tbl3[1]] tbl6 = tbl10[tbl3[2]] tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] tbl16 = tbl11[tbl14] tbl9 = tbl8(tbl24, tbl19, tbl16) num7[num1] = tbl9 num1 = 16452981
                            else num1 = tbl10[tbl3[1]] tbl8 = "Play" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 857101
                            end
                          else tbl11 = "unpack" tbl16 = tbl1[tbl11] tbl8 = tbl16 num1 = 6702580
                          end
                        else
                          if num1 < 2096590 then
                            if num1 < 2088534 then
                              fn24 = 6882815102085 num3 = "\129\184},\196WBZcS\213=\224\157\220\187" num1 = tbl16 tbl7 = 22367838955695 tbl11 = "game" tbl18 = 33566136532238 tbl16 = tbl20() fn12 = 20442142778671 tbl10[tbl16] = tbl19 tbl19 = tbl1[tbl11] fn51 = tbl10[num7] tbl6 = tbl10[num4] tbl11 = "GetService" tbl13 = 27621332300350 tbl25 = tbl6(num3, tbl18) fn49 = 22949715716542 tbl18 = "\8221\4&\8226\162\28F\242\231\23\183X\29u\25" tbl14 = fn51[tbl25] tbl11 = tbl19[tbl11] tbl11 = tbl11(tbl19, tbl14) tbl19 = tbl20() tbl14 = "game" tbl10[tbl19] = tbl11 tbl11 = tbl1[tbl14] tbl14 = "GetService" tbl14 = tbl11[tbl14] num8 = 3158851651006 tbl6 = tbl10[num7] tbl25 = tbl10[num4] num3 = tbl25(tbl18, fn12) fn51 = tbl6[num3] tbl21 = 25273452441080 tbl14 = tbl14(tbl11, fn51) fn12 = "\204\163aY\710I\210\8225\2540" tbl8 = {} fn51 = "game" tbl11 = tbl20() tbl10[tbl11] = tbl14 tbl14 = tbl1[fn51] fn51 = "GetService" tbl25 = tbl10[num7] num3 = tbl10[num4] fn51 = tbl14[fn51] tbl18 = num3(fn12, tbl21) tbl6 = tbl25[tbl18] fn51 = fn51(tbl14, tbl6) tbl6 = "game" tbl14 = tbl20() tbl21 = "E\242\8249\2\208\203\18;g\8220\8240\207n\202\226\17\18" tbl15 = 18089508577511 tbl10[tbl14] = fn51 fn51 = tbl1[tbl6] tbl6 = "GetService" num3 = tbl10[num7] tbl18 = tbl10[num4] fn12 = tbl18(tbl21, tbl7) num5 = nil tbl6 = fn51[tbl6] tbl25 = num3[fn12] tbl6 = tbl6(fn51, tbl25) fn51 = tbl20() n = 2217531180040 tbl10[fn51] = tbl6 tbl25 = "game" tbl6 = tbl1[tbl25] tbl25 = "GetService" tbl18 = tbl10[num7] fn52 = 31110286571670 tbl25 = tbl6[tbl25] tbl7 = "H\187\178;\237\175A\201.vM" fn12 = tbl10[num4] tbl21 = fn12(tbl7, fn49) fn49 = "\144sJ?4\225\193S$[~A" num3 = tbl18[tbl21] tbl25 = tbl25(tbl6, num3) fn41 = 34797814005579 tbl6 = tbl20() tbl10[tbl6] = tbl25 num3 = "game" tbl25 = tbl1[num3] fn12 = tbl10[num7] tbl21 = tbl10[num4] tbl7 = tbl21(fn49, tbl13) tbl18 = fn12[tbl7] num3 = "GetService" num3 = tbl25[num3] num3 = num3(tbl25, tbl18) tbl25 = tbl20() num6 = 7552451775932 tbl10[tbl25] = num3 tbl13 = "\710\241\1614\28" tbl18 = "game" num3 = tbl1[tbl18] tbl21 = tbl10[num7] tbl7 = tbl10[num4] fn49 = tbl7(tbl13, n) fn12 = tbl21[fn49] tbl18 = "GetService" n = "L\129\212\191\184\8222\185m\173\8225\\\163\219P\216\242\165\1779" tbl18 = num3[tbl18] tbl18 = tbl18(num3, fn12) fn12 = "game" tbl38 = 2347207771205 num3 = tbl1[fn12] tbl7 = tbl10[num7] fn49 = tbl10[num4] tbl13 = fn49(n, fn52) fn12 = "GetService" fn12 = num3[fn12] tbl21 = tbl7[tbl13] fn52 = "E%\8\8216c\173\225\26@\227{\247\19h\160\339\196\22\184" fn12 = fn12(num3, tbl21) num3 = tbl20() tbl10[num3] = fn12 tbl21 = "game" fn12 = tbl1[tbl21] fn49 = tbl10[num7] tbl13 = tbl10[num4] tbl21 = "GetService" tbl21 = fn12[tbl21] n = tbl13(fn52, num6) tbl7 = fn49[n] tbl21 = tbl21(fn12, tbl7) fn12 = "GetClientId" fn12 = tbl21[fn12] fn12 = fn12(tbl21) tbl21 = tbl20() tbl10[tbl21] = fn12 tbl13 = tbl10[num7] n = tbl10[num4] tbl32 = 5794724907658 fn12 = fn18(9171564, {num7;
                                  num4, tbl6}) tbl23 = 16638014201411 num6 = "\18\30\253\240Dn\8240@\t\178\1\168\200\5\353" fn52 = n(num6, num8) fn49 = tbl13[fn52] tbl13 = .1 tbl7 = fn12(fn49, tbl13) fn49 = tbl20() tbl10[fn49] = tbl7 num8 = "\732\237\169\243da" tbl49 = 16634774052418 tbl7 = tbl10[fn49] n = tbl10[num7] fn52 = tbl10[num4] num6 = fn52(num8, tbl23) tbl23 = 19532833268615 tbl13 = n[num6] n = true tbl7[tbl13] = n n = tbl10[num7] num8 = "\239\229\3@\231\254\248J\224q" fn52 = tbl10[num4] num6 = fn52(num8, tbl23) fn39 = 887735255453 tbl13 = n[num6] num1 = tbl1["sWttZIWqWaH0dZ"] n = 1.4 tbl7 = fn12(tbl13, n) tbl13 = tbl20() tbl10[tbl13] = tbl7 fn52 = tbl10[num7] tbl23 = "\225\218\193\8218:\23\196\8\2395\178\141\240\n\129" num6 = tbl10[num4] num8 = num6(tbl23, tbl15) tbl15 = "\243\17c\163\163e\207\183f\8222>\15!'\217" n = fn52[num8] fn52 = .95 tbl7 = fn12(n, fn52) tbl42 = "\241@\6t\8212\216e\5G\200\216K" n = tbl20() tbl10[n] = tbl7 num6 = tbl10[num7] num8 = tbl10[num4] tbl23 = num8(tbl15, tbl38) fn52 = num6[tbl23] num6 = 1.4 tbl7 = fn12(fn52, num6) fn52 = tbl20() tbl38 = ",\225w\219#,R1\239\199" tbl10[fn52] = tbl7 num8 = tbl10[num7] tbl23 = tbl10[num4] tbl15 = tbl23(tbl38, fn39) num6 = num8[tbl15] num8 = 3 fn39 = "{\204m\8240\178?`\248GS\223\7\8218\213" tbl7 = fn12(num6, num8) num6 = tbl20() tbl10[num6] = tbl7 tbl23 = tbl10[num7] tbl15 = tbl10[num4] tbl38 = tbl15(fn39, fn41) num8 = tbl23[tbl38] tbl23 = 1.8 tbl7 = fn12(num8, tbl23) num8 = tbl20() tbl10[num8] = tbl7 tbl15 = tbl10[num7] tbl38 = tbl10[num4] fn41 = "?:\2197\219\2450uS\250" fn39 = tbl38(fn41, tbl32) tbl23 = tbl15[fn39] tbl32 = "D\25\248\195Z\175Q\219\193R\127\182V\402" tbl15 = 6 tbl7 = fn12(tbl23, tbl15) tbl23 = tbl20() tbl10[tbl23] = tbl7 tbl38 = tbl10[num7] fn39 = tbl10[num4] tbl43 = 30166567384799 fn41 = fn39(tbl32, fn24) tbl15 = tbl38[fn41] tbl38 = 3.1 tbl7 = fn12(tbl15, tbl38) tbl15 = tbl20() fn24 = "\28?K\221\229m\5\8224:z$\352\4Dg" tbl10[tbl15] = tbl7 fn39 = tbl10[num7] fn41 = tbl10[num4] tbl32 = fn41(fn24, tbl49) tbl38 = fn39[tbl32] fn39 = 3.6 tbl32 = tbl10[num7] fn24 = tbl10[num4] tbl49 = fn24(tbl42, tbl43) fn41 = tbl32[tbl49] tbl7 = fn12(tbl38, fn39, fn41) tbl38 = tbl20() tbl10[tbl38] = tbl7 fn39 = fn16(14264512, {tbl25;
                                  num7;
                                  num4}) tbl7 = tbl20() tbl10[tbl7] = fn39 fn39 = tbl20() fn41 = fn13(7770132, {num7;
                                  num4}) tbl10[fn39] = fn41 fn41 = fn13(14243584, {tbl13, num7, num4, n;
                                  tbl16, tbl25;
                                  tbl7}) tbl32 = fn18(4415955, {fn49;
                                  num7;
                                  num4, tbl16, tbl9, fn39;
                                  tbl24, tbl21, tbl23, fn51, fn52, num6;
                                  num8;
                                  tbl15;
                                  tbl6;
                                  tbl11, tbl38;
                                  num3;
                                  tbl14, tbl12, tbl25;
                                  tbl19}) tbl16 = fn15(tbl16) num6 = fn15(num6) tbl21 = fn15(tbl21) fn39 = fn15(fn39) fn49 = fn15(fn49) tbl19 = fn15(tbl19) tbl7 = fn15(tbl7) tbl23 = fn15(tbl23) tbl11 = fn15(tbl11) tbl6 = fn15(tbl6) tbl15 = fn15(tbl15) tbl25 = fn15(tbl25) tbl13 = fn15(tbl13) num3 = fn15(num3) tbl18 = nil fn52 = fn15(fn52) fn51 = fn15(fn51) tbl24 = fn15(tbl24) n = fn15(n) tbl38 = fn15(tbl38) num8 = fn15(num8) tbl12 = fn15(tbl12) fn12 = nil tbl14 = fn15(tbl14) tbl9 = fn15(tbl9) num7 = fn15(num7) num4 = fn15(num4) fn24 = fn41(tbl32) tbl32 = nil fn41 = nil
                            else tbl9 = "\26s\221L?\6\7t" tbl24 = 25964871692 num3 = 25256440245744 tbl14 = 3155553420733 num5 = tbl10[tbl3[1]] fn53 = tbl2[1] num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) tbl11 = "\29" num7 = num5[tbl12] tbl8 = fn53[num7] num7 = tbl10[tbl3[3]] tbl24 = "\17\162m" num5 = "UDim2" num1 = tbl8 - num7 tbl8 = tbl1[num5] num7 = num1 num4 = tbl10[tbl3[1]] tbl19 = 29125462815994 tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num1 = tbl8[num5] tbl12 = tbl10[tbl3[4]] tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl16 = tbl19(tbl11, tbl14) tbl11 = 20095805662349 tbl9 = tbl24[tbl16] tbl16 = "G\194E|\205" num4 = tbl12[tbl9] tbl6 = 20317532300533 tbl9 = tbl10[tbl3[1]] fn51 = "\253" tbl24 = tbl10[tbl3[2]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num5 = num4[tbl12] tbl24 = tbl10[tbl3[4]] tbl16 = tbl10[tbl3[1]] tbl11 = tbl10[tbl3[2]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl6 = 23512304872132 tbl9 = tbl24[tbl19] tbl19 = tbl10[tbl3[1]] tbl14 = "L\215\177\1\227\208" tbl16 = tbl10[tbl3[2]] fn51 = 14262723631601 tbl11 = tbl16(tbl14, fn51) tbl14 = "{" tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl19 = tbl10[tbl3[1]] fn51 = 813358694778 tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl9 = num7[tbl24] tbl25 = "R" num4 = tbl12 + tbl9 tbl24 = tbl10[tbl3[4]] tbl16 = tbl10[tbl3[1]] fn51 = "\191" tbl11 = tbl10[tbl3[2]] tbl14 = tbl11(fn51, tbl6) fn51 = 15106593627002 tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] fn53 = nil tbl14 = "\196\8217W\8226\8217" tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl16 = tbl10[tbl3[4]] tbl14 = tbl10[tbl3[1]] fn51 = tbl10[tbl3[2]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl6 = "\7%\250\33a" tbl19 = tbl16[tbl11] tbl11 = tbl10[tbl3[1]] tbl25 = 22123281786941 tbl14 = tbl10[tbl3[2]] fn51 = tbl14(tbl6, tbl25) tbl6 = "]" tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl11 = tbl10[tbl3[1]] tbl14 = tbl10[tbl3[2]] tbl25 = 21232338495135 fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] fn51 = 29032270869711 tbl19 = num7[tbl16] tbl9 = tbl24 + tbl19 tbl8 = num1(num5, num4, tbl12, tbl9) num1 = tbl10[tbl3[5]] tbl14 = "E\24x" num4 = tbl10[tbl3[6]] num7 = nil tbl24 = "TweenInfo" tbl9 = tbl1[tbl24] num5 = tbl8 tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl8 = "Create" tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl24 = tbl10[tbl3[7]] tbl9 = tbl12(tbl24) tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl14 = "\15\212\205\251\216\8221\8250\8249" fn51 = 29737148446231 tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = {[tbl24] = num5} tbl8 = num1[tbl8] num5 = nil tbl8 = tbl8(num1, num4, tbl9, tbl12) num1 = "Play" num1 = tbl8[num1] num1 = num1(tbl8) num1 = tbl1["CGuhnCJQv7Swq"] tbl8 = {}
                            end
                          else tbl19 = tbl10[tbl3[2]] fn51 = 7156235701508 tbl14 = "\210'\8221zC\0\732\2" tbl16 = tbl10[tbl3[3]] tbl12 = num5 tbl11 = tbl16(tbl14, fn51) num1 = "IsA" tbl24 = tbl19[tbl11] num1 = tbl9[num1] num1 = num1(tbl9, tbl24) num1 = num1 and 3404667
                          end
                        end
                      end
                    end
                  end
                else
                  if num1 < 3123576 then
                    if num1 < 2673309 then
                      if num1 < 2293508 then
                        if num1 < 2248404 then
                          if num1 < 2245060 then
                            if num1 < 2177768 then
                              fn53 = tbl8 num1 = fn53 and 1367753
                            else tbl8 = "Play" num1 = tbl10[tbl3[1]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 4626195
                            end
                          else tbl17 = "tostring" fn12 = "l1" num1 = tbl1[tbl17] tbl18 = tbl1[fn12] tbl17 = num1(tbl18) num1 = "l2" tbl1[num1] = tbl17 num1 = 2988398
                          end
                        else
                          if num1 < 2272998 then
                            if num1 < 2250155 then
                              num7 = tbl10[fn53] num4 = tbl10[tbl3[1]] tbl24 = "9.f\237\186\219e" tbl12 = tbl10[tbl3[2]] tbl19 = 7668816825843 tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] tbl8 = num7[num5] num1 = not tbl8 num1 = num1 and 2751324
                            else num1 = {} tbl19 = "string" tbl12 = 35184372088832 tbl10[tbl3[2]] = num1 tbl8 = tbl10[tbl3[3]] tbl11 = 1 tbl24 = 255 num4 = tbl8 tbl8 = num7 % tbl12 tbl10[tbl3[4]] = tbl8 tbl9 = num7 % tbl24 tbl24 = 2 tbl12 = tbl9 + tbl24 tbl10[tbl3[5]] = tbl12 tbl14 = tbl11 tbl11 = 0 tbl24 = tbl1[tbl19] tbl19 = "len" tbl9 = tbl24[tbl19] tbl19 = 1 tbl24 = tbl9(fn53) tbl9 = "" num5[num7] = tbl9 fn51 = tbl14 < tbl11 tbl11 = tbl19 - tbl14 tbl9 = 123 num1 = 13173327 tbl16 = tbl24
                            end
                          else tbl8 = "pcall" num1 = tbl1[tbl8] fn53 = fn48(5178472, {tbl3[3];
                                tbl3[1], tbl3[2]}) tbl8 = num1(fn53) num1 = 9396748
                          end
                        end
                      else
                        if num1 < 2548470 then
                          if num1 < 2496046 then
                            if num1 < 2479773 then
                              num5 = "game" tbl19 = 19790911775743 num1 = tbl10[tbl3[1]] num7 = tbl1[num5] tbl16 = 22608788957472 num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl24 = "aM&\8212\n\177\206" tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] num4 = "game" tbl8 = "TeleportToPlaceInstance" tbl8 = num1[tbl8] tbl19 = "8hm\200q" num5 = tbl1[num4] tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num7 = num5[num4] tbl8 = tbl8(num1, fn53, num7) num1 = tbl1["Dc4F6HJRvqnrg"] tbl8 = {}
                            else num1 = tbl8 and 6938091
                            end
                          else num1 = 15528799 num5 = nil
                          end
                        else
                          if num1 < 2575234 then
                            if num1 < 2571679 then
                              num1 = tbl1["WtoyJ3v1ZI8eWp"] tbl8 = {} fn53 = nil
                            else fn53 = "_G" tbl9 = 23367665904257 tbl8 = tbl1[fn53] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl12 = "\168\201\162`\402S\11" num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] num1 = num1 and 8302345
                            end
                          else num1 = tbl8 and 512070
                          end
                        end
                      end
                    else
                      if num1 < 2838067 then
                        if num1 < 2752168 then
                          if num1 < 2722204 then
                            if num1 < 2675550 then
                              num5 = tbl10[tbl3[2]] tbl24 = 18658994102768 tbl9 = "\246(\192:\8224\177\206\175`,@U\129\186\8240" num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num1 = fn53[num7] num7 = "Connect" num5 = tbl10[tbl3[5]] num7 = num1[num7] num7 = num7(num1, num5) num1 = 4919113
                            else tbl8 = {} fn53 = nil num1 = tbl1["hMFwpLivu5JB31"]
                            end
                          else num1 = tbl10[tbl3[4]] tbl8 = num1() num7 = fn13(13767064, {tbl3[5], tbl3[1];
                                tbl3[2]}) tbl8 = "pcall" num1 = tbl1[tbl8] tbl8 = num1(num7) num1 = 0 num7 = num1 num1 = 3863470
                          end
                        else
                          if num1 < 2829303 then
                            if num1 < 2768573 then
                              num1 = 3277639
                            else tbl19 = "_G" tbl24 = tbl1[tbl19] tbl16 = tbl10[tbl3[2]] fn51 = "X\167\184}+j\219h\8250\202\16\172\243$\732D\181\181" tbl11 = tbl10[tbl3[3]] tbl6 = 26115485233024 tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] num1 = 14946634 tbl9 = tbl24[tbl19] num4 = tbl9
                            end
                          else num1 = tbl8 and 700416
                          end
                        end
                      else
                        if num1 < 3017997 then
                          if num1 < 3009941 then
                            if num1 < 2961490 then
                              num5 = tbl10[tbl3[6]] num7 = num5 == fn53 tbl8 = num7 num1 = 986405
                            else num1 = 12213649
                            end
                          else num8 = 2 num6 = n[num8] num8 = tbl10[tbl13] fn52 = num6 == num8 fn20 = fn52 num1 = 4912487
                          end
                        else
                          if num1 < 3116670 then
                            if num1 < 3056150 then
                              num7 = tbl10[tbl3[2]] num5 = 121 fn53 = num7 * num5 num7 = 5995079846631 tbl8 = fn53 + num7 num7 = 1 fn53 = 35184372088832 num1 = tbl8 % fn53 tbl10[tbl3[2]] = num1 fn53 = tbl10[tbl3[3]] tbl8 = fn53 ~= num7 num1 = 11398709
                            else num1 = true num1 = num1 and 13616439
                            end
                          else tbl8 = fn53 num1 = num7 num1 = 16438857
                          end
                        end
                      end
                    end
                  else
                    if num1 < 3442299 then
                      if num1 < 3357649 then
                        if num1 < 3277062 then
                          if num1 < 3210861 then
                            if num1 < 3136972 then
                              fn53 = tbl2[1] tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl19 = "\211\202\27\189\164G\193\8\183\3762\237c" tbl16 = 774190580072 tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl14 = "\381\217\8212 \27\2191f\0B\242J\247" fn51 = 32454959348489 num5 = fn53[num4] tbl24 = "Enum" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl14 = 14574375377538 tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl11 = "Jp\217\233\210|\8225\211\201\215\235\199x" tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] num7 = num5 == num4 tbl8 = num7 num1 = num7 and 422965
                            else tbl16 = true tbl19 = "SendKeyEvent" tbl17 = 32463435496204 tbl6 = "Enum" tbl24 = tbl10[tbl3[6]] tbl22 = "\242\218\141i\"7J" fn51 = tbl1[tbl6] tbl25 = tbl10[tbl3[2]] num3 = tbl10[tbl3[3]] fn14 = num3(tbl22, tbl17) tbl19 = tbl24[tbl19] tbl6 = tbl25[fn14] tbl14 = fn51[tbl6] tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] tbl22 = 19078991061684 fn14 = "_!" num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] tbl6 = "game" tbl11 = tbl14[fn51] fn51 = tbl1[tbl6] tbl22 = "\188\222\224\25\222>\245" tbl14 = false tbl19 = tbl19(tbl24, tbl16, tbl11, tbl14, fn51) tbl16 = "task" num1 = 385108 tbl19 = tbl1[tbl16] tbl11 = tbl10[tbl3[2]] tbl25 = 4753666820261 tbl14 = tbl10[tbl3[3]] tbl6 = "o\6\232u" fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl6 = "Enum" tbl24 = tbl19[tbl16] tbl16 = .05 tbl17 = 9619354292607 tbl19 = tbl24(tbl16) tbl24 = tbl10[tbl3[6]] fn51 = tbl1[tbl6] tbl16 = false tbl25 = tbl10[tbl3[2]] num3 = tbl10[tbl3[3]] fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] tbl14 = fn51[tbl6] tbl6 = tbl10[tbl3[2]] fn14 = "\235\250\198" tbl22 = 11707245008203 tbl25 = tbl10[tbl3[3]] num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] tbl11 = tbl14[fn51] tbl6 = "game" tbl14 = false tbl19 = "SendKeyEvent" fn51 = tbl1[tbl6] tbl19 = tbl24[tbl19] tbl19 = tbl19(tbl24, tbl16, tbl11, tbl14, fn51) tbl25 = 3808272418541 tbl16 = "task" tbl19 = tbl1[tbl16] tbl11 = tbl10[tbl3[2]] tbl6 = "\182\180\227C" tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl16 = 0.5 tbl19 = tbl24(tbl16)
                            end
                          else tbl8 = num7 num1 = num5 num1 = 7462204
                          end
                        else
                          if num1 < 3316188 then
                            if num1 < 3302100 then
                              num1 = true num1 = num1 and 6730575
                            else num1 = tbl10[tbl3[3]] tbl8 = num1(fn53) num1 = 6985983
                            end
                          else tbl24 = tbl10[fn53] tbl16 = tbl10[tbl3[1]] fn51 = "-\170\27\n%\8249]" tbl6 = 15906659933423 tbl11 = tbl10[tbl3[2]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] tbl12 = not tbl9 num5 = tbl12 num1 = 6703006
                          end
                        end
                      else
                        if num1 < 3406356 then
                          if num1 < 3398564 then
                            if num1 < 3374702 then
                              tbl19 = "\168F\180\210:\12\28Y\8226" num7 = tbl2[2] num5 = tbl2[3] tbl8 = tbl10[tbl3[1]] tbl16 = 3856980641540 tbl12 = tbl10[tbl3[2]] fn53 = tbl2[1] tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num1 = tbl8[num4] num1 = num1 and 6570451
                            else fn53 = tbl10[tbl3[1]] tbl8 = # fn53 fn53 = 0 num1 = tbl8 == fn53 num1 = num1 and 3035552
                            end
                          else tbl24 = tbl10[tbl3[2]] tbl11 = ">'#%X\157|C\200 " tbl19 = tbl10[tbl3[3]] tbl14 = 8713314062297 tbl16 = tbl19(tbl11, tbl14) num1 = tbl24[tbl16] tbl24 = false tbl9[num1] = tbl24 num1 = 1588601
                          end
                        else
                          if num1 < 3437988 then
                            if num1 < 3419359 then
                              tbl8 = "_G" fn53 = tbl2[1] num1 = tbl1[tbl8] tbl12 = "C\180\210W\11\226\8230\219\5:G\402\191\186)j\7\r" num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl9 = 29193005135130 num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = fn53 num1[tbl8] = num7 num1 = fn53 and 3687666
                            else tbl19 = "_G" tbl24 = tbl1[tbl19] tbl16 = tbl10[tbl3[2]] tbl6 = 6776823352403 tbl11 = tbl10[tbl3[3]] fn51 = "\157\203\12<\31\8212s\249\218L(" tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] num1 = tbl9 and 1680831
                            end
                          else tbl8 = 1 fn53 = 100 num7 = fn53 fn53 = 1 num5 = fn53 fn53 = 0 num1 = 7488383 num4 = num5 < fn53 fn53 = tbl8 - num5
                          end
                        end
                      end
                    else
                      if num1 < 3516632 then
                        if num1 < 3480431 then
                          if num1 < 3479232 then
                            if num1 < 3451275 then
                              tbl8 = "Destroy" num1 = tbl10[tbl3[1]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 3617850
                            else tbl11 = "YH\176~\732\0\8220\239\8225|\402\218" num5 = num1 tbl9 = "_G" tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[1]] tbl14 = 9730750730675 tbl19 = tbl10[tbl3[2]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] num7 = num4 num1 = num4 and 5346630
                            end
                          else fn51 = "\141h3\185\25zA\376\245\"o\190" tbl12 = num1 tbl6 = 10885587194828 tbl19 = "_G" tbl24 = tbl1[tbl19] tbl16 = tbl10[tbl3[1]] tbl11 = tbl10[tbl3[2]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] num4 = tbl9 num1 = tbl9 and 4293338
                          end
                        else
                          if num1 < 3515713 then
                            if num1 < 3510559 then
                              num5, tbl9 = num4(num7, num5) num1 = num5 and 6555426
                            else num7 = num1 num4 = "request" num5 = tbl1[num4] num1 = num5 and 6842619 fn53 = num5
                            end
                          else num1 = tbl1["JjnszxLDIQO7O"] tbl8 = {} fn53 = nil
                          end
                        end
                      else
                        if num1 < 3590432 then
                          if num1 < 3546251 then
                            if num1 < 3517724 then
                              fn51 = 30834326648854 tbl24 = "game" tbl14 = "QY\338a\199\199\228" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl11 = "@\163-U\24w)\338\232\8250\246" tbl24 = tbl10[tbl3[1]] tbl14 = 19619611681712 tbl19 = tbl10[tbl3[2]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] tbl9 = tbl10[tbl3[1]] tbl16 = "\186j\14W\8220c\241Wh" tbl11 = 33203775519845 tbl24 = tbl10[tbl3[2]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num5 = num4[tbl12] tbl9 = tbl10[tbl3[1]] tbl11 = 27431326347749 tbl16 = "S\252\203\180\220\20\169$q\376\239\0E\22xm" tbl24 = tbl10[tbl3[2]] num1 = 3118410 tbl19 = tbl24(tbl16, tbl11) num4 = "FindFirstChild" num4 = num5[num4] tbl12 = tbl9[tbl19] num4 = num4(num5, tbl12) fn53 = num4
                            else num1 = tbl10[tbl3[2]] tbl8 = "Toggle" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 8480933
                            end
                          else fn51 = tbl10[tbl3[2]] tbl17 = 14364774193697 tbl6 = tbl10[tbl3[3]] num3 = "^$\237\198" fn14 = 3414542124598 tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] num1 = tbl16[tbl14] tbl25 = tbl10[tbl3[2]] num3 = tbl10[tbl3[3]] tbl18 = 26037897490268 tbl22 = "\167\242E@\8216" fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] tbl28 = 4717604194452 tbl17 = "\213Gk\8221\19\246\235U\214$`Xz" fn12 = 20398375396634 num3 = tbl10[tbl3[2]] fn14 = tbl10[tbl3[3]] tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl14 = "Section" tbl18 = "\195\211>\164LW" tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] fn33 = "\175_\166\218\232\382\222\177 \208fX\255\191\11\182 \22\28" fn14 = true fn51 = {[tbl6] = tbl25, [num3] = fn14} tbl18 = 9518528827728 tbl14 = num1[tbl14] tbl17 = 16342786825658 tbl22 = "\210\230!\182\193" tbl14 = tbl14(num1, fn51) tbl25 = tbl10[tbl3[2]] num3 = tbl10[tbl3[3]] fn14 = num3(tbl22, tbl17) tbl17 = "q\216\12\8217)\2\237\214\184=`\242r" num4 = nil tbl6 = tbl25[fn14] num3 = tbl10[tbl3[2]] fn14 = tbl10[tbl3[3]] tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] tbl18 = "Ec\210\236QJ\"W" fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl32 = "<\1904Z\181\197.\732~\241\376\18\127\172_\198" num1 = "Toggle" fn12 = 10772241322904 num1 = tbl14[num1] tbl17 = tbl22(tbl18, fn12) value1 = 33161215556689 tbl18 = 4230077482929 num3 = fn14[tbl17] tbl17 = 1165223330334 fn14 = fn11(488189, {tbl3[2];
                                tbl3[3], tbl3[11]}) fn12 = 22692127598918 fn51 = {[tbl6] = tbl25, [num3] = fn14} num1 = num1(tbl14, fn51) tbl25 = tbl10[tbl3[2]] tbl22 = "C\183\215\223!" num3 = tbl10[tbl3[3]] fn14 = num3(tbl22, tbl17) tbl17 = "\232I\246`\160\195\8249\255\8364\174\233\8249\164\8250" tbl6 = tbl25[fn14] num3 = tbl10[tbl3[2]] fn14 = tbl10[tbl3[3]] tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] fn14 = tbl10[tbl3[2]] fn22 = "\163\353]\161`\222\382\17ep\20:\227\247\129<" num1 = "Toggle" tbl7 = 10212032123539 tbl22 = tbl10[tbl3[3]] fn49 = 24683403439334 tbl18 = "9C\7\8482\402)\25\206" tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] fn14 = fn17(11235108, {tbl3[2], tbl3[3];
                                tbl3[12]}) num1 = tbl14[num1] fn51 = {[tbl6] = tbl25;
                              [num3] = fn14} tbl18 = 13047532672955 num1 = num1(tbl14, fn51) fn12 = 27505368887816 tbl5 = 31615773817218 num1 = "Toggle" tbl22 = "i\204\237\174\8220" tbl25 = tbl10[tbl3[2]] tbl17 = 25052382637457 num3 = tbl10[tbl3[3]] num1 = tbl14[num1] fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] num3 = tbl10[tbl3[2]] fn14 = tbl10[tbl3[3]] tbl17 = "\8216\28\29/\17%\235\183)\216\201\192" tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] fn14 = tbl10[tbl3[2]] tbl36 = 11059785683998 tbl22 = tbl10[tbl3[3]] tbl18 = "\240\8217\243=\186+\161H" tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] fn14 = fn48(12469887, {tbl3[2];
                                tbl3[3], tbl3[12]}) fn51 = {[tbl6] = tbl25;
                              [num3] = fn14} tbl22 = "\207,\21\216\22" tbl18 = 23246743464521 num1 = num1(tbl14, fn51) tbl17 = 5565440346655 fn12 = 28552160457711 tbl25 = tbl10[tbl3[2]] tbl21 = 16829777108636 fn20 = "\8250\176\251" num3 = tbl10[tbl3[3]] num1 = "Toggle" fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] num3 = tbl10[tbl3[2]] tbl17 = "\235\173\197\21\231?\1814\201\222\161\176RB)#" fn14 = tbl10[tbl3[3]] tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] tbl18 = "7q\224e\"\189\8\248" fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] fn14 = fn48(3410069, {tbl3[2];
                                tbl3[3], tbl3[12]}) fn51 = {[tbl6] = tbl25, [num3] = fn14} num1 = tbl14[num1] num1 = num1(tbl14, fn51) fn12 = 1054709826027 num1 = fn10(3372728, {tbl3[7], tbl3[2];
                                tbl3[3], tbl3[13]}) tbl17 = 33455772908763 tbl22 = "hW\8230\219b\8226\8211\177" fn51 = tbl20() tbl18 = "TmK\8230\191" tbl10[fn51] = num1 tbl25 = tbl10[tbl3[2]] num3 = tbl10[tbl3[3]] fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] num1 = tbl16[tbl6] fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl49 = "\221\15F\176{\11\338\169\160\226\8240\248b\240U\249" tbl17 = tbl22(tbl18, fn12) fn12 = "\240\190\8250\8212\t\224\221\235\8212\169\208\710K\250U\213<l3" num3 = fn14[tbl17] tbl6 = "Section" tbl6 = num1[tbl6] tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] fn12 = 12636174997244 tbl25 = {[num3] = fn14} tbl5 = 27092607316295 tbl18 = "q\tx\0\203" tbl6 = tbl6(num1, tbl25) fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] tbl22 = tbl10[tbl3[2]] fn12 = "\185\15\12z\224\190\12\11\238bp\8249\\\21" tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) num1 = "Button" num1 = tbl6[num1] tbl5 = "\8212\402Q@p\239\250\195" fn14 = tbl22[tbl18] tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] tbl26 = 14024724765058 num8 = "H'g\8211\253t*\206\235\338\8\218\185?\237'9\218\141" fn12 = tbl18(tbl5, tbl21) tbl5 = 1426764038808 tbl22 = tbl17[fn12] fn12 = 28978961822902 tbl18 = "18%\229\8220" tbl17 = fn16(12537317, {fn51}) tbl25 = {[num3] = fn14, [tbl22] = tbl17} num1 = num1(tbl6, tbl25) fn14 = tbl10[tbl3[2]] num1 = "Button" tbl22 = tbl10[tbl3[3]] tbl21 = 27602018431541 tbl17 = tbl22(tbl18, fn12) tbl44 = 31554084485477 num3 = fn14[tbl17] tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] fn12 = "\25\30I\186\8222\"]\229Uz'" tbl18 = tbl17(fn12, tbl5) num1 = tbl6[num1] fn14 = tbl22[tbl18] fn35 = 90095337513 fn32 = "\232Y\224\12\8\18\173\208\8249&z\165C\8220\191m\161\217\29\217\237f\239\338\210" tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] tbl5 = "\177p\214\244@\127\170G" fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl21 = 31832095914470 tbl17 = fn17(7935281, {fn51}) tbl25 = {[num3] = fn14, [tbl22] = tbl17} fn12 = 2425043551337 num1 = num1(tbl6, tbl25) fn19 = 23527868721868 fn14 = tbl10[tbl3[2]] tbl18 = "\8364\8225\6\194l" tbl22 = tbl10[tbl3[3]] num1 = "Button" tbl5 = 2591987385526 tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] fn12 = "\29\178\177LN\175\208J\8217VG" tbl13 = "\243\82303" tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl5 = "\352Ki\217\nG\234#" tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] num1 = tbl6[num1] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl17 = fn13(13879440, {fn51}) tbl18 = "QP\220\167\6" tbl25 = {[num3] = fn14, [tbl22] = tbl17} fn12 = 25117171150256 num1 = num1(tbl6, tbl25) fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) tbl5 = 328709259417 tbl21 = 14768161069788 fn12 = "\206\195g\710\190o\188m\181\225\1684\t\205" num3 = fn14[tbl17] tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) tbl5 = "9\255=A\239%m$" fn14 = tbl22[tbl18] tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl17 = fn18(14475907, {fn51}) fn12 = 14985181698882 num1 = "Button" tbl25 = {[num3] = fn14;
                              [tbl22] = tbl17} tbl18 = "\190\28G\8249s" num1 = tbl6[num1] num1 = num1(tbl6, tbl25) fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) tbl5 = 13376241932372 num3 = fn14[tbl17] fn12 = "\157\129\17\180\200\177!\3 \178" tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl17 = tbl10[tbl3[2]] num1 = "Button" tbl18 = tbl10[tbl3[3]] tbl5 = "\8212\402\234e\211Fc\207" tbl21 = 7089157852389 fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] num1 = tbl6[num1] fn12 = 22274647550084 tbl17 = fn13(4379428, {fn51}) tbl25 = {[num3] = fn14;
                              [tbl22] = tbl17} fn26 = "\376\8221\226\247\162o$\225\8218\8212" num1 = num1(tbl6, tbl25) tbl5 = 14634158103198 fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] num2 = 30830704654356 tbl18 = "\8212E\239\732\8225" tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] tbl22 = tbl10[tbl3[2]] num1 = "Button" tbl17 = tbl10[tbl3[3]] fn12 = "p\174J\237\17\242w\214\382\164" tbl18 = tbl17(fn12, tbl5) tbl21 = 12654598215428 fn14 = tbl22[tbl18] tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] tbl5 = "`Gd\202\221\207(\172" fn12 = tbl18(tbl5, tbl21) num1 = tbl6[num1] tbl22 = tbl17[fn12] tbl17 = fn16(9389160, {fn51}) tbl25 = {[num3] = fn14;
                              [tbl22] = tbl17} tbl18 = "a\217]\2279" fn12 = 10337018909389 num1 = num1(tbl6, tbl25) fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) fn12 = "\243k\29p\5\230y\251\241p\228/" tbl5 = 8001946455694 num3 = fn14[tbl17] num1 = "Button" tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl5 = "\247\19\8221u6'\232\216" tbl21 = 6663231245342 tbl17 = tbl10[tbl3[2]] num1 = tbl6[num1] tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl21 = 10520211886882 tbl22 = tbl17[fn12] tbl17 = fn48(7527952, {fn51}) tbl25 = {[num3] = fn14, [tbl22] = tbl17} num1 = num1(tbl6, tbl25) tbl18 = "\190\189C\8364\22" fn12 = 14239281437158 tbl5 = 15443237444631 fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] fn34 = "9+\144\194\8482\210\1444\8225L;5Z\18\25\184" fn12 = "R=\8224\184\189\171^\253" tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) tbl5 = "0\211s\22AYn\8216" fn14 = tbl22[tbl18] tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] num1 = "Button" fn12 = tbl18(tbl5, tbl21) num1 = tbl6[num1] tbl22 = tbl17[fn12] fn12 = 23349218568824 fn42 = "^\8225\381R\227t\8225\245\177\15\28:]\216)\212\170\8225\18" tbl17 = fn18(12703537, {fn51}) tbl25 = {[num3] = fn14;
                              [tbl22] = tbl17} num1 = num1(tbl6, tbl25) tbl21 = 17249087070048 fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl18 = "\187|;\218\199" tbl45 = 5141953366362 tbl17 = tbl22(tbl18, fn12) tbl5 = 30308964906785 num3 = fn14[tbl17] fn12 = "\172P\n\376\191\23(\190R\225" tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] num1 = "Button" num1 = tbl6[num1] tbl5 = "9\21W\5\238\188^R" tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl17 = fn17(4639584, {fn51}) tbl25 = {[num3] = fn14;
                              [tbl22] = tbl17} tbl17 = ">W\204\239\202'\228\168" tbl48 = 26472365977639 num1 = num1(tbl6, tbl25) fn12 = "y\8224\179\195D" num3 = tbl10[tbl3[2]] fn14 = tbl10[tbl3[3]] tbl18 = 16366078156229 tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] num1 = tbl16[tbl25] tbl21 = 18303796896075 tbl5 = 28580365726716 tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] value3 = 12340290901618 tbl17 = tbl10[tbl3[2]] num6 = 19243237384 tbl5 = "\8226OK\179\208s\195n\212ac\14M;\8222OJ\247H?S\\\8217\8222" tbl18 = tbl10[tbl3[3]] tbl25 = "Section" fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] num3 = {[fn14] = tbl22} fn12 = "\233@~,\143" tbl25 = num1[tbl25] tbl25 = tbl25(num1, num3) tbl22 = tbl10[tbl3[2]] tbl5 = 12797479868231 tbl17 = tbl10[tbl3[3]] num1 = "Button" tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl5 = "|2\210p\18\28m\1737\203R\143X\127\28|\235Nkz" tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] tbl21 = 6032168618744 fn12 = tbl18(tbl5, tbl21) tbl21 = "\214\246?g+\144Gq" tbl22 = tbl17[fn12] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) num1 = tbl25[num1] fn52 = "\82215\236\129\8249\26:\230" tbl17 = tbl18[tbl5] tbl41 = 2135811605474 tbl18 = fn48(4665003, {fn51}) num3 = {[fn14] = tbl22;
                              [tbl17] = tbl18} num1 = num1(tbl25, num3) num1 = "Button" tbl5 = 29627256993252 tbl22 = tbl10[tbl3[2]] fn27 = "i\227P\213\238\198~w\338\165\226\6\8217`\8224\8220\352\8220D:^" fn12 = "\2125\2079p" tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl21 = 35011130458031 tbl17 = tbl10[tbl3[2]] num1 = tbl25[num1] tbl5 = "H\1\226\0\174\235\235J]\14&mG\237" tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl7 = 11638796162347 tbl21 = "\165\250\22\228\8230\8482'<" n = 18836358472259 tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] tbl18 = fn18(12135426, {fn51}) tbl7 = 14230783547874 num3 = {[fn14] = tbl22, [tbl17] = tbl18} num1 = num1(tbl25, num3) tbl21 = 2251801904152 tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] fn12 = "XvO\2422" tbl5 = 22044903319577 tbl18 = tbl17(fn12, tbl5) tbl5 = "S|\382\157\253\212`\192\172\27\227c\8226" fn14 = tbl22[tbl18] tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] num1 = "Button" fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl21 = "\186\252?;n\26\209\248" tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) num1 = tbl25[num1] fn12 = "\161\253\8211\8224~" tbl17 = tbl18[tbl5] tbl18 = fn18(1333305, {fn51}) num3 = {[fn14] = tbl22, [tbl17] = tbl18} tbl5 = 18692627145216 num1 = num1(tbl25, num3) num1 = "Button" tbl7 = 14559492807291 tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl5 = ">\\\8226\8220s\376\220n\192|ug\247\220k" tbl17 = tbl10[tbl3[2]] tbl21 = 27368973054408 tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl21 = "\171\24\8217V\178\230Os" tbl22 = tbl17[fn12] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] num1 = tbl25[num1] tbl18 = fn16(15406973, {fn51}) num3 = {[fn14] = tbl22;
                              [tbl17] = tbl18} num1 = num1(tbl25, num3) num1 = "Button" tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl21 = 7169782648074 tbl5 = 33460788215005 fn12 = "JO\227\8222L" fn24 = 31711078889902 tbl18 = tbl17(fn12, tbl5) tbl50 = 1360041329273 fn14 = tbl22[tbl18] tbl17 = tbl10[tbl3[2]] tbl5 = "zx}\227\18\207:gmCD" tbl18 = tbl10[tbl3[3]] num1 = tbl25[num1] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl7 = 27935734739664 tbl21 = "\215\170\195\t\16Mq1" tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] tbl18 = fn13(4809547, {fn51}) fn12 = "\246(\710\8222\216" num3 = {[fn14] = tbl22, [tbl17] = tbl18} num1 = num1(tbl25, num3) tbl5 = 5365573978562 tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl21 = 29444430214543 tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl17 = tbl10[tbl3[2]] tbl5 = "\8217{!\208e\231!\233u\"" tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl7 = 7385520737647 tbl22 = tbl17[fn12] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl21 = "\8\250\211\8224\8482ICV" num1 = "Button" tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] tbl18 = fn13(11561552, {fn51}) fn12 = 18020172193991 num1 = tbl25[num1] tbl5 = "y:$\r<" num3 = {[fn14] = tbl22, [tbl17] = tbl18} num1 = num1(tbl25, num3) tbl18 = "\193s\t\31" fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] fn44 = "\202!\223\216:d\191b\17\168\710\175" tbl21 = 4597077018716 tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] num1 = tbl16[num3] tbl17 = tbl10[tbl3[2]] tbl7 = 15387467209725 tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl21 = "8\189\213\237,\192\15\376\382\189" tbl22 = tbl17[fn12] num3 = "Input" tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl7 = "\212\212*\235\167q\8217" tbl17 = tbl18[tbl5] tbl30 = 30981209045082 fn12 = tbl10[tbl3[2]] tbl5 = tbl10[tbl3[3]] tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] tbl21 = tbl10[tbl3[2]] fn12 = 16 tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] fn49 = tbl10[tbl3[2]] tbl13 = tbl10[tbl3[3]] n = tbl13(fn20, num2) tbl7 = fn49[n] fn49 = 400 n = tbl10[tbl3[2]] fn20 = tbl10[tbl3[3]] num2 = fn20(fn52, num6) num3 = num1[num3] tbl21 = 16 tbl13 = n[num2] n = fn48(9545495, {tbl3[7], tbl3[2], tbl3[3]}) fn14 = {[tbl22] = tbl17;
                              [tbl18] = fn12;
                              [tbl5] = tbl21;
                              [tbl7] = fn49, [tbl13] = n} tbl7 = 387755114676 fn49 = 980390871496 tbl18 = "m\r\20~" num3 = num3(num1, fn14) fn12 = 23367283108481 tbl5 = "T\247~\253\212" fn14 = tbl10[tbl3[2]] tbl21 = 19351291077427 tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] num1 = tbl16[num3] tbl17 = tbl10[tbl3[2]] num3 = "Toggle" tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl18 = tbl10[tbl3[2]] tbl21 = "\214\29\338\170\193\382\8217K" fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl7 = "s$\241\184\382\217\250\8" tbl17 = tbl18[tbl5] fn12 = tbl10[tbl3[2]] tbl5 = tbl10[tbl3[3]] tbl13 = 29812956427834 tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] fn12 = fn11(15103760, {tbl3[14], tbl24}) num3 = num1[num3] tbl5 = ">\180\178\252\196" tbl7 = 30607647864748 fn14 = {[tbl22] = tbl17, [tbl18] = fn12} tbl21 = 10599787238215 fn49 = 25210218065371 num3 = num3(num1, fn14) fn12 = 25383459712556 tbl18 = "+%S\r" fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] num1 = tbl16[num3] tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] num3 = "Toggle" fn12 = tbl18(tbl5, tbl21) tbl21 = "\8221v\8220\200D\8249" tbl22 = tbl17[fn12] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl43 = "\227\183`\8211z\255.BH_\214\7\249 \0" tbl17 = tbl18[tbl5] fn12 = tbl10[tbl3[2]] num3 = num1[num3] tbl5 = tbl10[tbl3[3]] tbl7 = "Q\224\172F\21\4\210\243" tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] fn12 = fn13(5082337, {tbl3[14];
                                tbl19}) fn14 = {[tbl22] = tbl17;
                              [tbl18] = fn12} fn49 = 1284994859606 tbl21 = 17468179095494 fn12 = 22238583400563 tbl18 = "\174\191\241\224" num3 = num3(num1, fn14) fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) tbl12 = nil tbl5 = "\230\8230\242\8225\196" num3 = fn14[tbl17] num1 = tbl16[num3] tbl7 = 27462019969524 tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl18 = tbl10[tbl3[2]] tbl21 = "\143MZ\338[v{\248Ne\239J\237" fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] fn25 = "=,O^\t\170.jO7\21d" fn12 = tbl10[tbl3[2]] tbl5 = tbl10[tbl3[3]] tbl7 = "\15\185.\163\225\220\199>" tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] fn12 = fn16(6668024, {tbl3[14];
                                tbl3[2], tbl3[3]}) num3 = "Toggle" fn14 = {[tbl22] = tbl17;
                              [tbl18] = fn12} num3 = num1[num3] num3 = num3(num1, fn14) fn14 = tbl10[tbl3[2]] fn12 = 19646620918716 tbl21 = 15844487666898 tbl22 = tbl10[tbl3[3]] tbl18 = "\240\8218\25u" tbl5 = "z`\252\8220\170" tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] fn49 = 26816403583175 num1 = tbl16[num3] tbl7 = 34437222350500 tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl21 = "\194\204\732S\163s\230UT\209\242IZ" tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] num3 = "Toggle" n = 27466954977782 fn12 = tbl10[tbl3[2]] tbl7 = "\"\214u\3\2100V\227" num2 = 17778051620950 tbl5 = tbl10[tbl3[3]] tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] fn53 = nil fn12 = fn48(6140818, {tbl3[14];
                                tbl3[2];
                                tbl3[3]}) num3 = num1[num3] fn14 = {[tbl22] = tbl17, [tbl18] = fn12} fn12 = ":>\237~" num3 = num3(num1, fn14) num1 = fn13(6137273, {tbl3[2];
                                tbl3[3];
                                num7}) num3 = tbl20() tbl5 = 29425201313158 tbl10[num3] = num1 tbl22 = tbl10[tbl3[2]] fn20 = 18381486776687 tbl21 = "\228x-\200;" tbl17 = tbl10[tbl3[3]] fn52 = 27963848094429 tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] fn49 = 1953015153549 num1 = tbl16[fn14] tbl7 = 4509641033779 tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] fn12 = tbl10[tbl3[2]] tbl7 = "\169\219\180\237\208\8225[\175p\\\193ya\1845\253" tbl5 = tbl10[tbl3[3]] tbl21 = tbl5(tbl7, fn49) fn49 = "\20a\169T&\247l\161" tbl18 = fn12[tbl21] tbl5 = tbl10[tbl3[2]] tbl27 = 21034729023043 tbl21 = tbl10[tbl3[3]] tbl37 = 10481339355920 tbl7 = tbl21(fn49, tbl13) fn49 = 913307681193 fn14 = "Button" fn12 = tbl5[tbl7] tbl5 = fn47(34456, {tbl3[2], tbl3[3], num3}) fn14 = num1[fn14] tbl7 = 5228371560834 tbl22 = {[tbl17] = tbl18, [fn12] = tbl5} fn14 = fn14(num1, tbl22) tbl22 = tbl10[tbl3[2]] tbl13 = 17362320826260 tbl5 = 27336474866105 tbl17 = tbl10[tbl3[3]] fn12 = "\169}\166\239\188=\213" tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] num1 = tbl16[fn14] tbl18 = tbl10[tbl3[2]] tbl21 = "o\255Y\246," fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl7 = "\8218\144=\212\18\8249\210\180\173}\"" tbl17 = tbl18[tbl5] fn12 = tbl10[tbl3[2]] tbl5 = tbl10[tbl3[3]] tbl21 = tbl5(tbl7, fn49) fn49 = "\215o\223>N\1732\228%\194\198" tbl46 = "\235\169\217\01\353\22oR\27\144\165\198\157\8364)<\235\2068\193" tbl18 = fn12[tbl21] tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl13 = "\8230\732\234\252=\248?" tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] n = "Q\173\202S\203\19\228\27" tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) fn14 = "Input" fn14 = num1[fn14] tbl21 = tbl7[tbl13] tbl7 = fn11(3797199, {tbl3[2], tbl3[3]}) tbl22 = {[tbl17] = tbl18, [fn12] = tbl5;
                              [tbl21] = tbl7} fn14 = fn14(num1, tbl22) tbl22 = tbl10[tbl3[2]] tbl13 = 9412065399070 tbl5 = 28751949837388 fn49 = 29286589625669 tbl51 = 10477256971022 tbl17 = tbl10[tbl3[3]] fn12 = "`j\242\189\8240o+" tbl21 = "\197\3\2159M" tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl7 = 19357920912182 num1 = tbl16[fn14] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl31 = 33071120219175 tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] fn12 = tbl10[tbl3[2]] tbl5 = tbl10[tbl3[3]] tbl7 = "\242\244\254\8222\127\8221\2284\231\211R\171" fn14 = "Button" tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] tbl5 = tbl10[tbl3[2]] fn49 = "\11\8217\22\180\710\250\2\3" tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl5 = fn17(8410288, {tbl3[2];
                                tbl3[3];
                                tbl3[15], tbl3[7]}) n = "\207\216\161\8225@\3381\174" value2 = "\20 \230vD\179v?h\246l\162W\161\129\382\732\8240=\176D" tbl22 = {[tbl17] = tbl18, [fn12] = tbl5} fn14 = num1[fn14] fn14 = fn14(num1, tbl22) fn12 = "\28\183\214\8364H\14\8221[" tbl5 = 4606275749984 tbl22 = tbl10[tbl3[2]] fn20 = 29075703608547 tbl39 = 19327322776359 tbl7 = 29218747708710 tbl21 = "%$\206\239V" tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] num1 = tbl16[fn14] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) fn49 = 27461773455859 tbl17 = tbl18[tbl5] tbl7 = "7O\221\27\199\2360\181~\168s\338\28Z\1\244]u" fn12 = tbl10[tbl3[2]] fn14 = "Section" tbl5 = tbl10[tbl3[3]] fn14 = num1[fn14] tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] fn21 = "\210\174=\234|\8482\376n\1603Q\212\339\220~L\177`96C\",\8212ZDa" tbl22 = {[tbl17] = tbl18} fn14 = fn14(num1, tbl22) fn49 = 32951805361136 tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl7 = 23847332031328 fn12 = "3Qf\173'\252\191\225" tbl5 = 6559290903534 tbl29 = 26873819918562 tbl21 = "<\12\161\8482b" tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] num1 = tbl16[fn14] tbl18 = tbl10[tbl3[2]] fn14 = "Toggle" fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] fn12 = tbl10[tbl3[2]] tbl7 = "H\20\172pl\15%\176n\223\171\6\26S\141\219" tbl5 = tbl10[tbl3[3]] fn14 = num1[fn14] tbl21 = tbl5(tbl7, fn49) fn49 = "\219=p\208\246\189\217" tbl18 = fn12[tbl21] tbl5 = tbl10[tbl3[2]] tbl25 = nil tbl21 = tbl10[tbl3[3]] tbl13 = 33895765786023 tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl7 = tbl10[tbl3[2]] tbl5 = true fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] tbl7 = fn13(4729762, {tbl3[1]}) tbl13 = 17062227713801 tbl22 = {[tbl17] = tbl18, [fn12] = tbl5;
                              [tbl21] = tbl7} fn14 = fn14(num1, tbl22) tbl22 = tbl10[tbl3[2]] tbl5 = 33865113042329 tbl7 = 16073714507068 fn12 = "\215\214\191v\224I(\250" tbl17 = tbl10[tbl3[3]] n = 25713683214021 tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] num1 = tbl16[fn14] tbl21 = "[9\253\15" tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl7 = "1\215\1749\144+\243\8224=U?ph\381w" tbl17 = tbl18[tbl5] fn49 = 21358286481113 fn12 = tbl10[tbl3[2]] tbl5 = tbl10[tbl3[3]] tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] tbl5 = tbl10[tbl3[2]] tbl38 = 34782918164293 fn20 = 14925864213286 fn49 = "\8220&\212m\175\160\198\219{%\7" tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) tbl13 = "\243\5\239m\208(\160" fn12 = tbl5[tbl7] tbl21 = tbl10[tbl3[2]] fn41 = 30869460596774 tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] n = "\187c\233\208\234IVd" tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] tbl7 = fn48(13076189, {tbl3[1];
                                tbl3[2], tbl3[3]}) tbl22 = {[tbl17] = tbl18, [fn12] = tbl5, [tbl21] = tbl7} fn14 = "Input" fn14 = num1[fn14] tbl21 = 24337929612357 fn14 = fn14(num1, tbl22) fn23 = "\166\214FQ\246`\376fQ\219Tn\193U\376" tbl22 = "Instance" tbl5 = "q&\229" fn14 = tbl1[tbl22] tbl7 = 5550149732888 tbl17 = tbl10[tbl3[2]] n = 12360860423803 tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] num1 = fn14[tbl22] tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] tbl5 = "\8249\203\161\234\382Nmq\205" tbl21 = 19846547694617 fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl17 = tbl10[tbl3[4]] fn14 = num1(tbl22, tbl17) tbl17 = "Instance" tbl21 = "D\193\160" tbl22 = tbl20() tbl10[tbl22] = fn14 fn14 = tbl1[tbl17] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl7 = 7161473240326 tbl17 = tbl18[tbl5] num1 = fn14[tbl17] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl21 = "\204`\n\236\174" tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] tbl18 = tbl10[tbl22] tbl7 = 7891370987098 fn14 = num1(tbl17, tbl18) tbl17 = tbl20() tbl21 = "$C\174_" tbl13 = "\235\"\237" fn36 = "\253rF\233\1752\352\220L1\201\192a6\26\5h@\222\"" tbl10[tbl17] = fn14 num1 = tbl10[tbl17] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] tbl5 = "UDim2" fn12 = tbl1[tbl5] tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] tbl18 = fn12[tbl5] fn49 = 0 tbl21 = 0 tbl7 = 1 n = 18574790697417 tbl5 = 1 fn12 = tbl18(tbl5, tbl21, tbl7, fn49) fn37 = "j(\247\16/\161\382\20\199NI\352\217\3\732>c\15v[6J\174o\212" num1[fn14] = fn12 num1 = tbl10[tbl17] tbl13 = "1a\204" tbl21 = "\8\240xX\160\195\235\211\173a\177\225\8249\178\235=" tbl18 = tbl10[tbl3[2]] tbl7 = 5966387923674 fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] tbl5 = "Color3" fn12 = tbl1[tbl5] tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl7 = 1 tbl5 = tbl21[fn49] tbl18 = fn12[tbl5] tbl21 = 1 tbl5 = 1 fn12 = tbl18(tbl5, tbl21, tbl7) num1[fn14] = fn12 tbl7 = 9660737720722 num1 = tbl10[tbl17] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl21 = "RcF\213\196\8216\182" tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] tbl7 = 955768766909 tbl18 = false tbl13 = 16286140112287 tbl21 = "\8212`\178\143m\219" num1[fn14] = tbl18 num1 = tbl10[tbl17] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl40 = 21381966063332 tbl5 = fn12(tbl21, tbl7) tbl7 = 6211466087244 fn14 = tbl18[tbl5] n = 22960320440771 tbl21 = "\21\n;7\197\20\181\3" tbl18 = 999999 tbl33 = 14792168479464 num1[fn14] = tbl18 tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] num1 = tbl16[fn14] fn20 = 39388069906 num6 = 10074564285011 tbl5 = tbl10[tbl3[2]] fn49 = "\3058\16$e" tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] fn14 = "Section" tbl13 = "\21\180\255\23\196\229\8216\232\205\8222\8217\255\165" tbl21 = tbl10[tbl3[2]] fn14 = num1[fn14] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] tbl21 = "\178\6X\198@\24\18#" tbl7 = 6005012466412 fn49 = "T\222\253\167\162" tbl18 = {[fn12] = tbl5} fn14 = fn14(num1, tbl18) tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] fn29 = "\176\254\233\15tK\2\143o)\27\164U4|" n = 27566596190756 tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] num1 = tbl16[fn14] tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl13 = 4053900429151 tbl7 = tbl21(fn49, tbl13) fn14 = "Toggle" tbl13 = "]\31\143\20\r,\7\234\8\1967\198" fn12 = tbl5[tbl7] fn14 = num1[fn14] tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] n = "6\31\141\218G\164\239\352" tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] tbl7 = fn11(7366442, {tbl17, tbl3[2];
                                tbl3[3]}) tbl18 = {[fn12] = tbl5, [tbl21] = tbl7} tbl7 = 34125887110675 fn14 = fn14(num1, tbl18) tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] fn49 = "\168\191j\179\165" tbl21 = "64-N\17\14ww\31" tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] num1 = tbl16[fn14] tbl5 = tbl10[tbl3[2]] fn38 = "QP\21\241Z\353\213\710[\225\182\202\187\237j\255\195\26\129\182\180\164" tbl21 = tbl10[tbl3[3]] tbl13 = 23886720117619 tbl7 = tbl21(fn49, tbl13) fn14 = "Input" fn12 = tbl5[tbl7] tbl13 = "\191;f\213H\339\241\247o@\128\237\207\241\2327s" tbl21 = tbl10[tbl3[2]] n = 29283107157316 tbl7 = tbl10[tbl3[3]] fn14 = num1[fn14] fn49 = tbl7(tbl13, n) n = "\2279a\209\230\171\8211QxK\214" tbl5 = tbl21[fn49] tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] fn30 = "\14\202c\28Y5\2='\253\182\141\182\338" fn39 = "\tbXm^u\246\249\242\200\8212\161" fn20 = 32837280791483 tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] fn49 = tbl10[tbl3[2]] fn20 = "\187U\188\8218o\167\207\251" tbl13 = tbl10[tbl3[3]] n = tbl13(fn20, num2) num2 = "\8218N\180\162\8230T(\172" tbl7 = fn49[n] tbl13 = tbl10[tbl3[2]] n = tbl10[tbl3[3]] fn20 = n(num2, fn52) tbl47 = 29397490447737 fn49 = tbl13[fn20] fn51 = fn15(fn51) tbl13 = fn18(14642982, {tbl3[2];
                                tbl3[3]}) tbl18 = {[fn12] = tbl5;
                              [tbl21] = tbl7, [fn49] = tbl13} tbl21 = "\0\228\191,2\t\5\233" fn14 = fn14(num1, tbl18) tbl18 = tbl10[tbl3[2]] fn49 = "h\19\246\183O" tbl7 = 3951965996848 fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] num1 = tbl16[fn14] tbl13 = 9841703719398 tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) tbl13 = "\31\1947\210\8212\6o\252" n = 4255934302141 fn12 = tbl5[tbl7] tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] tbl18 = {[fn12] = tbl5} fn49 = "\205\210>o\182" fn14 = "Section" fn14 = num1[fn14] tbl13 = 11077480240166 fn14 = fn14(num1, tbl18) tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl21 = "](\231\255{4\8222\248" tbl7 = 18877830210134 tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] num1 = tbl16[fn14] tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) num2 = "\191j\230\250\8221\22w\8250" tbl13 = "?a\18yq}\218\129\141\208\8221\30\192\192\229\195D.%\5\1927\238" n = 24071835036617 fn12 = tbl5[tbl7] tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) n = "\189p\181\207\195\193\212" tbl5 = tbl21[fn49] fn20 = 8031387717275 tbl7 = tbl10[tbl3[2]] fn52 = 30924027934784 fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl15 = "\16+\8212\200\14Ob\4cq\225\8217\160\203\251=\20\r\232" tbl21 = tbl7[tbl13] tbl7 = true tbl13 = tbl10[tbl3[2]] n = tbl10[tbl3[3]] fn20 = n(num2, fn52) fn49 = tbl13[fn20] fn14 = "Toggle" num2 = "\8224#\250\8226F\204\24\221" tbl13 = fn11(13562993, {tbl3[2], tbl3[3]}) tbl18 = {[fn12] = tbl5, [tbl21] = tbl7;
                              [fn49] = tbl13} fn14 = num1[fn14] tbl7 = 15192860957602 fn14 = fn14(num1, tbl18) fn20 = 21159248881277 tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl13 = 3631026816666 tbl21 = "\170^\165T\224ZF\338" tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] num1 = tbl16[fn14] tbl5 = tbl10[tbl3[2]] fn49 = "\23\180\191\161\5" tbl21 = tbl10[tbl3[3]] n = 6798473088093 tbl7 = tbl21(fn49, tbl13) fn31 = "\20D\5a\255aT\171 \172[iH6u\184\202\196" fn52 = 22205817530468 fn12 = tbl5[tbl7] tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] tbl13 = "\219!\24\246o+t\218" fn14 = "Toggle" fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] tbl7 = tbl10[tbl3[2]] n = "\238\2\1\402|\161\20" fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] tbl7 = true tbl13 = tbl10[tbl3[2]] n = tbl10[tbl3[3]] fn20 = n(num2, fn52) fn49 = tbl13[fn20] tbl13 = fn13(10278077, {tbl3[2], tbl3[3]}) fn14 = num1[fn14] fn20 = 2273190102050 tbl18 = {[fn12] = tbl5, [tbl21] = tbl7;
                              [fn49] = tbl13} n = 32745350937488 fn14 = fn14(num1, tbl18) tbl21 = "\230\29\127\338\8250h\7323" tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl7 = 22115017664570 tbl13 = 28417283617712 fn49 = "]X\15\207v" tbl5 = fn12(tbl21, tbl7) fn43 = "\29w`@\190z\157w\129\26\382$Wz#\217" fn14 = tbl18[tbl5] num1 = tbl16[fn14] tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl21 = tbl10[tbl3[2]] tbl13 = "5h\168\179\227G\252\1733X\29|" fn14 = "Section" fn14 = num1[fn14] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] tbl18 = {[fn12] = tbl5} fn49 = "\222!E\160=" fn14 = fn14(num1, tbl18) tbl18 = tbl10[tbl3[2]] tbl21 = "Z\8218P\2384\209\352Y" tbl7 = 9890966000125 fn12 = tbl10[tbl3[3]] tbl13 = 34422296084125 tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] num1 = tbl16[fn14] n = 1614879277807 tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] tbl13 = "%|\8225\"\21,\226\8240\338h\254\201n,\28\23" fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] n = "\222\31n\179LR\180;" tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] n = 27229288214919 tbl7 = fn13(14648810, {tbl3[2], tbl3[3]}) fn14 = "Toggle" fn14 = num1[fn14] tbl13 = 23164032182818 tbl18 = {[fn12] = tbl5, [tbl21] = tbl7} fn49 = "\"d66XO" tbl7 = 1214705107509 fn14 = fn14(num1, tbl18) tbl18 = tbl10[tbl3[2]] tbl21 = "-\208\206\183x\162q|" tbl8 = {} fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] num1 = tbl16[fn14] fn20 = 34051985898992 tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl13 = "\11t\7324\"\r{\225<" tbl34 = 34005125692890 tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) n = "rgL\189\r\8250\28\239" fn14 = "Button" tbl5 = tbl21[fn49] tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] tbl7 = fn17(14803473, {tbl3[2];
                                tbl3[3]}) tbl18 = {[fn12] = tbl5;
                              [tbl21] = tbl7} tbl21 = "u)#=\216I\190\204" fn14 = num1[fn14] fn14 = fn14(num1, tbl18) tbl18 = tbl10[tbl3[2]] tbl7 = 29850467939916 fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl23 = 5563204389406 fn49 = "#\n\168\19\244" fn14 = tbl18[tbl5] num1 = tbl16[fn14] tbl13 = 16850171305638 tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] n = 28587507905536 fn14 = "Button" tbl7 = tbl21(fn49, tbl13) fn20 = 5743576074866 fn12 = tbl5[tbl7] tbl13 = "\11\8\157\r\176\8230\n\237\191\216" tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) fn14 = num1[fn14] tbl5 = tbl21[fn49] tbl7 = tbl10[tbl3[2]] n = "\240$\220P\226\219\180\31" fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] tbl7 = fn48(803318, {tbl3[15];
                                tbl3[2], tbl3[3];
                                tbl3[16]}) fn49 = "\168`.\212\353" tbl18 = {[fn12] = tbl5, [tbl21] = tbl7} fn14 = fn14(num1, tbl18) tbl21 = "A\216\195\8222j+\197l" tbl18 = tbl10[tbl3[2]] fn20 = 34608244948723 fn12 = tbl10[tbl3[3]] tbl7 = 24717278932213 tbl13 = 20552987780450 n = 20993909679664 tbl5 = fn12(tbl21, tbl7) fn14 = tbl18[tbl5] num1 = tbl16[fn14] tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) tbl13 = "\196E\25k{{" fn12 = tbl5[tbl7] tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] n = "\194\172\226\27i\127\160\24" tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] tbl7 = fn13(2404443, {tbl3[16], tbl3[2];
                                tbl3[3]}) n = 20554970015075 tbl18 = {[fn12] = tbl5;
                              [tbl21] = tbl7} fn14 = "Button" fn20 = 2911768053067 fn14 = num1[fn14] tbl21 = "sZ\179\249\171\212T\381" tbl7 = 1697062945558 fn14 = fn14(num1, tbl18) tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] num2 = 7546497142202 tbl5 = fn12(tbl21, tbl7) fn49 = "\162DH\205H" fn14 = tbl18[tbl5] num1 = tbl16[fn14] tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl35 = 31010909141096 tbl13 = 19068223840943 fn14 = "Toggle" fn14 = num1[fn14] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl13 = "81\7\228\245V\196-\224h\202" tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] n = "\169\8220D\181\208t:\20" tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) n = 32608650361680 tbl21 = tbl7[tbl13] tbl7 = fn48(10164211, {tbl3[2];
                                tbl3[3]}) tbl18 = {[fn12] = tbl5;
                              [tbl21] = tbl7} fn20 = 14373618833957 fn14 = fn14(num1, tbl18) tbl7 = 1779381846844 tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl21 = "\\L}\187\187\167v]" tbl5 = fn12(tbl21, tbl7) fn49 = "E'\254G\254" fn14 = tbl18[tbl5] tbl13 = 12805595617099 num1 = tbl16[fn14] tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl13 = "\192\"\194\207\28\78w\245\8230" tbl21 = tbl10[tbl3[2]] fn14 = "Button" tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) fn14 = num1[fn14] tbl5 = tbl21[fn49] tbl7 = tbl10[tbl3[2]] n = "\243R\352\338f&}\15" fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) fn49 = "\20Q\229\710\203\184z" tbl21 = tbl7[tbl13] tbl7 = fn17(4812117, {tbl3[17];
                                tbl3[1], tbl22;
                                num7}) tbl18 = {[fn12] = tbl5;
                              [tbl21] = tbl7} fn14 = fn14(num1, tbl18) num1 = fn13(9003559, {num5;
                                tbl3[7];
                                tbl3[2];
                                tbl3[3], tbl3[18]}) fn14 = tbl20() num3 = fn15(num3) tbl13 = 1952299205517 tbl10[fn14] = num1 tbl18 = tbl10[tbl3[19]] tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] fn20 = 26096363171704 tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] num1 = tbl18[fn12] tbl42 = 29746735150619 tbl18 = "Connect" tbl18 = num1[tbl18] fn12 = fn16(7187870, {tbl3[7], tbl3[2];
                                tbl3[3], tbl24, tbl9;
                                tbl19}) tbl18 = tbl18(num1, fn12) tbl5 = tbl10[tbl3[10]] tbl7 = tbl10[tbl3[2]] n = "Pv\240\191\8218\222" fn49 = tbl10[tbl3[3]] tbl6 = nil tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] fn12 = tbl5[tbl21] tbl13 = "\235\163h\7\255d\23OxH1\352\8221\141\229\218\8218Q\184\8364\252" tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] n = 8933287989311 fn49 = tbl7(tbl13, n) tbl13 = 26066246692714 tbl5 = tbl21[fn49] tbl18 = fn12[tbl5] fn49 = "\8221\179\183\202d\170)\2008k\241@0" n = 35154672009202 tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] num1 = tbl18[fn12] tbl18 = "Connect" tbl18 = num1[tbl18] fn12 = fn11(12729617, {tbl3[2], tbl3[3];
                                tbl3[10]}) tbl18 = tbl18(num1, fn12) fn12 = tbl10[tbl3[2]] fn49 = 8347891814191 tbl7 = "{\12y\241\222\210\16\178\236\255\31?\161\210}\225\28\203n" tbl5 = tbl10[tbl3[3]] tbl21 = tbl5(tbl7, fn49) tbl13 = "\8212$1\230R\8222\16\201\179\217\8216\8224B2;" tbl18 = fn12[tbl21] fn12 = true fn20 = "\339\220h#U\201\186g\235\339{>" tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] fn49 = tbl10[tbl3[2]] tbl13 = tbl10[tbl3[3]] fn52 = "\184]\186\168\222*W\250\19\8221~\15M\204n\166n\r" n = tbl13(fn20, num2) tbl21 = true tbl7 = fn49[n] fn49 = true n = tbl10[tbl3[2]] fn20 = tbl10[tbl3[3]] num2 = fn20(fn52, num6) tbl13 = n[num2] num2 = tbl10[tbl3[2]] n = true fn52 = tbl10[tbl3[3]] fn28 = "\30\8222\1\180,\243\181\216\228\160\19\6\24\192f\191\166O\179" num6 = fn52(num8, tbl23) fn20 = num2[num6] num6 = tbl10[tbl3[2]] num2 = true fn40 = "\168\229F\173\207\232\19<D1\226\218\206\28" num8 = tbl10[tbl3[3]] tbl23 = num8(tbl15, tbl38) fn52 = num6[tbl23] num6 = true tbl23 = tbl10[tbl3[2]] tbl15 = tbl10[tbl3[3]] tbl38 = tbl15(fn39, fn41) num8 = tbl23[tbl38] tbl23 = true tbl38 = tbl10[tbl3[2]] fn39 = tbl10[tbl3[3]] fn41 = fn39(tbl32, fn24) tbl15 = tbl38[fn41] tbl38 = true fn41 = tbl10[tbl3[2]] tbl32 = tbl10[tbl3[3]] fn24 = tbl32(tbl49, tbl42) fn39 = fn41[fn24] fn24 = tbl10[tbl3[2]] tbl49 = tbl10[tbl3[3]] fn41 = true tbl42 = tbl49(tbl43, fn19) tbl32 = fn24[tbl42] fn24 = true tbl42 = tbl10[tbl3[2]] tbl43 = tbl10[tbl3[3]] fn19 = tbl43(tbl46, fn35) tbl49 = tbl42[fn19] tbl43 = 20252166202582 tbl42 = true num1 = {[tbl18] = fn12;
                              [tbl5] = tbl21;
                              [tbl7] = fn49, [tbl13] = n;
                              [fn20] = num2;
                              [fn52] = num6;
                              [num8] = tbl23;
                              [tbl15] = tbl38, [fn39] = fn41, [tbl32] = fn24, [tbl49] = tbl42} tbl18 = tbl20() fn39 = 29340175136094 tbl13 = 26489933967407 n = "A\24\18\248_\8216\5j\5q\184Zf\165c\212\166\141N" tbl10[tbl18] = num1 tbl22 = fn15(tbl22) tbl5 = tbl10[tbl3[2]] fn20 = 28991872464060 fn52 = 1077762130421 tbl21 = tbl10[tbl3[3]] fn24 = "\172\210\187\141\\" num8 = 2422379529320 fn19 = "7\n\196\8224\8212\8217g\247|!\193F)N\213\229" fn49 = "\184\175<\2\168\8226X\221t\225\710\144\216\174" tbl24 = fn15(tbl24) tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl7 = tbl10[tbl3[2]] num2 = "<K\1756.\8250\352\8224\14\236\189\226\n" tbl5 = true tbl38 = "\176\252[d\243\244\235\171O\179\8249\180'Sz\252" num6 = "\338\14\235\164\237\12\2F\376\214\353\234\193" fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] tbl13 = tbl10[tbl3[2]] tbl7 = true n = tbl10[tbl3[3]] fn20 = n(num2, fn52) fn49 = tbl13[fn20] fn20 = tbl10[tbl3[2]] tbl13 = true num2 = tbl10[tbl3[3]] fn52 = num2(num6, num8) tbl46 = 18511903236524 tbl16 = nil tbl49 = 30500091475834 fn41 = "\141ZM\207\198\199\732\182\197\8224E" n = fn20[fn52] fn20 = true fn52 = tbl10[tbl3[2]] tbl15 = 21786777413537 tbl23 = "\710\8224\238\0\164\25\5\244.\402ju" num6 = tbl10[tbl3[3]] tbl32 = 9578615247212 num8 = num6(tbl23, tbl15) num2 = fn52[num8] fn52 = true num8 = tbl10[tbl3[2]] tbl23 = tbl10[tbl3[3]] tbl15 = tbl23(tbl38, fn39) num6 = num8[tbl15] num8 = true tbl15 = tbl10[tbl3[2]] tbl38 = tbl10[tbl3[3]] fn39 = tbl38(fn41, tbl32) tbl23 = tbl15[fn39] fn39 = tbl10[tbl3[2]] fn41 = tbl10[tbl3[3]] tbl15 = true tbl32 = fn41(fn24, tbl49) tbl38 = fn39[tbl32] tbl42 = "\231\199p\186V\163H~\191.\nt\209F\234\8217\165\\" tbl32 = tbl10[tbl3[2]] fn39 = true fn24 = tbl10[tbl3[3]] tbl49 = fn24(tbl42, tbl43) fn41 = tbl32[tbl49] tbl32 = true tbl49 = tbl10[tbl3[2]] tbl42 = tbl10[tbl3[3]] tbl43 = tbl42(fn19, tbl46) fn24 = tbl49[tbl43] tbl43 = tbl10[tbl3[2]] fn19 = tbl10[tbl3[3]] fn35 = "\339I\241 \223\177(\162R\223D+O\170&wh~" tbl46 = fn19(fn35, tbl40) tbl49 = true tbl42 = tbl43[tbl46] tbl46 = tbl10[tbl3[2]] tbl43 = true fn35 = tbl10[tbl3[3]] tbl40 = fn35(fn21, tbl37) fn19 = tbl46[tbl40] tbl46 = true tbl40 = tbl10[tbl3[2]] fn21 = tbl10[tbl3[3]] tbl37 = fn21(fn40, tbl47) fn35 = tbl40[tbl37] tbl37 = tbl10[tbl3[2]] tbl40 = true fn40 = tbl10[tbl3[3]] tbl47 = fn40(fn30, tbl36) fn21 = tbl37[tbl47] tbl47 = tbl10[tbl3[2]] fn30 = tbl10[tbl3[3]] tbl37 = true tbl36 = fn30(fn32, tbl45) fn40 = tbl47[tbl36] tbl36 = tbl10[tbl3[2]] tbl47 = true fn32 = tbl10[tbl3[3]] tbl45 = fn32(fn27, tbl26) fn30 = tbl36[tbl45] tbl36 = true tbl45 = tbl10[tbl3[2]] fn27 = tbl10[tbl3[3]] tbl26 = fn27(fn37, tbl41) fn32 = tbl45[tbl26] tbl45 = true tbl26 = tbl10[tbl3[2]] fn37 = tbl10[tbl3[3]] tbl41 = fn37(fn38, tbl44) fn27 = tbl26[tbl41] tbl26 = true tbl41 = tbl10[tbl3[2]] fn38 = tbl10[tbl3[3]] tbl44 = fn38(fn43, tbl35) fn37 = tbl41[tbl44] tbl44 = tbl10[tbl3[2]] tbl41 = true fn43 = tbl10[tbl3[3]] tbl35 = fn43(fn28, tbl39) fn38 = tbl44[tbl35] tbl35 = tbl10[tbl3[2]] tbl44 = true fn28 = tbl10[tbl3[3]] tbl39 = fn28(fn26, tbl28) fn43 = tbl35[tbl39] tbl39 = tbl10[tbl3[2]] fn26 = tbl10[tbl3[3]] tbl35 = true tbl28 = fn26(fn42, tbl30) fn28 = tbl39[tbl28] tbl39 = true tbl28 = tbl10[tbl3[2]] fn42 = tbl10[tbl3[3]] tbl30 = fn42(fn29, tbl29) fn26 = tbl28[tbl30] tbl30 = tbl10[tbl3[2]] fn29 = tbl10[tbl3[3]] tbl29 = fn29(fn25, tbl33) fn42 = tbl30[tbl29] tbl30 = true tbl28 = true tbl29 = tbl10[tbl3[2]] fn25 = tbl10[tbl3[3]] tbl33 = fn25(fn31, tbl50) fn29 = tbl29[tbl33] tbl29 = true tbl33 = tbl10[tbl3[2]] fn31 = tbl10[tbl3[3]] tbl50 = fn31(fn36, tbl48) fn25 = tbl33[tbl50] tbl33 = true tbl50 = tbl10[tbl3[2]] fn36 = tbl10[tbl3[3]] tbl48 = fn36(fn33, tbl51) fn31 = tbl50[tbl48] tbl48 = tbl10[tbl3[2]] fn33 = tbl10[tbl3[3]] tbl51 = fn33(fn44, tbl31) tbl50 = true tbl19 = fn15(tbl19) fn36 = tbl48[tbl51] tbl51 = tbl10[tbl3[2]] fn44 = tbl10[tbl3[3]] tbl31 = fn44(fn34, tbl27) tbl48 = true fn33 = tbl51[tbl31] tbl51 = true tbl31 = tbl10[tbl3[2]] fn34 = tbl10[tbl3[3]] tbl27 = fn34(fn22, tbl34) fn44 = tbl31[tbl27] tbl27 = tbl10[tbl3[2]] fn22 = tbl10[tbl3[3]] tbl34 = fn22(fn23, value1) tbl31 = true fn34 = tbl27[tbl34] tbl27 = true tbl34 = tbl10[tbl3[2]] fn23 = tbl10[tbl3[3]] value1 = fn23(value2, value3) fn22 = tbl34[value1] tbl34 = true num1 = {[fn12] = tbl5, [tbl21] = tbl7;
                              [fn49] = tbl13;
                              [n] = fn20;
                              [num2] = fn52, [num6] = num8, [tbl23] = tbl15;
                              [tbl38] = fn39, [fn41] = tbl32, [fn24] = tbl49;
                              [tbl42] = tbl43;
                              [fn19] = tbl46, [fn35] = tbl40;
                              [fn21] = tbl37, [fn40] = tbl47;
                              [fn30] = tbl36, [fn32] = tbl45, [fn27] = tbl26, [fn37] = tbl41, [fn38] = tbl44;
                              [fn43] = tbl35;
                              [fn28] = tbl39;
                              [fn26] = tbl28;
                              [fn42] = tbl30, [fn29] = tbl29, [fn25] = tbl33, [fn31] = tbl50, [fn36] = tbl48;
                              [fn33] = tbl51;
                              [fn44] = tbl31;
                              [fn34] = tbl27, [fn22] = tbl34} n = "\166-$\7\2" tbl21 = "task" fn12 = tbl20() tbl10[fn12] = num1 tbl5 = tbl1[tbl21] tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] fn20 = 27812626051735 tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] n = "Y\163\241l\199" fn20 = 24382024739929 num1 = tbl5[tbl21] tbl21 = fn17(11176703, {tbl3[2];
                                tbl3[3], tbl3[7];
                                fn14;
                                tbl3[10], tbl18;
                                fn12, tbl3[18]}) tbl5 = num1(tbl21) tbl21 = "task" tbl5 = tbl1[tbl21] tbl23 = 34482828787385 tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] fn20 = 21207755138707 num1 = tbl5[tbl21] tbl21 = fn17(2767024, {tbl3[2], tbl3[3], tbl3[10]}) n = "\8220\8224&\230d" tbl5 = num1(tbl21) tbl21 = "task" tbl5 = tbl1[tbl21] tbl7 = tbl10[tbl3[2]] num6 = 6125744868132 fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] num1 = tbl5[tbl21] tbl21 = fn13(4529879, {tbl3[2], tbl3[3], tbl3[10]}) n = "\165\245\205x\11" fn20 = 18597873361364 tbl5 = num1(tbl21) tbl21 = "task" tbl5 = tbl1[tbl21] tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] num1 = tbl5[tbl21] tbl21 = fn47(7142216, {tbl3[2];
                                tbl3[3];
                                tbl3[20];
                                tbl3[7]}) num2 = 23075209013753 tbl5 = num1(tbl21) tbl21 = "game" tbl5 = tbl1[tbl21] tbl21 = "GetService" fn20 = "\8Z\23\7\233#\8\28\3387\732\339\187\17c\176" fn49 = tbl10[tbl3[2]] tbl13 = tbl10[tbl3[3]] n = tbl13(fn20, num2) tbl7 = fn49[n] tbl21 = tbl5[tbl21] tbl21 = tbl21(tbl5, tbl7) tbl7 = tbl10[tbl3[2]] fn20 = 26116677349249 n = "\193-\184wV\167\12\2427\162\18" fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl5 = tbl7[tbl13] num1 = tbl21[tbl5] tbl21 = fn17(2575066, {tbl3[2], tbl3[3]}) fn24 = 20530795177304 tbl5 = "Connect" tbl5 = num1[tbl5] num2 = 4043395270490 tbl5 = tbl5(num1, tbl21) tbl21 = "game" fn20 = "J\8212A\732\8240\179\178\3533\193" tbl5 = tbl1[tbl21] tbl21 = "GetService" fn49 = tbl10[tbl3[2]] tbl15 = 7387450412400 tbl13 = tbl10[tbl3[3]] n = tbl13(fn20, num2) tbl21 = tbl5[tbl21] tbl7 = fn49[n] n = ")\16\187E\18Y\24" fn20 = 12119674754571 tbl11 = nil tbl21 = tbl21(tbl5, tbl7) tbl7 = tbl10[tbl3[2]] num2 = 20069840790657 fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) fn12 = fn15(fn12) fn20 = "90\11b" tbl5 = tbl7[tbl13] num1 = tbl21[tbl5] tbl5 = "Connect" tbl13 = 25182448577998 tbl5 = num1[tbl5] fn49 = "\228\228\r\205\212\2108J\8225\254\206\8211\127\18\198\216\252\219\162\215a\219\402M\186jy" tbl21 = fn47(9853488, {tbl3[2], tbl3[3]}) tbl5 = tbl5(num1, tbl21) tbl17 = fn15(tbl17) tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) num1 = tbl5[tbl7] tbl5 = num1 fn14 = fn15(fn14) tbl7 = "Instance" tbl21 = tbl1[tbl7] fn49 = tbl10[tbl3[2]] fn52 = 843869979016 tbl13 = tbl10[tbl3[3]] num8 = "\22\213<\2\8482u~" n = tbl13(fn20, num2) num2 = 26376441589754 tbl7 = fn49[n] num1 = tbl21[tbl7] fn49 = tbl10[tbl3[2]] tbl13 = tbl10[tbl3[3]] fn20 = " \234\183&b\8249#\18k" n = tbl13(fn20, num2) tbl14 = nil tbl7 = fn49[n] fn20 = 11107170210868 fn49 = tbl10[tbl3[4]] num2 = 15901925121260 tbl21 = num1(tbl7, fn49) tbl7 = tbl10[tbl3[2]] n = "\7Y\199\8249" fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) num1 = tbl7[tbl13] fn49 = tbl10[tbl3[2]] tbl13 = tbl10[tbl3[3]] fn20 = "\222'\29'>\353\215~\245\234e?\22\141\232\255\206\219" n = tbl13(fn20, num2) num2 = "e\203&" tbl7 = fn49[n] tbl21[num1] = tbl7 tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] fn20 = 3194772571599 n = "S\199\14\208\166;46\17\25_\216" tbl13 = fn49(n, fn20) num1 = tbl7[tbl13] fn49 = "Instance" tbl7 = false tbl21[num1] = tbl7 tbl7 = tbl1[fn49] tbl13 = tbl10[tbl3[2]] n = tbl10[tbl3[3]] fn20 = n(num2, fn52) num2 = "\185-<\8249\8482[I\127Wx0" fn49 = tbl13[fn20] num1 = tbl7[fn49] tbl13 = tbl10[tbl3[2]] fn52 = 24443081550966 n = tbl10[tbl3[3]] fn20 = n(num2, fn52) fn49 = tbl13[fn20] fn52 = 33795349020025 num2 = "W\175P_" tbl7 = num1(fn49) fn49 = tbl20() tbl10[fn49] = tbl7 num1 = tbl10[fn49] tbl13 = tbl10[tbl3[2]] n = tbl10[tbl3[3]] fn20 = n(num2, fn52) tbl7 = tbl13[fn20] n = tbl10[tbl3[2]] fn20 = tbl10[tbl3[3]] fn52 = "C\242'\214\175\8225\2\210\26=" num2 = fn20(fn52, num6) tbl13 = n[num2] num1[tbl7] = tbl13 num1 = tbl10[fn49] fn52 = 3775830623966 tbl13 = tbl10[tbl3[2]] num2 = "\8250\169\141\2463\127" n = tbl10[tbl3[3]] fn20 = n(num2, fn52) tbl7 = tbl13[fn20] fn52 = 7613866659289 tbl13 = tbl21 num1[tbl7] = tbl13 num1 = tbl10[fn49] tbl13 = tbl10[tbl3[2]] num2 = "n\8216zm\226w\tB\2\338\169\24\222\200\190N" n = tbl10[tbl3[3]] fn20 = n(num2, fn52) tbl7 = tbl13[fn20] fn20 = "Color3" n = tbl1[fn20] num2 = tbl10[tbl3[2]] fn52 = tbl10[tbl3[3]] num6 = fn52(num8, tbl23) tbl23 = 4800050202811 fn20 = num2[num6] fn52 = 30 tbl13 = n[fn20] num2 = 10 fn20 = 5 n = tbl13(fn20, num2, fn52) fn52 = 9225257062599 num1[tbl7] = n num5 = fn15(num5) num2 = "\79\189a\186\8249I@" num1 = tbl10[fn49] tbl13 = tbl10[tbl3[2]] n = tbl10[tbl3[3]] fn20 = n(num2, fn52) tbl7 = tbl13[fn20] fn20 = "UDim2" n = tbl1[fn20] num2 = tbl10[tbl3[2]] fn52 = tbl10[tbl3[3]] num8 = "\223RL" num6 = fn52(num8, tbl23) fn20 = num2[num6] tbl13 = n[fn20] num6 = -30 num2 = 20 num8 = "\2374\251" fn52 = 0.5 fn20 = 0 n = tbl13(fn20, num2, fn52, num6) num1[tbl7] = n num1 = tbl10[fn49] num2 = "\217Y.B" tbl32 = "\229Bf\353\t\223b\211\1699" tbl13 = tbl10[tbl3[2]] n = tbl10[tbl3[3]] fn52 = 24436452748403 fn20 = n(num2, fn52) tbl7 = tbl13[fn20] tbl23 = 17035695234812 fn20 = "UDim2" n = tbl1[fn20] num2 = tbl10[tbl3[2]] fn52 = tbl10[tbl3[3]] num6 = fn52(num8, tbl23) fn20 = num2[num6] fn52 = 0 num6 = 53.6 num2 = 53.6 tbl13 = n[fn20] fn20 = 0 n = tbl13(fn20, num2, fn52, num6) num1[tbl7] = n num1 = tbl10[fn49] num2 = ":\30\228\8364\222" tbl13 = tbl10[tbl3[2]] num6 = 24486208515210 n = tbl10[tbl3[3]] fn52 = 10427765052151 fn20 = n(num2, fn52) tbl7 = tbl13[fn20] tbl13 = tbl5 num1[tbl7] = tbl13 num2 = "]\166.~-\249P\173:\224\227\189\255\208\242\6" tbl21 = nil num1 = tbl10[fn49] tbl13 = tbl10[tbl3[2]] num8 = "51#Y" n = tbl10[tbl3[3]] fn52 = 17947812225189 fn20 = n(num2, fn52) tbl7 = tbl13[fn20] tbl13 = true num1[tbl7] = tbl13 fn52 = "\183G\207" tbl13 = "Instance" tbl7 = tbl1[tbl13] tbl9 = fn15(tbl9) n = tbl10[tbl3[2]] fn20 = tbl10[tbl3[3]] num2 = fn20(fn52, num6) tbl13 = n[num2] num1 = tbl7[tbl13] n = tbl10[tbl3[2]] num6 = 8391630147395 fn52 = "o\171\247h\192\176\216/" fn20 = tbl10[tbl3[3]] num2 = fn20(fn52, num6) tbl13 = n[num2] num2 = "\127\185\21\248\241r\143hw_\164%" fn52 = 19770574038006 n = tbl10[fn49] tbl23 = 6011779123951 tbl7 = num1(tbl13, n) tbl13 = tbl10[tbl3[2]] n = tbl10[tbl3[3]] fn20 = n(num2, fn52) num1 = tbl13[fn20] fn20 = "UDim" n = tbl1[fn20] num2 = tbl10[tbl3[2]] fn52 = tbl10[tbl3[3]] num6 = fn52(num8, tbl23) fn20 = num2[num6] tbl13 = n[fn20] num6 = "L:\168" num2 = 0 fn20 = 1 n = tbl13(fn20, num2) tbl7[num1] = n n = "Instance" tbl13 = tbl1[n] num8 = 10398890513130 fn20 = tbl10[tbl3[2]] num2 = tbl10[tbl3[3]] fn52 = num2(num6, num8) n = fn20[fn52] num1 = tbl13[n] fn20 = tbl10[tbl3[2]] num8 = 33713010605394 tbl23 = "\20,Y\144\240\254\t" num6 = "t\237\251Wy\8222\3763" num2 = tbl10[tbl3[3]] fn52 = num2(num6, num8) n = fn20[fn52] fn20 = tbl10[fn49] tbl5 = nil tbl13 = num1(n, fn20) fn52 = "\168\25\16'\26" num6 = 21178803906182 tbl7 = nil n = tbl10[tbl3[2]] fn20 = tbl10[tbl3[3]] num2 = fn20(fn52, num6) num1 = n[num2] num2 = "Color3" fn20 = tbl1[num2] fn52 = tbl10[tbl3[2]] num6 = tbl10[tbl3[3]] num8 = num6(tbl23, tbl15) num2 = fn52[num8] n = fn20[num2] num2 = 0 num6 = 0 fn52 = 0 fn20 = n(num2, fn52, num6) num6 = 21609430869838 tbl13[num1] = fn20 fn52 = "\0\129\178\8226\8230(\25\8220Z" n = tbl10[tbl3[2]] fn20 = tbl10[tbl3[3]] num2 = fn20(fn52, num6) num1 = n[num2] n = 1.75 tbl13[num1] = n fn52 = "S\203\8226P\189\219h\169w\144\240W" num6 = 13157476947950 n = tbl10[tbl3[2]] fn20 = tbl10[tbl3[3]] num2 = fn20(fn52, num6) fn52 = tbl20() num1 = n[num2] n = .1 tbl13[num1] = n num1 = nil num2 = nil tbl10[fn52] = num1 num6 = tbl20() fn20 = nil n = nil tbl10[num6] = n n = tbl20() tbl10[n] = fn20 fn20 = tbl20() tbl10[fn20] = num2 num2 = tbl20() num8 = tbl20() num1 = .1 tbl10[num2] = num1 num1 = fn18(2096360, {tbl3[2], tbl3[3];
                                n;
                                fn20, tbl3[21], fn49;
                                num2}) tbl10[num8] = num1 tbl23 = tbl10[fn49] tbl38 = tbl10[tbl3[2]] tbl18 = fn15(tbl18) fn39 = tbl10[tbl3[3]] tbl13 = nil fn41 = fn39(tbl32, fn24) tbl15 = tbl38[fn41] fn24 = 1416898429587 num1 = tbl23[tbl15] tbl15 = fn18(6430998, {tbl3[2];
                                tbl3[3], fn52;
                                n, fn49, fn20}) tbl32 = "\184\15H\193H\8216\251z\8482\157?\176" tbl23 = "Connect" num2 = fn15(num2) tbl23 = num1[tbl23] tbl23 = tbl23(num1, tbl15) tbl23 = tbl10[fn49] tbl38 = tbl10[tbl3[2]] fn39 = tbl10[tbl3[3]] fn41 = fn39(tbl32, fn24) tbl15 = tbl38[fn41] fn24 = 20895961130498 tbl32 = "\376!\229&\t\228S&\8217r\171[" num1 = tbl23[tbl15] tbl23 = "Connect" tbl23 = num1[tbl23] tbl15 = fn17(3136538, {tbl3[2];
                                tbl3[3];
                                num6}) tbl23 = tbl23(num1, tbl15) tbl23 = tbl10[tbl3[22]] tbl38 = tbl10[tbl3[2]] fn39 = tbl10[tbl3[3]] fn41 = fn39(tbl32, fn24) tbl15 = tbl38[fn41] tbl32 = "L[\179\382\215F\196\216AwIx\129\127s\176x" num1 = tbl23[tbl15] tbl23 = "Connect" tbl15 = fn17(13454887, {num6, fn52, num8}) tbl23 = num1[tbl23] tbl23 = tbl23(num1, tbl15) tbl23 = tbl10[fn49] fn24 = 11529210270968 fn52 = fn15(fn52) tbl38 = tbl10[tbl3[2]] fn39 = tbl10[tbl3[3]] fn49 = fn15(fn49) fn41 = fn39(tbl32, fn24) num6 = fn15(num6) tbl15 = tbl38[fn41] num1 = tbl23[tbl15] tbl15 = fn48(9863960, {tbl3[17], num7, tbl3[2], tbl3[3];
                                tbl3[4];
                                tbl3[5]}) tbl23 = "Connect" fn20 = fn15(fn20) num7 = fn15(num7) num8 = fn15(num8) tbl23 = num1[tbl23] tbl23 = tbl23(num1, tbl15) num1 = tbl1["hZk1zO0juTTz"] n = fn15(n)
                          end
                        else
                          if num1 < 3621295 then
                            if num1 < 3617690 then
                              num1 = tbl1["Xq9dake5UPvhFk"] tbl8 = {}
                            else num1 = tbl10[tbl3[2]] num1 = num1 and 968035
                            end
                          else tbl9 = nil tbl12 = nil num1 = 9061804
                          end
                        end
                      end
                    end
                  end
                end
              else
                if num1 < 5693174 then
                  if num1 < 4720835 then
                    if num1 < 4284703 then
                      if num1 < 3799792 then
                        if num1 < 3678856 then
                          if num1 < 3660152 then
                            if num1 < 3625772 then
                              fn53 = tbl10[tbl3[5]] num4 = tbl10[tbl3[3]] tbl24 = "\376x\193\r;p" tbl19 = 21709319825277 tbl12 = tbl10[tbl3[4]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num7 = "FindFirstChild" num7 = fn53[num7] num7 = num7(fn53, num5) tbl8 = num7 num1 = num7 and 5371901
                            else tbl8 = "_G" num1 = tbl1[tbl8] num7 = tbl10[tbl3[1]] tbl12 = "\200q\r<\157\230!:\174\177\241" num5 = tbl10[tbl3[2]] tbl9 = 18120437260533 num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = false num1[tbl8] = num7 tbl8 = "Play" num1 = tbl10[tbl3[3]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 1479649
                            end
                          else tbl9 = 34238977703495 tbl12 = "V\2265\22" fn53 = "task" tbl8 = tbl1[fn53] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] tbl24 = "1T8\16\141n9\208\8226" tbl19 = 14762670430938 fn53 = .1 tbl8 = num1(fn53) num7 = tbl10[tbl3[3]] num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] tbl24 = 14415031360056 tbl9 = "\8226c\249H#@\246" tbl19 = "\224\8216\195\205g\19\163??\338:" num5 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) tbl9 = 28394780734374 num7 = num5[tbl12] tbl8 = fn53[num7] tbl12 = "r\1\8\25w\29\239" num7 = tbl10[tbl3[1]] tbl16 = 24341285678150 num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] num4 = "_G" fn53 = tbl20() tbl10[fn53] = num1 num5 = tbl1[num4] tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num7 = num5[num4] tbl8 = num7 num1 = num7 and 5128182
                          end
                        else
                          if num1 < 3792746 then
                            if num1 < 3696096 then
                              tbl8 = "_G" num1 = tbl1[tbl8] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl9 = 3902262527769 tbl12 = "j\4\29\231F\141h\238\127\8225" num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = false tbl12 = "\3\176\"\166\8250\221\209\165\201\29fU" num1[tbl8] = num7 tbl8 = "_G" tbl9 = 7441290972553 num1 = tbl1[tbl8] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = false num1[tbl8] = num7 num1 = tbl10[tbl3[3]] tbl8 = "Play" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 1609143
                            else tbl8 = "pairs" num1 = tbl1[tbl8] tbl24 = "GetChildren" tbl24 = num5[tbl24] tbl9 = {tbl24(num5)} tbl24 = {num1(fn46(tbl9))} tbl8 = tbl24[1] tbl12 = tbl24[3] num4 = tbl24[2] tbl9 = tbl8 num1 = 5343417
                            end
                          else fn53 = tbl2[1] tbl8 = "_G" num1 = tbl1[tbl8] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl9 = 9639968690568 tbl12 = "\352$\245\252\r\166" num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = fn53 fn53 = nil num1[tbl8] = num7 tbl8 = {} num1 = tbl1["JS6LFYH95sTkHT"]
                          end
                        end
                      else
                        if num1 < 4056218 then
                          if num1 < 4007152 then
                            if num1 < 3941911 then
                              num4 = 7.5 num5 = num7 < num4 num1 = num5 and 10907942 tbl8 = num5
                            else tbl6 = "\196\195\241m\230W" tbl11 = tbl10[tbl3[1]] tbl24 = tbl12 num3 = 25673538711219 tbl14 = tbl10[tbl3[2]] num1 = "WaitForChild" tbl25 = 22638596417837 num1 = fn53[num1] fn51 = tbl14(tbl6, tbl25) tbl25 = "@uGF\221\163\203]\8240\177" tbl16 = tbl11[fn51] num1 = num1(fn53, tbl16) tbl14 = tbl10[tbl3[1]] fn51 = tbl10[tbl3[2]] tbl16 = "WaitForChild" tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl16 = num1[tbl16] tbl16 = tbl16(num1, tbl11) fn14 = 31368838265103 num3 = "\12\188\207\23" fn51 = tbl10[tbl3[1]] tbl6 = tbl10[tbl3[2]] tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] num3 = 12137627768340 tbl24 = nil tbl11 = tbl19[tbl14] num1 = "FireServer" num1 = tbl16[num1] tbl25 = "\20\216i\166" num1 = num1(tbl16, tbl11) tbl11 = "task" tbl16 = tbl1[tbl11] tbl14 = tbl10[tbl3[1]] tbl19 = nil fn51 = tbl10[tbl3[2]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] num1 = tbl16[tbl11] tbl11 = .2 tbl16 = num1(tbl11) num1 = 5343417
                            end
                          else num5 = "table" num7 = tbl1[num5] num5 = "remove" fn53 = num7[num5] num5 = tbl10[tbl3[1]] num1 = tbl1["MoUCkJCX3SFQt"] num7 = {fn53(num5)} tbl8 = {fn46(num7)}
                          end
                        else
                          if num1 < 4104468 then
                            if num1 < 4094802 then
                              tbl8 = "Destroy" num1 = tbl10[tbl3[2]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = tbl1["Zt6sOaHxzEsXU"] tbl8 = {}
                            else num1 = 7410641 tbl25 = num3 tbl21 = tbl25 tbl6[tbl25] = tbl21 tbl25 = nil
                            end
                          else num1 = tbl8 and 13463387
                          end
                        end
                      end
                    else
                      if num1 < 4568300 then
                        if num1 < 4480388 then
                          if num1 < 4401973 then
                            if num1 < 4346044 then
                              num7 = num4 num1 = tbl12 num1 = 1881042
                            else num1 = tbl10[tbl3[1]] fn53 = 67.43 num5 = -1296.41 num7 = 5 tbl8 = num1(fn53, num7, num5) num1 = tbl1["F6IKOoZbTuuz"] tbl8 = {}
                            end
                          else tbl8 = "Play" tbl19 = 11242999534707 tbl25 = 19290742579990 num1 = tbl10[tbl3[1]] num7 = "game" tbl8 = num1[tbl8] tbl16 = 16292535295394 tbl8 = tbl8(num1) tbl8 = "loadstring" tbl24 = "BW\179\241\22\8225~\2\7q\8217\240\236\2\141\\\161\8230\217x\20-\8211t:\166bU!\230\r/\191\171Om\223\"\164\27\182\16\199\161\8249\245\382 &.+\8225b%l\1979RS\15\222\8364\8364\2179\8222\237,\205\2392\18\211\8220,\177" num1 = tbl1[tbl8] fn53 = tbl1[num7] tbl22 = 17348553367438 tbl11 = "\25\8230\214\7\160" num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl14 = 1978816807833 tbl9 = tbl12(tbl24, tbl19) tbl24 = 26812001136837 num5 = num4[tbl9] num4 = "HttpGet" num4 = fn53[num4] num7 = {num4(fn53, num5)} fn51 = 6643357486101 tbl8 = num1(fn46(num7)) num1 = tbl8() num5 = tbl10[tbl3[2]] tbl9 = "@>I\215" num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) fn53 = num1 num1 = "CreateWindow" num7 = num5[tbl12] tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl6 = 27036585996589 tbl19 = "\t\339F\167\24D\163" tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl12 = true tbl24 = tbl10[tbl3[2]] fn14 = 31943112948250 tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl14 = "T\249\382\251\220\8224U\165G\352\710" tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl16 = tbl10[tbl3[2]] tbl11 = tbl10[tbl3[3]] fn51 = "\8212\n)\217\188\247\250#" tbl14 = tbl11(fn51, tbl6) tbl11 = 17063562026761 tbl19 = tbl16[tbl14] tbl16 = fn48(13932322, {}) num5 = {[num4] = tbl12, [tbl9] = tbl24, [tbl19] = tbl16} tbl19 = "+I\178\235&" tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl16 = 21594164094791 tbl24 = tbl9(tbl19, tbl16) fn52 = 26638312206452 fn49 = 15061200280421 tbl14 = 11098191123503 num4 = tbl12[tbl24] tbl18 = 13814508230944 tbl9 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl16 = "\8n\353\353\207}*\198\251>>" tbl19 = tbl24(tbl16, tbl11) tbl11 = " Zi}" tbl12 = tbl9[tbl19] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl16 = "UDim2" tbl7 = 30678943954893 tbl6 = "\8249L\30\236\209J\376,\238\144" tbl19 = tbl1[tbl16] tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) num3 = 31464352414011 tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl11 = 445 tbl16 = 545 tbl19 = tbl24(tbl16, tbl11) tbl16 = tbl10[tbl3[2]] tbl11 = tbl10[tbl3[3]] fn51 = "<T\222\8220\230" tbl6 = 21213122602646 tbl14 = tbl11(fn51, tbl6) tbl24 = tbl16[tbl14] tbl11 = tbl10[tbl3[2]] tbl6 = "p\225\352{" tbl17 = 1708946572059 tbl25 = 29693937595907 num6 = 19507619668859 tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl25 = "\238\25\203\231" tbl6 = fn51(tbl25, num3) num3 = "\199\8221\244I[<\226\236\200\186\176Y\162D\246\8364\227U\195\22|3#\r\208\8230\192" tbl11 = tbl14[tbl6] fn51 = tbl10[tbl3[2]] tbl6 = tbl10[tbl3[3]] tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] fn14 = "\175\220\12d\239\209\23\8217\8216\238" num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] tbl25 = tbl10[tbl3[2]] num3 = tbl10[tbl3[3]] tbl22 = "\209\199\8226d\8217\26\189\8222\8222}H\129\177\245\189\8364\241a\237\8211\28\1/\\\187\24\208m" fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] num3 = tbl10[tbl3[2]] fn12 = 10246420337315 fn14 = tbl10[tbl3[3]] tbl17 = "\241\732h\224\196\14" tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] tbl18 = "\\\8221dUP\198(\172s\175\194\191{\tN\185\200" fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] num1 = fn53[num1] tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] tbl8 = {[num7] = num5;
                              [num4] = tbl12;
                              [tbl9] = tbl19, [tbl24] = tbl16, [tbl11] = tbl14;
                              [fn51] = tbl6, [tbl25] = num3} tbl21 = 4924804024565 tbl13 = 3899488683799 num7 = tbl20() num1 = num1(fn53, tbl8) tbl16 = 24669541969119 tbl10[num7] = num1 num5 = "task" tbl8 = tbl1[num5] num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl19 = 26762619023534 tbl24 = "\200\710\194\382\8364" tbl14 = 6571675536372 tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] tbl24 = 30999915984995 num1 = tbl8[num5] num5 = fn47(7984826, {tbl3[4], tbl3[2], tbl3[3];
                                tbl3[5], tbl3[6]}) tbl8 = num1(num5) tbl8 = "_G" num1 = tbl1[tbl8] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl9 = "\rc8RN\24\172\210k\t*" num3 = 24515836521624 tbl11 = "\169" tbl18 = 22137312684100 tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] num5 = false num1[tbl8] = num5 tbl8 = "_G" tbl24 = 6523609271261 tbl9 = "_,(jI[\230%E\163'\1956\22[\188\173\243" num1 = tbl1[tbl8] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] tbl24 = 1346791277171 num5 = false fn14 = "9\243\31c" num1[tbl8] = num5 tbl8 = "_G" tbl9 = "\29\231\0.\26\200\338\202\1604R!" num1 = tbl1[tbl8] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] num5 = false num1[tbl8] = num5 tbl22 = 32660585708392 tbl24 = 18064141738203 tbl17 = 6203283884872 tbl8 = "_G" tbl9 = "\197p\183I\229Y\8230\217" num1 = tbl1[tbl8] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] num5 = false num1[tbl8] = num5 tbl8 = "_G" num1 = tbl1[tbl8] tbl24 = 11022033703948 tbl5 = 21774006773659 num5 = tbl10[tbl3[2]] tbl9 = "$}\231\177\160Zz0\r\187" fn12 = 8574404743064 num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] fn51 = "\24" tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl19 = "\244" tbl25 = "\29" tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl12 = false tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl16 = tbl10[tbl3[2]] tbl6 = 6802764123231 tbl24 = false tbl11 = tbl10[tbl3[3]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl16 = false tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl14 = false num5 = {[num4] = tbl12;
                              [tbl9] = tbl24;
                              [tbl19] = tbl16;
                              [tbl11] = tbl14} num1[tbl8] = num5 tbl9 = "\210]Y\30\167B\210,T" tbl8 = "_G" num1 = tbl1[tbl8] tbl24 = 17814675087463 num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) tbl24 = 33614765260069 tbl8 = num5[tbl12] num5 = true num1[tbl8] = num5 tbl8 = "_G" num1 = tbl1[tbl8] tbl9 = "'\26\8230\184a\82221" fn51 = "\190\732\190\127" num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl19 = 19793491895297 tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] num5 = true tbl24 = 5623999711802 tbl9 = "\231\193\14\27\196L7\254\8225\21\381\8217" num1[tbl8] = num5 tbl8 = "_G" num1 = tbl1[tbl8] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) tbl24 = "\255&\189\167" tbl8 = num5[tbl12] num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] tbl24 = tbl20() num1[tbl8] = num5 num5 = false num4 = false tbl19 = tbl20() fn20 = 24552155540648 tbl12 = false tbl8 = false num1 = 50 tbl9 = tbl20() tbl10[tbl9] = num1 tbl10[tbl24] = tbl8 num1 = false tbl10[tbl19] = num5 num5 = tbl20() tbl10[num5] = num1 tbl16 = tbl10[tbl3[2]] tbl11 = tbl10[tbl3[3]] tbl6 = 5073750640954 num2 = 28535305974759 tbl14 = tbl11(fn51, tbl6) tbl8 = tbl16[tbl14] tbl16 = tbl10[num7] tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] num3 = tbl25(fn14, tbl22) tbl22 = "\181\213\8224\15\182" fn51 = tbl6[num3] tbl25 = tbl10[tbl3[2]] num3 = tbl10[tbl3[3]] fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] tbl17 = "\252\1w\16V" num3 = tbl10[tbl3[2]] fn14 = tbl10[tbl3[3]] tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl18 = "\253B\209\226" tbl17 = tbl22(tbl18, fn12) tbl11 = "Tab" num3 = fn14[tbl17] tbl11 = tbl16[tbl11] tbl14 = {[fn51] = tbl6;
                              [tbl25] = num3} tbl11 = tbl11(tbl16, tbl14) num3 = 25494026464863 tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] fn12 = 3083970233756 tbl25 = "M\213\14\171" tbl6 = fn51(tbl25, num3) tbl17 = ",~\208]" tbl18 = 8166063181530 tbl16 = tbl14[tbl6] tbl14 = tbl10[num7] num3 = tbl10[tbl3[2]] fn14 = tbl10[tbl3[3]] tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl18 = "\242fEA" tbl17 = tbl22(tbl18, fn12) fn12 = "\177\222\2085\190" num3 = fn14[tbl17] fn51 = "Tab" tbl22 = tbl10[tbl3[2]] fn51 = tbl14[fn51] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl5 = "\221\402\165P" tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] fn12 = "\230aSy" tbl6 = {[tbl25] = num3;
                              [fn14] = tbl22} fn51 = fn51(tbl14, tbl6) tbl22 = 20432523617578 tbl5 = 23482953362103 fn14 = "\196\8482\732\220\1\8\82172" tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] num3 = tbl25(fn14, tbl22) tbl14 = tbl6[num3] tbl6 = tbl10[num7] tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl21 = 18739312255510 tbl17 = tbl10[tbl3[2]] tbl5 = "Q\3396\229a\21o\r\t\2" tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl21 = "N\200\246\241n" tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] fn12 = tbl10[tbl3[2]] n = 10383121208035 tbl7 = "+\82261\2546[\213\0" tbl5 = tbl10[tbl3[3]] tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] tbl25 = "Tab" num3 = {[fn14] = tbl22, [tbl17] = tbl18} tbl17 = "A\141E\187" tbl25 = tbl6[tbl25] tbl25 = tbl25(tbl6, num3) tbl7 = 3859511936773 num3 = tbl10[tbl3[2]] fn14 = tbl10[tbl3[3]] tbl21 = "\14\22\27D4" tbl18 = 8083944804020 tbl22 = fn14(tbl17, tbl18) fn49 = 33720194383190 tbl6 = num3[tbl22] num3 = tbl10[num7] tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) tbl17 = tbl18[tbl5] fn12 = tbl10[tbl3[2]] tbl5 = tbl10[tbl3[3]] tbl7 = "\181\249x" tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] fn14 = "Tab" tbl5 = tbl10[tbl3[2]] fn49 = "C\223D\8221\382" tbl21 = tbl10[tbl3[3]] tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl21 = tbl10[tbl3[2]] tbl13 = "\242\221\8225\164" tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) n = 21405154911983 fn14 = num3[fn14] tbl5 = tbl21[fn49] tbl22 = {[tbl17] = tbl18, [fn12] = tbl5} fn12 = "5L\218\244\732z\202" tbl13 = 21963630422003 fn14 = fn14(num3, tbl22) tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl5 = 35066985660361 tbl18 = tbl17(fn12, tbl5) tbl17 = "Tab" num3 = tbl22[tbl18] tbl22 = tbl10[num7] tbl5 = tbl10[tbl3[2]] tbl21 = tbl10[tbl3[3]] fn49 = "8\183\219%" tbl7 = tbl21(fn49, tbl13) fn12 = tbl5[tbl7] tbl17 = tbl22[tbl17] tbl13 = "5m\253\245\129!4\200\215\195\223u\14\215" tbl21 = tbl10[tbl3[2]] tbl7 = tbl10[tbl3[3]] fn49 = tbl7(tbl13, n) tbl5 = tbl21[fn49] tbl7 = tbl10[tbl3[2]] n = "I\12s\16n" fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] fn20 = "\169_u\169\8221&\8220" fn49 = tbl10[tbl3[2]] tbl13 = tbl10[tbl3[3]] n = tbl13(fn20, num2) tbl7 = fn49[n] fn20 = 13883619957057 tbl18 = {[fn12] = tbl5, [tbl21] = tbl7} tbl17 = tbl17(tbl22, tbl18) tbl21 = "\238\219>\8221`\710\127l" tbl7 = 28207919035215 num2 = 11165608957007 n = "\226\8212\23\175" tbl18 = tbl10[tbl3[2]] fn12 = tbl10[tbl3[3]] tbl5 = fn12(tbl21, tbl7) fn12 = "Tab" tbl22 = tbl18[tbl5] tbl18 = tbl10[num7] tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] fn20 = "\28\170\161\234!\15=\238" fn49 = tbl10[tbl3[2]] tbl13 = tbl10[tbl3[3]] n = tbl13(fn20, num2) num2 = "Ry\381\255_" tbl7 = fn49[n] tbl13 = tbl10[tbl3[2]] n = tbl10[tbl3[3]] fn20 = n(num2, fn52) fn52 = "\229\209'\127\252x>]" fn49 = tbl13[fn20] n = tbl10[tbl3[2]] fn20 = tbl10[tbl3[3]] num2 = fn20(fn52, num6) fn12 = tbl18[fn12] tbl13 = n[num2] tbl5 = {[tbl21] = tbl7, [fn49] = tbl13} fn12 = fn12(tbl18, tbl5) num1 = {[tbl8] = tbl11, [tbl16] = fn51;
                              [tbl14] = tbl25;
                              [tbl6] = fn14, [num3] = tbl17, [tbl22] = fn12} fn14 = 31712062847407 tbl22 = 16983833272036 n = "\225\164\191" num3 = "\18\8225\183\203\"" tbl16 = num1 tbl25 = 30959100852304 tbl6 = "\214\206\30P" tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl8 = tbl11[fn51] num1 = tbl16[tbl8] tbl17 = 1978012631961 fn51 = tbl10[tbl3[2]] tbl6 = tbl10[tbl3[3]] tbl25 = tbl6(num3, fn14) fn12 = 18665003426291 tbl18 = "\127\24V\239\220\221" tbl14 = fn51[tbl25] fn14 = "\339\24\222\215/\174\247\127\230e_\157j" tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] tbl22 = "\168\183\225\242" tbl25 = tbl10[tbl3[2]] num3 = tbl10[tbl3[3]] fn14 = num3(tbl22, tbl17) tbl7 = "\8211\5\382\248" tbl6 = tbl25[fn14] fn49 = 25558238015101 fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] tbl17 = tbl10[tbl3[7]] fn12 = tbl10[tbl3[2]] tbl5 = tbl10[tbl3[3]] tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] tbl22 = tbl17[tbl18] fn12 = tbl10[tbl3[2]] fn49 = 27472039096824 tbl7 = "\189\206\232\227\252\160D" tbl5 = tbl10[tbl3[3]] tbl8 = "Paragraph" tbl21 = tbl5(tbl7, fn49) fn20 = 26831066607822 tbl18 = fn12[tbl21] tbl8 = num1[tbl8] tbl21 = "string" tbl5 = tbl1[tbl21] tbl7 = tbl10[tbl3[2]] fn49 = tbl10[tbl3[3]] tbl13 = fn49(n, fn20) tbl21 = tbl7[tbl13] tbl7 = 1 fn12 = tbl5[tbl21] fn49 = 15 tbl21 = tbl10[tbl3[8]] tbl5 = fn12(tbl21, tbl7, fn49) tbl17 = tbl18..tbl5 fn14 = tbl22..tbl17 tbl25 = num3..fn14 tbl18 = 2360255038539 num3 = "K\144\239\219^" tbl11 = {[tbl14] = fn51, [tbl6] = tbl25} tbl22 = 31755870632387 tbl8 = tbl8(num1, tbl11) tbl6 = "(\250O#" tbl17 = 13890359777604 tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] tbl25 = 28642208265241 fn51 = tbl14(tbl6, tbl25) fn14 = 14061673781651 tbl8 = tbl11[fn51] num1 = tbl16[tbl8] fn51 = tbl10[tbl3[2]] tbl6 = tbl10[tbl3[3]] tbl8 = "Paragraph" tbl25 = tbl6(num3, fn14) fn14 = "\234.\8240\20\210O!\224#l;\251\8212\243\232" tbl14 = fn51[tbl25] tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] tbl25 = tbl10[tbl3[2]] tbl22 = "\8224\168?." num3 = tbl10[tbl3[3]] fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] num3 = tbl10[tbl3[2]] tbl8 = num1[tbl8] fn14 = tbl10[tbl3[3]] tbl17 = "\214<\218\182;\252\8249\198- bN\176g'2\248\8225\233O\1j\239\6\211\4\15\165\248\240\228\28\6\189cvt_\247z\168u[\182\352\221\176\221Bc\253\24875\12N\234\160\8226\26\23\29\20W%.I\232\175=\25\20163XP\8224\18X\2451s\210\222" tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] tbl22 = 17421455318960 tbl11 = {[tbl14] = fn51, [tbl6] = tbl25} tbl8 = tbl8(num1, tbl11) tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] tbl17 = 23394755603086 tbl25 = 15310810799065 tbl6 = "\252M\188\141" fn51 = tbl14(tbl6, tbl25) num3 = "\204Y\352,\169" tbl8 = tbl11[fn51] num1 = tbl16[tbl8] fn14 = 9384931627282 fn51 = tbl10[tbl3[2]] tbl6 = tbl10[tbl3[3]] tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] fn14 = ">\8230\31\176eY\8482b\2316p" tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] tbl21 = 23627564788474 num3 = tbl25(fn14, tbl22) tbl22 = "N\129\226\240)\18" fn51 = tbl6[num3] tbl25 = tbl10[tbl3[2]] num3 = tbl10[tbl3[3]] tbl8 = "Section" fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] tbl8 = num1[tbl8] tbl17 = "62" tbl25 = true tbl11 = {[tbl14] = fn51;
                              [tbl6] = tbl25} tbl8 = tbl8(num1, tbl11) tbl5 = 27294244286885 tbl18 = 13244443564055 tbl11 = tbl8 tbl8 = "ipairs" fn12 = 15957277596934 num1 = tbl1[tbl8] num3 = tbl10[tbl3[2]] fn14 = tbl10[tbl3[3]] tbl22 = fn14(tbl17, tbl18) tbl25 = num3[tbl22] fn14 = tbl10[tbl3[2]] tbl22 = tbl10[tbl3[3]] tbl18 = "U" tbl17 = tbl22(tbl18, fn12) num3 = fn14[tbl17] fn12 = ":" tbl22 = tbl10[tbl3[2]] tbl17 = tbl10[tbl3[3]] tbl18 = tbl17(fn12, tbl5) fn14 = tbl22[tbl18] tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] tbl5 = "'" fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] tbl6 = {tbl25;
                              num3;
                              fn14;
                              tbl22} tbl25 = {num1(tbl6)} fn51 = tbl25[3] num1 = 7535927 tbl8 = tbl25[1] tbl14 = tbl25[2] tbl6 = tbl8
                          end
                        else
                          if num1 < 4534542 then
                            if num1 < 4506927 then
                              tbl6 = "table" fn51 = tbl1[tbl6] tbl6 = "unpack" num1 = 7497857 tbl14 = fn51[tbl6] tbl16 = tbl14
                            else num1 = 14746840
                            end
                          else num1 = 2080841 tbl11 = tbl10[tbl9] tbl19 = tbl11
                          end
                        end
                      else
                        if num1 < 4629206 then
                          if num1 < 4623622 then
                            if num1 < 4607237 then
                              tbl9 = "\165\8226d\11" num1 = "FindFirstChild" num5 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl24 = 15981371055377 tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] num5 = true num1 = num7[num1] num1 = num1(num7, tbl8, num5) num5 = num1 num1 = num5 and 3791480
                            else num1 = fn53 tbl10[tbl3[2]] = num1 num1 = tbl1["qM7r3IKfHMibx"] fn53 = nil tbl8 = {}
                            end
                          else num1 = tbl10[tbl3[2]] num1 = num1 and 9145362
                          end
                        else
                          if num1 < 4683257 then
                            if num1 < 4660675 then
                              num5 = 1401.47 num7 = 9.11 fn53 = 1259.4 num1 = tbl10[tbl3[1]] tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["g53bJb57qOUw"]
                            else num7 = 177.5 num1 = tbl10[tbl3[1]] fn53 = -1350.3 num5 = 10.2 tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["7RvbpreKjDHWG"]
                            end
                          else num5 = num5 + tbl12 tbl24 = not tbl9 num7 = num5 <= num4 num7 = tbl24 and num7 tbl24 = num5 >= num4 tbl24 = tbl9 and tbl24 num7 = tbl24 or num7 tbl24 = 14649910 num1 = num7 and tbl24 num7 = 15262058 num1 = num1 or num7
                          end
                        end
                      end
                    end
                  else
                    if num1 < 5141948 then
                      if num1 < 4912586 then
                        if num1 < 4806249 then
                          if num1 < 4764894 then
                            if num1 < 4740191 then
                              fn53 = tbl2[1] num1 = fn53 and 13026604
                            else num1 = 12066337
                            end
                          else num1 = tbl8 and 7152747
                          end
                        else
                          if num1 < 4841046 then
                            if num1 < 4810207 then
                              num7 = 33.999069213867 num1 = tbl10[tbl3[1]] num5 = -1198.3585205078 fn53 = 1226.0625 tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["2XZ3hiabs5pO"]
                            else tbl8 = "Play" num1 = tbl10[tbl3[1]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = tbl10[tbl3[2]] tbl8 = "Stop" tbl8 = num1[tbl8] tbl8 = tbl8(num1) tbl8 = "Destroy" num1 = tbl10[tbl3[3]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = tbl10[tbl3[4]] tbl8 = "Destroy" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = tbl1["56mAD47Fkq2CS"] tbl8 = {}
                            end
                          else num1 = num2 num1 = 11537665 tbl8 = fn20
                          end
                        end
                      else
                        if num1 < 5068656 then
                          if num1 < 5014789 then
                            if num1 < 4942730 then
                              fn53 = nil tbl8 = {} num1 = tbl1["65XhfqtFzkv3"]
                            else tbl14 = 13 num7 = tbl10[tbl3[3]] num5 = 32 fn53 = num7 % num5 tbl16 = 2 num4 = tbl10[tbl3[4]] tbl24 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] tbl6 = tbl25 - fn53 tbl25 = 32 fn51 = tbl6 / tbl25 tbl11 = tbl14 - fn51 tbl19 = tbl16 ^ tbl11 tbl14 = 256 tbl9 = tbl24 / tbl19 tbl12 = num4(tbl9) tbl16 = 256 tbl19 = 1 num4 = 4294967296 num5 = tbl12 % num4 tbl12 = 2 num4 = tbl12 ^ fn53 num7 = num5 / num4 num1 = 4007426 num4 = tbl10[tbl3[4]] tbl24 = num7 % tbl19 tbl19 = 4294967296 tbl9 = tbl24 * tbl19 tbl12 = num4(tbl9) num4 = tbl10[tbl3[4]] tbl9 = num4(num7) tbl24 = 65536 num5 = tbl12 + tbl9 tbl12 = 65536 num4 = num5 % tbl12 tbl9 = num5 - num4 tbl12 = tbl9 / tbl24 tbl24 = 256 tbl9 = num4 % tbl24 tbl19 = num4 - tbl9 num5 = nil fn53 = nil tbl24 = tbl19 / tbl16 tbl16 = 256 tbl19 = tbl12 % tbl16 tbl11 = tbl12 - tbl19 tbl16 = tbl11 / tbl14 num4 = nil num7 = nil tbl11 = {tbl9;
                                tbl24;
                                tbl19, tbl16} tbl9 = nil tbl12 = nil tbl19 = nil tbl16 = nil tbl10[tbl3[1]] = tbl11 tbl24 = nil
                            end
                          else fn53 = tbl10[tbl3[4]] tbl19 = 8364940087095 tbl24 = "\211\164\196\6 \252" num4 = tbl10[tbl3[2]] num1 = 6920454 num7 = "FindFirstChild" tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) num7 = fn53[num7] num5 = num4[tbl9] num7 = num7(fn53, num5) tbl8 = num7
                          end
                        else
                          if num1 < 5125875 then
                            if num1 < 5117531 then
                              fn53 = tbl2[1] num1 = fn53 and 14414707
                            else num7 = "http_request" fn53 = tbl1[num7] num1 = fn53 and 11698867 tbl8 = fn53
                            end
                          else num1 = tbl8 and 2248919
                          end
                        end
                      end
                    else
                      if num1 < 5383479 then
                        if num1 < 5346429 then
                          if num1 < 5252033 then
                            if num1 < 5241107 then
                              tbl9 = "\24876\211<\164" fn53 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl24 = 32203053152915 tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl8 = fn53[num7] tbl12 = "#*\82184\141\219\208\24" tbl9 = 13538938312864 num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) tbl9 = 668654993719 fn53 = num7[num4] num1 = tbl8[fn53] num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] tbl12 = "\144%\24" num4 = num5(tbl12, tbl9) fn53 = num7[num4] tbl8 = "FireServer" tbl8 = num1[tbl8] tbl8 = tbl8(num1, fn53) tbl8 = {} num1 = tbl1["hfSeuE0wNi2yki"]
                            else tbl8 = "_G" num1 = tbl1[tbl8] num7 = tbl10[tbl3[1]] tbl12 = "\28u;\00\255\7x\232\31\8250\8217" tbl9 = 1257916170825 num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = false num1[tbl8] = num7 num1 = tbl10[tbl3[3]] tbl8 = "Play" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 13675762
                            end
                          else tbl12, tbl19 = tbl9(num4, tbl12) num1 = tbl12 and 4004775
                          end
                        else
                          if num1 < 5381275 then
                            if num1 < 5361021 then
                              tbl8 = num7 num1 = num5 num1 = 5128182
                            else fn53 = tbl8 num1 = fn53 and 14736177
                            end
                          else num5 = tbl12 num1 = tbl9 num1 = tbl12 and 3338721
                          end
                        end
                      else
                        if num1 < 5514462 then
                          if num1 < 5400403 then
                            if num1 < 5385143 then
                              tbl8 = {} num1 = tbl1["LkQkZeVDuhgNt"] fn53 = nil
                            else num1 = 5762685
                            end
                          else fn53 = nil num1 = tbl1["Gr1wQgE2x7Rx"] tbl8 = {}
                          end
                        else
                          if num1 < 5612059 then
                            if num1 < 5585324 then
                              tbl9 = "\227\251Qf;5" tbl24 = 34425170067102 fn53 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl8 = fn53[num7] tbl9 = 23089690307071 tbl12 = "~\220|" num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] tbl12 = "\221>\382\217R\2326\214g\8211\352" num1 = tbl8[fn53] tbl9 = 3585130088069 num7 = tbl10[tbl3[2]] tbl8 = "FireServer" num5 = tbl10[tbl3[3]] tbl8 = num1[tbl8] num4 = num5(tbl12, tbl9) fn53 = num7[num4] tbl8 = tbl8(num1, fn53) tbl8 = {} num1 = tbl1["ip19goyIApLmhM"]
                            else tbl19 = 11733196969303 num7 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl24 = "t\15\248\141&>\192)\248\8211\16\161]\23" tbl9 = tbl12(tbl24, tbl19) tbl19 = 28451264771008 num5 = num4[tbl9] fn53 = num7[num5] num4 = tbl10[tbl3[2]] num1 = 11453701 tbl24 = "a\2362\230\235<p\187" tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) num7 = "FindFirstChild" num5 = num4[tbl9] num7 = fn53[num7] num7 = num7(fn53, num5) tbl8 = num7
                            end
                          else num1 = tbl8 and 14976332
                          end
                        end
                      end
                    end
                  end
                else
                  if num1 < 6702881 then
                    if num1 < 6137578 then
                      if num1 < 5843817 then
                        if num1 < 5759467 then
                          if num1 < 5710092 then
                            if num1 < 5701955 then
                              tbl24 = num1 tbl14 = tbl10[tbl3[1]] tbl25 = "\210\18\193\8364" fn51 = tbl10[tbl3[2]] num3 = 5281874889115 tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl16 = tbl12[tbl11] tbl25 = " I\204" num3 = 14517121178216 tbl14 = tbl10[tbl3[1]] fn51 = tbl10[tbl3[2]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl19 = tbl16 == tbl11 num1 = tbl19 and 15085228 tbl9 = tbl19
                            else num2 = tbl10[num7] fn20 = num2 num1 = num2 and 10959916
                            end
                          else tbl24 = "game" tbl14 = "z8\\AX\220\219" fn51 = 30165671638750 tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) num7 = num1 tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl14 = 9138355802271 tbl11 = "\232R\196\r4\12:\28\25\231\28" tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl11 = 11996020381138 tbl16 = "\8217\242W\190e\192\194\8249{" num4 = tbl12[tbl9] tbl9 = tbl10[tbl3[1]] tbl24 = tbl10[tbl3[2]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num5 = num4[tbl12] fn53 = num5 num1 = num5 and 3516823
                          end
                        else
                          if num1 < 5829575 then
                            if num1 < 5765193 then
                              num1 = tbl1["vvQSIi58EZu9"] tbl8 = {num7}
                            else tbl8 = "tonumber" num4 = "tostring" num1 = tbl1[tbl8] fn53 = tbl10[tbl3[4]] num5 = tbl1[num4] tbl19 = "pcall" tbl24 = tbl1[tbl19] tbl16 = fn16(8118303, {}) tbl19 = {tbl24(tbl16)} tbl9 = {fn46(tbl19)} tbl24 = 2 tbl12 = tbl9[tbl24] num4 = num5(tbl12) num5 = ":(%d*):" num7 = fn53(num4, num5) fn53 = {num7()} tbl8 = num1(fn46(fn53)) num7 = tbl10[tbl3[5]] fn53 = tbl8 tbl8 = num7 num1 = num7 and 2885360
                            end
                          else num4 = nil tbl12 = nil num1 = 13634983
                          end
                        end
                      else
                        if num1 < 5901913 then
                          if num1 < 5888069 then
                            if num1 < 5858619 then
                              num1 = tbl1["TKjUE0BWZprV"] tbl8 = {}
                            else num5 = "game" tbl24 = "\174\23\8249\16j\238I" num7 = tbl1[num5] num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl19 = 18860409643598 tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] tbl24 = 21109093738085 num5 = tbl10[tbl3[1]] tbl9 = "\7^3\15\203\732\185-%\251\144" num4 = tbl10[tbl3[2]] tbl19 = 24921071873364 tbl12 = num4(tbl9, tbl24) tbl24 = "\186\16\25" num7 = num5[tbl12] tbl8 = fn53[num7] num7 = tbl10[tbl3[1]] tbl12 = "wY\1745_\219t\225" tbl14 = 30600576448425 tbl9 = 31016456435819 num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl11 = "\221i\194" tbl16 = 8541156413321 fn53 = num7[num4] num1 = tbl8[fn53] tbl9 = 12002703070677 num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] fn53 = num1 tbl12 = "\235}J\352\227\30\241\242>\191w\218`\26\166\185" num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num1 = fn53[tbl8] num5 = "Ray" tbl8 = tbl1[num5] num4 = tbl10[tbl3[1]] num7 = num1 tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num1 = tbl8[num5] tbl12 = tbl10[tbl3[1]] tbl19 = "L7y`b\8218\25\237" tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl9 = "Vector3" num5 = num7[num4] tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] tbl9 = 0 tbl24 = -10 tbl19 = 0 tbl12 = {num4(tbl9, tbl24, tbl19)} tbl8 = num1(num5, fn46(tbl12)) num5 = tbl8 tbl12 = {fn53} tbl8 = "workspace" tbl9 = "FindPartOnRayWithIgnoreList" num1 = tbl1[tbl8] tbl9 = num1[tbl9] tbl9 = {tbl9(num1, num5, tbl12)} tbl8 = tbl9[1] num4 = tbl9[2] tbl12 = tbl8 tbl8 = tbl12 num1 = tbl12 and 5693476
                            end
                          else tbl22 = tbl14 == fn51 fn14 = tbl22 num1 = 10403048
                          end
                        else
                          if num1 < 5932260 then
                            if num1 < 5902674 then
                              tbl10[num7] = fn20 tbl23 = 1 num8 = tbl10[tbl7] num6 = num8 + tbl23 fn52 = n[num6] num2 = tbl14 + fn52 fn52 = 256 num1 = num2 % fn52 num6 = tbl10[tbl21] tbl14 = num1 fn52 = fn51 + num6 num1 = 1448629 num6 = 256 num2 = fn52 % num6 fn51 = num2
                            else tbl8 = 15805823 num7 = "RUhW" num5 = 13483292 fn53 = num7 ^ num5 num1 = tbl8 - fn53 fn53 = num1 tbl8 = "ZAyh7UrhPta9u" num1 = tbl8 / fn53 tbl8 = {num1} num1 = tbl1["V0BwlkDBNqzf"]
                            end
                          else tbl8 = "game" tbl12 = "4\161\r\239\246\8218\240#\172\195G\197\213?\235\191\199" num1 = tbl1[tbl8] num7 = tbl10[tbl3[1]] tbl9 = 4618424223846 num5 = tbl10[tbl3[2]] tbl8 = "GetService" tbl8 = num1[tbl8] num4 = num5(tbl12, tbl9) fn53 = num7[num4] tbl8 = tbl8(num1, fn53) tbl9 = 21076461692502 num1 = "FindFirstChild" num7 = tbl10[tbl3[1]] tbl12 = "\0\223\228\4" num5 = tbl10[tbl3[2]] fn53 = tbl8 num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num1 = fn53[num1] num1 = num1(fn53, tbl8) num7 = num1 num1 = num7 and 4597260
                          end
                        end
                      end
                    else
                      if num1 < 6508652 then
                        if num1 < 6321689 then
                          if num1 < 6283715 then
                            if num1 < 6269745 then
                              fn53 = tbl2[1] num1 = fn53 and 10383383
                            else num1 = tbl8 and 13244873
                            end
                          else tbl6 = "gethui" fn51 = tbl1[tbl6] tbl6 = fn51() tbl11 = tbl6 num1 = 11113331
                          end
                        else
                          if num1 < 6416555 then
                            if num1 < 6388453 then
                              tbl19 = tbl11 tbl17 = "string" tbl22 = tbl1[tbl17] tbl17 = "byte" fn14 = tbl22[tbl17] tbl22 = fn14(fn53, tbl19) fn14 = tbl10[tbl3[6]] tbl17 = fn14() num3 = tbl22 + tbl17 tbl25 = num3 + tbl9 num3 = 256 tbl6 = tbl25 % num3 num1 = 13173327 tbl9 = tbl6 tbl17 = 1 num3 = num5[num7] tbl22 = tbl9 + tbl17 fn14 = num4[tbl22] tbl19 = nil tbl25 = num3..fn14 num5[num7] = tbl25
                            else fn53 = nil num7 = nil tbl8 = {} num1 = tbl1["soQkK4pXeksvZ8"]
                            end
                          else fn53 = tbl20() fn51 = 34537198665426 tbl10[fn53] = tbl2[1] tbl16 = "U:'\255\166\235\170\178\189S=c\235" tbl11 = 3073155843479 num4 = tbl10[fn53] tbl14 = "\376\199\237\143\216do2H_\242CU" tbl9 = tbl10[tbl3[1]] tbl24 = tbl10[tbl3[2]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num5 = num4[tbl12] tbl24 = "Enum" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) tbl14 = 9782875820491 tbl24 = tbl19[tbl11] tbl11 = "Rl\197\127\8D\353D4}\8230:" tbl12 = tbl9[tbl24] tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] num7 = num5 == num4 num1 = num7 and 1677546 tbl8 = num7
                          end
                        end
                      else
                        if num1 < 6655438 then
                          if num1 < 6569833 then
                            if num1 < 6554329 then
                              num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl9 = "\8224\223\339\196\192\160\r\227" tbl24 = 17120132800292 tbl16 = 1726672470820 tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl9 = "\216F\141" tbl8 = fn53[num7] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl19 = "\237\15\163" tbl24 = 18168487633164 tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num1 = tbl8[num7] tbl9 = 25539358076532 num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] tbl12 = "y\217\4\3\t\19L\188" num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num4 = "UDim2" num5 = tbl1[num4] tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl12 = 0 tbl16 = 26147874500496 num7 = num5[num4] tbl19 = "\164\8220\227" num4 = 0.5 tbl24 = 0 tbl9 = 0.5 num5 = num7(num4, tbl12, tbl9, tbl24) num1[tbl8] = num5 num5 = tbl10[tbl3[2]] tbl24 = 5592904485420 num4 = tbl10[tbl3[3]] tbl9 = "\206I\213V\189\172\207\186" tbl12 = num4(tbl9, tbl24) tbl9 = "\203L\197" num7 = num5[tbl12] tbl24 = 27236421022090 tbl8 = fn53[num7] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl9 = 20794896311763 tbl12 = "i1:90" num1 = tbl8[num7] num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num4 = "UDim2" num5 = tbl1[num4] tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num7 = num5[num4] num4 = 1 tbl12 = 1 tbl24 = 1 tbl9 = 1 num5 = num7(num4, tbl12, tbl9, tbl24) num1[tbl8] = num5 num1 = 7898596
                            else num1 = tbl10[tbl3[5]] tbl12 = num5 tbl12 = nil tbl24 = num1(tbl9) tbl9 = nil num1 = 3480503
                            end
                          else tbl14 = 28201231692620 num1 = tbl10[tbl3[4]] tbl8 = "Play" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num4 = tbl10[tbl3[1]] tbl11 = 9109937131666 tbl16 = "\381\206\186\22\207\201\177\382\8" tbl9 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] tbl8 = num4[tbl12] tbl16 = 14865727462154 tbl12 = tbl10[tbl3[2]] tbl11 = "\177K\381" tbl19 = "C\8221\199^\219*\0\190\203\3821\195\235\353\0\161" tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num1 = tbl8[num4] num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl24 = "F\8230\5\27\352\232" tbl19 = 6728875183165 tbl9 = tbl12(tbl24, tbl19) tbl8 = num4[tbl9] tbl9 = "CFrame" tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] tbl12 = num4(fn53, num7, num5) num1[tbl8] = tbl12 num1 = 9177296
                          end
                        else
                          if num1 < 6700355 then
                            if num1 < 6680539 then
                              fn53 = tbl2[1] num1 = fn53 and 1973276
                            else num5, tbl9 = num4(num7, num5) num1 = num5 and 2096690
                            end
                          else tbl11 = 3 tbl14 = 65 tbl16 = tbl20() tbl10[tbl16] = tbl8 num1 = tbl10[tbl24] tbl8 = num1(tbl11, tbl14) tbl11 = tbl20() tbl6 = "pcall" tbl10[tbl11] = tbl8 num1 = 0 tbl14 = num1 tbl25 = fn16(5908614, {}) num1 = 0 tbl8 = tbl1[tbl6] tbl6 = {tbl8(tbl25)} tbl17 = "tostring" fn51 = num1 num1 = {fn46(tbl6)} tbl8 = 2 tbl6 = num1 num1 = tbl6[tbl8] tbl25 = num1 tbl8 = "tonumber" num1 = tbl1[tbl8] num3 = tbl10[num5] tbl22 = tbl1[tbl17] tbl17 = tbl22(tbl25) tbl22 = ":(%d*):" fn14 = num3(tbl17, tbl22) num3 = {fn14()} tbl8 = num1(fn46(num3)) num3 = tbl20() tbl10[num3] = tbl8 tbl8 = 1 fn14 = tbl10[tbl11] num1 = 7066904 tbl22 = fn14 fn14 = 1 tbl17 = fn14 fn14 = 0 tbl18 = tbl17 < fn14 fn14 = tbl8 - tbl17
                          end
                        end
                      end
                    end
                  else
                    if num1 < 7046611 then
                      if num1 < 6921392 then
                        if num1 < 6850143 then
                          if num1 < 6825953 then
                            if num1 < 6718139 then
                              num1 = num4 num1 = 14668004 tbl8 = num5
                            else fn53 = "_G" tbl8 = tbl1[fn53] num7 = tbl10[tbl3[1]] tbl12 = "\198\212\254\338\7N\176x" tbl9 = 26122276368260 num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] num1 = num1 and 2278684
                            end
                          else num1 = num7 num1 = 11698867 tbl8 = fn53
                          end
                        else
                          if num1 < 6917043 then
                            if num1 < 6892860 then
                              num4 = tbl10[fn53] tbl11 = 20108851078291 tbl9 = tbl10[tbl3[1]] tbl14 = "\15}\1\8221\161\n]\353\232@0k\196" tbl24 = tbl10[tbl3[2]] fn51 = 9780591612362 tbl16 = "1\241\172\8222\215\143P\8217\181'\2\173\185" tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] tbl24 = "Enum" num5 = num4[tbl12] tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl11 = "\254g\n\201\184" tbl14 = 27730688045681 num1 = 1677546 tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] num7 = num5 == num4 tbl8 = num7
                            else num4 = nil tbl12 = nil num1 = 9840210 num7 = nil num5 = nil fn53 = nil
                            end
                          else fn53 = tbl8 num1 = fn53 and 8573470
                          end
                        end
                      else
                        if num1 < 6940007 then
                          if num1 < 6938138 then
                            if num1 < 6934222 then
                              tbl24 = num5 tbl19 = num1 num1 = num5 and 11443333
                            else num7 = tbl10[tbl3[1]] tbl24 = "\233u`\253\23\338\254\8225v" num4 = tbl10[tbl3[2]] tbl19 = 27842780230309 tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) tbl24 = 3563388536443 num5 = num4[tbl9] tbl8 = num7[num5] tbl9 = "\31\240\27\229\194l\22\31\29{\26" num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl12 = "\1784\t\236\8217\12\206^" tbl14 = "\16\213\30\8217\157\172\236[\201" num1 = tbl8[num7] num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] tbl9 = 31927570922003 fn51 = 5464003742192 num4 = num5(tbl12, tbl9) tbl8 = num7[num4] tbl9 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl11 = "?\11\170\188\161\184+_" tbl24 = tbl10[tbl3[2]] tbl14 = 987666792907 tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl16 = "\163\339\177\209\27=\8226\28\163\181\27\238\11" num4 = tbl12[tbl9] tbl9 = tbl10[tbl3[2]] tbl11 = 11116817667128 tbl24 = tbl10[tbl3[3]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num5 = num4[tbl12] num4 = tbl10[tbl3[5]] num7 = num5 * num4 num1[tbl8] = num7 num1 = 15068901
                            end
                          else num1 = 4293338 tbl19 = "_G" fn51 = "\732\207O\183\8249\7\252\16\241\253_G\175\157\168\4\8\211" tbl24 = tbl1[tbl19] tbl16 = tbl10[tbl3[1]] tbl11 = tbl10[tbl3[2]] tbl6 = 24862191725881 tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] num4 = tbl9
                          end
                        else
                          if num1 < 6982335 then
                            if num1 < 6979743 then
                              tbl24 = "math" tbl9 = tbl8 tbl8 = tbl1[tbl24] tbl24 = "random" num1 = tbl8[tbl24] tbl19 = "table" tbl24 = tbl20() tbl10[tbl24] = num1 tbl8 = tbl1[tbl19] tbl19 = "concat" num1 = tbl8[tbl19] tbl11 = num1 tbl19 = num1 fn51 = "table" tbl14 = tbl1[fn51] tbl16 = tbl14 num1 = tbl14 and 4487229
                            else num7 = tbl10[tbl3[3]] num5 = 1 fn53 = num7 ~= num5 num1 = fn53 and 4998978
                            end
                          else num1 = tbl1["9WvnFkmAjgiW9"] fn53 = nil tbl8 = {}
                          end
                        end
                      end
                    else
                      if num1 < 7163755 then
                        if num1 < 7134104 then
                          if num1 < 7130477 then
                            if num1 < 7072070 then
                              fn12 = not tbl18 fn14 = fn14 + tbl17 tbl8 = fn14 <= tbl22 tbl8 = fn12 and tbl8 fn12 = fn14 >= tbl22 fn12 = tbl18 and fn12 tbl8 = fn12 or tbl8 fn12 = 9880338 num1 = tbl8 and fn12 tbl8 = 9723093 num1 = num1 or tbl8
                            else num3 = # tbl6 tbl18 = 0 tbl25 = num3 == tbl18 num1 = tbl25 and 16632314
                            end
                          else num1 = tbl1["rsMuun4jBzEcE"] tbl8 = {}
                          end
                        else
                          if num1 < 7144686 then
                            if num1 < 7138312 then
                              tbl19 = "Ql7xx\31\27i\187:\170I\162\254" tbl24 = 15422466628621 fn53 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl9 = "p\206 7\8240+\14X\8\83647\29\2378" tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num4 = "Enum" tbl8 = fn53[num7] num5 = tbl1[num4] tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl16 = 28571112272888 tbl24 = tbl9(tbl19, tbl16) tbl19 = 10845528478650 num4 = tbl12[tbl24] num7 = num5[num4] tbl24 = "\24\196\203" num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] num1 = tbl8 == fn53 num1 = num1 and 15667812
                            else num1 = 9667905
                            end
                          else tbl19 = tbl10[tbl3[1]] fn51 = 5449426438633 tbl16 = tbl10[tbl3[2]] tbl14 = "x \31d\27\8gS" tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl9 = num7[tbl24] tbl19 = tbl10[tbl3[1]] tbl14 = "\732" tbl16 = tbl10[tbl3[2]] fn51 = 32370555648737 tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl8 = tbl9[tbl24] tbl9 = 0 num1 = tbl8 < tbl9 num1 = num1 and 1907866
                          end
                        end
                      else
                        if num1 < 7364107 then
                          if num1 < 7234200 then
                            if num1 < 7187536 then
                              num1 = tbl1["kEYrDNcWyOE2eo"] fn53 = nil num7 = nil tbl8 = {}
                            else fn53 = fn17(1732706, {tbl3[1];
                                  tbl3[2];
                                  tbl3[3];
                                  tbl3[4], tbl3[5], tbl3[6]}) tbl8 = "pcall" num1 = tbl1[tbl8] tbl8 = num1(fn53) tbl8 = {} num1 = tbl1["gfwov6Oyj39Hq"]
                            end
                          else fn53 = nil num1 = tbl1["rBiKtiO1Zbbb"] tbl8 = {}
                          end
                        else
                          if num1 < 7418129 then
                            if num1 < 7389691 then
                              fn53 = tbl2[1] num1 = tbl10[tbl3[1]] tbl12 = "\238\251\8211\144\8225\24\204" num7 = tbl10[tbl3[2]] tbl9 = 31515673885011 num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = fn53 fn53 = nil num1[tbl8] = num7 num1 = tbl1["ECrtzRDhw4eW"] tbl8 = {}
                            else tbl21 = not tbl5 num3 = num3 + fn12 tbl25 = num3 <= tbl18 tbl25 = tbl21 and tbl25 tbl21 = num3 >= tbl18 tbl21 = tbl5 and tbl21 tbl25 = tbl21 or tbl25 tbl21 = 4097161 num1 = tbl25 and tbl21 tbl25 = 10258900 num1 = num1 or tbl25
                            end
                          else num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] fn53 = num7 == num5 tbl8 = fn53 num1 = 1320366
                          end
                        end
                      end
                    end
                  end
                end
              end
            else
              if num1 < 12068113 then
                if num1 < 9504070 then
                  if num1 < 8389058 then
                    if num1 < 8070898 then
                      if num1 < 7737225 then
                        if num1 < 7511912 then
                          if num1 < 7495948 then
                            if num1 < 7463765 then
                              num1 = tbl8 and 9153605
                            else fn53 = fn53 + num5 tbl12 = not num4 tbl8 = fn53 <= num7 tbl8 = tbl12 and tbl8 tbl12 = fn53 >= num7 tbl12 = num4 and tbl12 tbl8 = tbl12 or tbl8 tbl12 = 1697641 num1 = tbl8 and tbl12 tbl8 = 9088452 num1 = num1 or tbl8
                            end
                          else
                            if num1 < 7498274 then
                              num1 = tbl11 num1 = tbl16 and 6702580 tbl8 = tbl16
                            else tbl18 = # tbl6 tbl21 = 1 num3 = 1 tbl25 = num5(num3, tbl18) num1 = 7100071 num3 = tbl9(tbl6, tbl25) tbl18 = tbl10[fn51] tbl5 = num3 - tbl21 fn12 = tbl24(tbl5) tbl18[num3] = fn12 tbl25 = nil num3 = nil
                            end
                          end
                        else
                          if num1 < 7584358 then
                            if num1 < 7530698 then
                              num7 = 9.11 fn53 = 1442.7 num5 = -1484.02 num1 = tbl10[tbl3[1]] tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["utAFVpCYUjDFPw"]
                            else fn51, num3 = tbl6(tbl14, fn51) num1 = fn51 and 10548707
                            end
                          else tbl24 = tbl10[tbl3[1]] num4 = num7 tbl14 = 5757711698553 tbl19 = tbl10[tbl3[2]] tbl11 = "HZ\209\228\204\222\251R" tbl16 = tbl19(tbl11, tbl14) num1 = "IsA" tbl9 = tbl24[tbl16] num1 = tbl12[num1] num1 = num1(tbl12, tbl9) num1 = num1 and 14899531
                          end
                        end
                      else
                        if num1 < 7920217 then
                          if num1 < 7915695 then
                            if num1 < 7897497 then
                              tbl24 = "\195\213vj\732\25 \253\178" tbl19 = 22089233639470 fn53 = tbl2[1] num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num7 = "IsA" num5 = num4[tbl9] num7 = fn53[num7] num7 = num7(fn53, num5) tbl8 = num7 num1 = num7 and 4109513
                            else num7 = tbl10[tbl3[4]] num1 = num7 and 15331671 tbl8 = num7
                            end
                          else tbl9 = tbl10[tbl3[1]] tbl16 = "\190\8217\15\187\164\129\21\207\1826" num4 = "IsA" tbl24 = tbl10[tbl3[2]] tbl11 = 16825354722970 num4 = fn53[num4] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num4 = num4(fn53, tbl12) num1 = 12981866 num7 = num4
                          end
                        else
                          if num1 < 7999958 then
                            if num1 < 7938124 then
                              num1 = tbl10[tbl3[1]] num5 = -48.39 num7 = 9.28 fn53 = -1202.46 tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["LeB0nJNVVZbyLi"]
                            else fn53 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl19 = 24529004637342 tbl12 = tbl10[tbl3[3]] tbl24 = "a\12J\165\243@" num7 = "WaitForChild" num7 = fn53[num7] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num4 = 5 num7 = num7(fn53, num5, num4) num1 = num7 and 6920454 tbl8 = num7
                            end
                          else tbl8 = {} num1 = tbl1["TUmm0txwNQvFR"]
                          end
                        end
                      end
                    else
                      if num1 < 8231485 then
                        if num1 < 8144566 then
                          if num1 < 8097697 then
                            if num1 < 8086383 then
                              num5 = num1 tbl9 = "_G" tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[2]] tbl14 = 31751517108673 tbl11 = "\245\253\163M%g<\238\244>\8226" tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] num7 = num4 num1 = num4 and 13479283
                            else tbl8 = "Play" num1 = tbl10[tbl3[3]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 12215246
                            end
                          else tbl8 = 15481716 num5 = 11292888 num7 = "KhnzhZG3" fn53 = num7 ^ num5 num1 = tbl8 - fn53 tbl8 = "cdrBq3UA8CITM" fn53 = num1 num1 = tbl8 / fn53 tbl8 = {num1} num1 = tbl1["k4oZwItpzt8cvh"]
                          end
                        else
                          if num1 < 8211928 then
                            if num1 < 8205680 then
                              num5 = 0 fn53 = "error" num1 = tbl1[fn53] num7 = tbl10[tbl3[8]] fn53 = num1(num7, num5) num1 = 16220349
                            else num1 = tbl10[tbl3[7]] num1 = num1 and 8195153
                            end
                          else tbl16 = "\163\167\213\237S\144z" tbl11 = 11828098258307 num5 = num1 tbl9 = tbl10[tbl3[1]] tbl24 = tbl10[tbl3[2]] num4 = "IsA" tbl19 = tbl24(tbl16, tbl11) num4 = fn53[num4] tbl12 = tbl9[tbl19] num4 = num4(fn53, tbl12) num1 = num4 and 12981866 num7 = num4
                          end
                        end
                      else
                        if num1 < 8339106 then
                          if num1 < 8297404 then
                            if num1 < 8244684 then
                              num1 = tbl10[tbl3[1]] tbl8 = "Play" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 11870760
                            else num1 = 14097646
                            end
                          else tbl12 = "game" num4 = tbl1[tbl12] tbl9 = tbl10[tbl3[1]] tbl16 = "\12;\\\17\229\193%" tbl24 = tbl10[tbl3[2]] tbl11 = 31965284252196 tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num5 = num4[tbl12] tbl19 = "\251\8482\167\225R\17\8482f\250\189\201" tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl16 = 2361011717195 tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num7 = num5[num4] tbl24 = "e\174j\8225)cRa\208" num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl19 = 8441531289434 tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] num1 = fn53 and 9391752 tbl8 = fn53
                          end
                        else
                          if num1 < 8373996 then
                            if num1 < 8357988 then
                              tbl12 = nil num1 = 9316761 num4 = nil
                            else tbl8 = "pairs" num1 = tbl1[tbl8] tbl12 = "GetPlayers" num5 = tbl10[tbl3[3]] tbl12 = num5[tbl12] num4 = {tbl12(num5)} num5 = {num1(fn46(num4))} fn53 = num5[2] tbl8 = num5[1] num1 = 13634983 num7 = num5[3] num5 = tbl8
                            end
                          else tbl12 = tbl10[tbl3[3]] tbl16 = 27274746196380 num5 = "FindFirstChildOfClass" tbl9 = tbl10[tbl3[4]] tbl19 = "gl\16\224" num5 = fn53[num5] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num1 = 9756170 num5 = num5(fn53, num4) num7 = not num5 tbl8 = num7
                          end
                        end
                      end
                    end
                  else
                    if num1 < 9059511 then
                      if num1 < 8726980 then
                        if num1 < 8511335 then
                          if num1 < 8478921 then
                            if num1 < 8398038 then
                              num1 = 12213649
                            else num5 = "_G" tbl19 = 18610771157466 num7 = tbl1[num5] num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl24 = "\254\12[\248}\8226" tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] tbl8 = fn53 num1 = fn53 and 639055
                            end
                          else num1 = 15954276
                          end
                        else
                          if num1 < 8716128 then
                            if num1 < 8547959 then
                              num1 = true tbl10[tbl3[1]] = num1 tbl8 = {} num1 = tbl1["bYm5uvHF1TQ5m"]
                            else tbl8 = "pairs" tbl12 = "GetDescendants" tbl12 = fn53[tbl12] num1 = tbl1[tbl8] num4 = {tbl12(fn53)} tbl12 = {num1(fn46(num4))} num5 = tbl12[3] tbl8 = tbl12[1] num7 = tbl12[2] num1 = 3480503 num4 = tbl8
                            end
                          else num1 = 2832744 tbl8 = num5
                          end
                        end
                      else
                        if num1 < 8881079 then
                          if num1 < 8808769 then
                            if num1 < 8789615 then
                              tbl8 = {} num1 = tbl1["trq42p9WSUnU1S"]
                            else tbl8 = "Play" num1 = tbl10[tbl3[1]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 4093937
                            end
                          else num1 = tbl1["qRsM4OEvAkil"] tbl8 = {}
                          end
                        else
                          if num1 < 9054471 then
                            if num1 < 8971772 then
                              fn53 = nil tbl8 = {} num1 = tbl1["3pmsOKJCu19wXZ"]
                            else num1 = tbl10[tbl3[1]] num1 = num1 and 805532
                            end
                          else num1 = tbl1["LM3Xr1QHVpll"] tbl8 = {}
                          end
                        end
                      end
                    else
                      if num1 < 9175878 then
                        if num1 < 9146963 then
                          if num1 < 9122877 then
                            if num1 < 9064016 then
                              num5, tbl9 = num4(num7, num5) num1 = num5 and 11602020
                            else tbl19 = "\161\203=\211" num7 = 0.5 tbl16 = 23322750691948 num1 = tbl10[tbl3[6]] fn53 = tbl10[tbl3[7]] tbl12 = tbl10[tbl3[3]] tbl9 = tbl10[tbl3[4]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] fn51 = 23691905903384 tbl24 = "UDim2" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[3]] tbl14 = "\710\201\3" tbl16 = tbl10[tbl3[4]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl19 = 0 tbl16 = 0 tbl11 = 0 tbl24 = 0 tbl9 = tbl12(tbl24, tbl19, tbl16, tbl11) tbl24 = tbl10[tbl3[3]] tbl11 = "\234N.\200\209\244\177\8218\188l\163p\14eb\204nl\7\232\244\226" tbl19 = tbl10[tbl3[4]] tbl14 = 30965102524499 tbl16 = tbl19(tbl11, tbl14) tbl12 = tbl24[tbl16] tbl24 = 1 num5 = {[num4] = tbl9, [tbl12] = tbl24} tbl8 = num1(fn53, num7, num5) tbl9 = 35030666641336 fn53 = "task" tbl12 = "\176Z\235\199" tbl8 = tbl1[fn53] num7 = tbl10[tbl3[3]] num5 = tbl10[tbl3[4]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] fn53 = 0.5 tbl8 = num1(fn53) tbl8 = "Destroy" num1 = tbl10[tbl3[8]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) tbl8 = {} num1 = tbl1["UyebzhAvscbpII"]
                            end
                          else tbl8 = tbl10[tbl3[2]] num7 = tbl10[tbl3[3]] num5 = tbl10[tbl3[4]] tbl12 = "\255\402\381\210d\27" tbl9 = 31992652446257 num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] num1 = num1 and 3517732
                          end
                        else
                          if num1 < 9175767 then
                            if num1 < 9164315 then
                              tbl19 = 19811606422537 num7 = tbl10[tbl3[3]] tbl24 = "\338\143y\186\211!" num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] tbl24 = 26260398026692 tbl8 = num7[num5] num5 = tbl10[tbl3[1]] tbl9 = "\24\228N?\8221\8216C\141e\219A0\2550\184\5\170\165\212\251\0" num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num1 = tbl8[num7] tbl8 = "FireServer" tbl24 = "j(\8M9\164" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num7 = tbl10[tbl3[3]] num4 = tbl10[tbl3[1]] tbl19 = 26412131119115 tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] tbl24 = 16986184376037 tbl8 = num7[num5] num5 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl9 = "\191\175\178\141\176\8482\t\247\171\190T\220\8230\253G" tbl12 = num4(tbl9, tbl24) tbl19 = "\170\24G\18" tbl16 = 17191511154501 num7 = num5[tbl12] num1 = tbl8[num7] num7 = true tbl12 = tbl10[tbl3[1]] tbl8 = "FireServer" tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) tbl8 = num1[tbl8] num4 = tbl12[tbl24] num5 = fn53[num4] tbl8 = tbl8(num1, num7, num5) num1 = 15107300
                            else num7 = tbl2[2] num5 = tbl2[3] tbl16 = 17245280280414 tbl19 = "$T\193" fn53 = tbl2[1] num4 = "Instance" tbl8 = tbl1[num4] tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num1 = tbl8[num4] tbl16 = 34839755407199 tbl19 = "I{g6\165" tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) tbl19 = 693331165506 num4 = tbl12[tbl24] tbl8 = num1(num4) num4 = tbl8 tbl8 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl24 = "s\253#L" tbl9 = tbl12(tbl24, tbl19) num1 = tbl8[tbl9] tbl12 = num1 tbl8 = num5 num1 = num5 and 12849884
                            end
                          else num1 = tbl1["vi1jahfa74be5O"] tbl8 = {}
                          end
                        end
                      else
                        if num1 < 9390905 then
                          if num1 < 9320643 then
                            if num1 < 9222059 then
                              num7 = nil num5 = nil fn53 = nil num1 = tbl1["LOBO4jv4Mby5Sl"] tbl8 = {}
                            else num7, tbl12 = num5(fn53, num7) num1 = num7 and 7727190
                            end
                          else num7 = 9.76 num5 = -1406.38 fn53 = -1370.04 num1 = tbl10[tbl3[1]] tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["Y0WlhR2f3I6m"]
                          end
                        else
                          if num1 < 9398120 then
                            if num1 < 9393239 then
                              tbl12 = "game" tbl16 = "\170\141]\30#X\24" tbl11 = 3557735515768 num4 = tbl1[tbl12] tbl9 = tbl10[tbl3[1]] tbl24 = tbl10[tbl3[2]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] tbl16 = 34824447229784 num5 = num4[tbl12] tbl12 = tbl10[tbl3[1]] tbl19 = "\19RM O\232J!\8249\8218\25" tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num7 = num5[num4] num4 = tbl10[tbl3[1]] tbl19 = 27520522351119 tbl24 = "a\n\8\214TIF\205\169" tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] num1 = 2106394 tbl24 = "\255\0isr\160\22s" tbl19 = 8311402336030 tbl9 = tbl12(tbl24, tbl19) num7 = "FindFirstChildOfClass" num5 = num4[tbl9] num7 = fn53[num7] num7 = num7(fn53, num5) tbl8 = num7
                            else fn53 = "task" tbl8 = tbl1[fn53] tbl12 = "\8249H\8222\157" num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl9 = 10481255879440 num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] fn53 = 3 tbl8 = num1(fn53) num1 = 3277639
                            end
                          else tbl11 = 17872169263234 num1 = tbl10[tbl3[5]] tbl16 = "\188\8240\382\382" tbl14 = 22248597842040 tbl9 = tbl10[tbl3[3]] tbl24 = tbl10[tbl3[4]] tbl19 = tbl24(tbl16, tbl11) tbl8 = tbl9[tbl19] tbl24 = tbl10[tbl3[3]] tbl19 = tbl10[tbl3[4]] tbl11 = "68\194/\382@Q\222\193H\127$\8220\8217qq\8240\190N\220\17\20\231\187\203\163" tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num1[tbl8] = tbl9 num1 = 12829489
                          end
                        end
                      end
                    end
                  end
                else
                  if num1 < 10907747 then
                    if num1 < 10130308 then
                      if num1 < 9776709 then
                        if num1 < 9706749 then
                          if num1 < 9670508 then
                            if num1 < 9597618 then
                              fn53 = tbl20() tbl10[fn53] = tbl2[1] tbl8 = "pcall" num7 = fn18(9673241, {tbl3[1], tbl3[2];
                                  tbl3[3], fn53}) num1 = tbl1[tbl8] fn53 = fn15(fn53) tbl8 = num1(num7) tbl8 = {} num1 = tbl1["G9eZ9AerSFxo"]
                            else num1 = true num1 = num1 and 1449480
                            end
                          else tbl9 = "\193/N\8250(n\212l\8226" tbl24 = 7001204935868 fn53 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl12 = "\8212\8240\169\8225\16\8364\210;" tbl8 = fn53[num7] tbl9 = 25955297455926 num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) tbl12 = 17268330307433 fn53 = num7[num4] num1 = tbl8[fn53] fn53 = tbl10[tbl3[2]] num4 = "\12\8|\222\163\17\179j\189" num7 = tbl10[tbl3[3]] num5 = num7(num4, tbl12) tbl8 = fn53[num5] fn53 = tbl10[tbl3[4]] num1[tbl8] = fn53 tbl8 = {} num1 = tbl1["zzgPQm7DzuaJV"]
                          end
                        else
                          if num1 < 9755106 then
                            if num1 < 9739215 then
                              tbl22 = tbl10[num7] fn14 = tbl22 num1 = tbl22 and 5898892
                            else num1 = 11741395 fn53 = nil
                            end
                          else num1 = tbl8 and 15298580
                          end
                        end
                      else
                        if num1 < 9878231 then
                          if num1 < 9863354 then
                            if num1 < 9843578 then
                              num1 = tbl1["ODUZTXHQeAhaHt"] tbl8 = {}
                            else tbl8 = "pcall" fn53 = fn17(11483398, {tbl3[1];
                                  tbl3[2]}) num1 = tbl1[tbl8] tbl8 = num1(fn53) num1 = tbl1["mZOAx56SXMwsN"] tbl8 = {}
                            end
                          else num1 = tbl10[tbl3[1]] num1 = num1 and 2242295
                          end
                        else
                          if num1 < 10049307 then
                            if num1 < 9899121 then
                              n = 2 tbl5 = "math" tbl15 = 10000 tbl21 = 100 fn12 = tbl20() tbl10[fn12] = fn14 tbl8 = tbl1[tbl5] tbl5 = "random" num1 = tbl8[tbl5] tbl7 = 255 tbl5 = 1 tbl8 = num1(tbl5, tbl21) tbl5 = tbl20() tbl21 = 0 tbl10[tbl5] = tbl8 num1 = tbl10[tbl24] tbl8 = num1(tbl21, tbl7) tbl21 = tbl20() tbl10[tbl21] = tbl8 num1 = tbl10[tbl24] tbl7 = 1 fn49 = tbl10[tbl5] tbl8 = num1(tbl7, fn49) tbl7 = tbl20() tbl10[tbl7] = tbl8 tbl8 = tbl10[tbl24] tbl13 = 1 tbl23 = 0 fn49 = tbl8(tbl13, n) tbl8 = 1 num1 = fn49 == tbl8 tbl8 = ":(%d*):" fn49 = tbl20() n = ":" tbl10[fn49] = num1 fn52 = "tostring" num1 = "gsub" num2 = tbl1[fn52] num6 = tbl10[tbl24] num8 = {num6(tbl23, tbl15)} fn52 = num2(fn46(num8)) num2 = ":" fn20 = fn52..num2 tbl13 = n..fn20 n = "pcall" num1 = tbl25[num1] num1 = num1(tbl25, tbl8, tbl13) tbl13 = tbl20() tbl10[tbl13] = num1 tbl8 = tbl1[n] fn20 = fn17(1041130, {tbl24, fn12;
                                  tbl11, num5;
                                  num7;
                                  num3;
                                  fn49;
                                  tbl13, tbl5, tbl7;
                                  tbl21;
                                  tbl16}) n = {tbl8(fn20)} num1 = {fn46(n)} n = num1 num1 = tbl10[fn49] num1 = num1 and 13653748
                            else num1 = 15684533
                            end
                          else tbl8 = {} num1 = tbl1["RSLMrxAxdgwA"]
                          end
                        end
                      end
                    else
                      if num1 < 10387729 then
                        if num1 < 10279427 then
                          if num1 < 10264919 then
                            if num1 < 10204173 then
                              num7 = "game" fn53 = tbl2[1] tbl24 = 7047883918545 tbl8 = tbl1[num7] num5 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl9 = "\4\r\8212\179\8220P\175\252" tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num1 = tbl8[num7] tbl12 = "\16\25\244p=\228\205Os\175" tbl9 = 12599886141163 num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] tbl9 = 2 num4 = fn53 and tbl9 tbl12 = num1 num5 = num1 fn53 = nil tbl12 = 1 num7 = num4 or tbl12 num1[tbl8] = num7 tbl8 = {} num1 = tbl1["CegYtqoajb0cHo"]
                            else num1 = 7500330 num3 = # tbl6 tbl18 = 0 tbl25 = num3 == tbl18
                            end
                          else tbl12 = "N\203|\20\162\198\710" tbl9 = 16459210825200 tbl8 = "_G" num1 = tbl1[tbl8] fn53 = tbl2[1] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = fn53 fn53 = nil num1[tbl8] = num7 tbl8 = {} num1 = tbl1["qekL7QE9LGcESC"]
                          end
                        else
                          if num1 < 10362988 then
                            if num1 < 10301464 then
                              num1 = tbl8 and 6542467
                            else num1 = true num1 = num1 and 12393285
                            end
                          else num1 = tbl10[tbl3[1]] tbl8 = "Play" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 10641935
                          end
                        end
                      else
                        if num1 < 10580368 then
                          if num1 < 10533098 then
                            if num1 < 10458754 then
                              tbl10[num7] = fn14 num1 = tbl10[num7] num1 = num1 and 8275742
                            else tbl8 = "pcall" num1 = tbl1[tbl8] fn53 = fn16(16358129, {tbl3[4];
                                  tbl3[1];
                                  tbl3[2];
                                  tbl3[3]}) tbl8 = num1(fn53) num1 = 1010808
                            end
                          else tbl25 = fn51 num1 = tbl20() tbl10[num1] = num3 num3 = num1 tbl5 = "\188\201\253\143\204" tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] tbl21 = 15839891168464 fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] fn49 = 14073502620057 fn12 = tbl10[tbl3[2]] tbl5 = tbl10[tbl3[3]] tbl7 = "Q \184\197A\223\0P\8216\402\180" tbl21 = tbl5(tbl7, fn49) tbl7 = "\206\251\8240\8364\247\230%!" tbl18 = fn12[tbl21] fn12 = tbl10[num3] tbl17 = tbl18..fn12 fn12 = tbl10[tbl3[2]] num1 = "Toggle" tbl5 = tbl10[tbl3[3]] fn49 = 9848347595241 tbl21 = tbl5(tbl7, fn49) tbl18 = fn12[tbl21] num1 = tbl11[num1] tbl5 = "\200\200\8221\187\8221" fn12 = fn13(15425561, {tbl3[2], tbl3[3];
                                num3, tbl3[9]}) tbl25 = nil fn14 = {[tbl22] = tbl17;
                              [tbl18] = fn12} tbl22 = "task" num1 = num1(tbl11, fn14) fn14 = tbl1[tbl22] tbl21 = 7424436489601 tbl17 = tbl10[tbl3[2]] tbl18 = tbl10[tbl3[3]] fn12 = tbl18(tbl5, tbl21) tbl22 = tbl17[fn12] num1 = fn14[tbl22] tbl22 = fn17(16476495, {tbl3[2], tbl3[3];
                                num3, tbl3[10]}) num3 = fn15(num3) fn14 = num1(tbl22) num1 = 7535927
                          end
                        else
                          if num1 < 10700043 then
                            if num1 < 10611918 then
                              num1 = true num1 = 12582487
                            else tbl8 = "_G" num1 = tbl1[tbl8] tbl12 = "\224\170\242" num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] tbl9 = 8595850317730 num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = fn53 fn53 = nil num1[tbl8] = num7 num1 = tbl1["xMPa78TkvIndLh"] tbl8 = {}
                            end
                          else num1 = tbl10[tbl3[4]] fn51 = 5975964764894 tbl9 = "Kick" tbl14 = "h\245\2\191\3J&\3819\225\\t\235\127\192" tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl9 = num1[tbl9] tbl9 = tbl9(num1, tbl24) num1 = 5843165
                          end
                        end
                      end
                    end
                  else
                    if num1 < 11447949 then
                      if num1 < 11169347 then
                        if num1 < 10961137 then
                          if num1 < 10935801 then
                            if num1 < 10908734 then
                              tbl16 = "_G" tbl25 = 1881935168364 tbl19 = tbl1[tbl16] num4 = num1 tbl11 = tbl10[tbl3[1]] tbl6 = "\164l\21<K\179\202^\206\255j" tbl14 = tbl10[tbl3[2]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl9 = num1 tbl24 = tbl19[tbl16] num1 = tbl24 and 5383141 tbl12 = tbl24
                            else tbl8 = tbl10[tbl3[2]] tbl12 = "z\174\222\217\184\220\160\8212\220" num7 = tbl10[tbl3[3]] num5 = tbl10[tbl3[4]] tbl9 = 22515273312500 num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] fn53 = num1 num1 = fn53 and 8383637 tbl8 = fn53
                            end
                          else num1 = 5902492 fn52 = 1 num2 = n[fn52] fn20 = num2
                          end
                        else
                          if num1 < 11069108 then
                            if num1 < 11052743 then
                              num5 = "pcall" num1 = 4750695 num4 = fn16(13456555, {fn53, tbl3[1], tbl3[2], tbl3[6], tbl3[7];
                                  tbl3[8]}) tbl8 = tbl1[num5] num7 = nil num5 = tbl8(num4)
                            else num1 = tbl10[tbl24] tbl17 = 1 tbl18 = 6 tbl22 = num1(tbl17, tbl18) num1 = "l2" tbl1[num1] = tbl22 tbl18 = "l2" tbl17 = tbl1[tbl18] tbl18 = 2 num1 = tbl17 > tbl18 num1 = num1 and 2247874
                            end
                          else tbl19 = tbl11 num1 = tbl14 num1 = tbl11 and 2080841
                          end
                        end
                      else
                        if num1 < 11268805 then
                          if num1 < 11247587 then
                            if num1 < 11179077 then
                              num1 = 11252416
                            else tbl9 = 32921093979106 fn53 = tbl2[1] tbl8 = "_G" num1 = tbl1[tbl8] tbl12 = "\175h\143,Y\8224+5>\165\338\144" num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = fn53 num1[tbl8] = num7 num1 = fn53 and 3636695
                            end
                          else num1 = true num1 = num1 and 3670598
                          end
                        else
                          if num1 < 11437709 then
                            if num1 < 11347204 then
                              num1 = 15645302 tbl8 = true tbl12 = tbl8
                            else num5 = 77 num7 = tbl10[tbl3[3]] fn53 = num7 * num5 num1 = 6981498 num7 = 257 tbl8 = fn53 % num7 tbl10[tbl3[3]] = tbl8
                            end
                          else tbl8 = tbl24 num1 = tbl19 num1 = 15859059
                          end
                        end
                      end
                    else
                      if num1 < 11580429 then
                        if num1 < 11507565 then
                          if num1 < 11488195 then
                            if num1 < 11463732 then
                              fn53 = tbl8 tbl8 = fn53 num1 = fn53 and 16207880
                            else num5 = "_G" tbl24 = "\250\24\250" num7 = tbl1[num5] num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl19 = 33641454157105 tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] fn53 = num7[num5] tbl8 = fn53 num1 = fn53 and 5715882
                            end
                          else num1 = tbl24 and 1651917
                          end
                        else
                          if num1 < 11551307 then
                            if num1 < 11518602 then
                              tbl16 = "Oa=\24" tbl11 = 29844986099273 tbl9 = tbl10[tbl3[1]] tbl24 = tbl10[tbl3[2]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num4 = fn53[tbl12] num1 = 3275861 num7 = num4
                            else num1 = 1448629 tbl10[num7] = tbl8
                            end
                          else num7 = 45.378063201904 num5 = 1412.0883789062 fn53 = 1536.8004150391 num1 = tbl10[tbl3[1]] tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["E2z3tqOztqSkU"]
                          end
                        end
                      else
                        if num1 < 11738202 then
                          if num1 < 11727551 then
                            if num1 < 11625689 then
                              fn14 = 5114258737485 num3 = 16627384491582 tbl12 = num5 tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl25 = "A\141\382?\18\150" tbl6 = fn51(tbl25, num3) num3 = "k\240\194\8230\164\17\376\205t\205" tbl11 = tbl14[tbl6] tbl16 = tbl9[tbl11] fn51 = tbl10[tbl3[2]] tbl6 = tbl10[tbl3[3]] tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] tbl11 = tbl9[tbl14] tbl19 = tbl16 < tbl11 num1 = tbl19 and 15353941 tbl24 = tbl19
                            else tbl17 = 30173752948450 tbl11 = 6810710690915 tbl9 = "\18\168F" num5 = tbl10[tbl3[1]] tbl24 = 23229195397696 num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl12 = "_G" tbl16 = "\8\339\239\8226k\r" num4 = tbl1[tbl12] fn51 = "\141z\8211\255\230\8218w" tbl9 = tbl10[tbl3[1]] fn53 = tbl8 tbl22 = "1\251-\24" tbl24 = tbl10[tbl3[2]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num5 = num4[tbl12] tbl16 = 33989286788563 tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl19 = "\381\197\8364," tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl25 = "\216wR\8(\141\175\25\184\186H\180\143\219YE\29l0k\243\15|\203f\144\217\17\227\381\20" tbl12 = tbl10[tbl3[3]] tbl16 = tbl10[tbl3[1]] num3 = 32484249402134 tbl6 = 10683419710318 tbl9 = "JSONEncode" tbl11 = tbl10[tbl3[2]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl14 = tbl10[tbl3[1]] tbl9 = tbl12[tbl9] fn51 = tbl10[tbl3[2]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] fn51 = tbl10[tbl3[4]] tbl25 = tbl10[tbl3[1]] num3 = tbl10[tbl3[2]] fn14 = num3(tbl22, tbl17) tbl6 = tbl25[fn14] tbl14 = fn51[tbl6] tbl16 = tbl11..tbl14 tbl24 = {[tbl19] = tbl16} tbl9 = tbl9(tbl12, tbl24) fn51 = 6625402391565 tbl11 = "\212\352\240N\8212(" tbl24 = tbl10[tbl3[1]] tbl14 = 22821047478658 tbl19 = tbl10[tbl3[2]] tbl25 = "K\209zD\230\2;+\200\129$\2" num3 = 34977918484383 tbl16 = tbl19(tbl11, tbl14) tbl12 = tbl24[tbl16] tbl14 = "\8221\189Eo" tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) fn51 = "\207}\217!\184D" tbl24 = tbl19[tbl11] tbl6 = 22004551673862 tbl16 = tbl10[tbl3[1]] tbl11 = tbl10[tbl3[2]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl14 = tbl10[tbl3[1]] fn51 = tbl10[tbl3[2]] tbl6 = fn51(tbl25, num3) num3 = "I\31m\240\1983\205\184\160J\27\240-@0[" tbl11 = tbl14[tbl6] fn51 = tbl10[tbl3[1]] fn14 = 22952132422079 tbl6 = tbl10[tbl3[2]] tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] tbl16 = {[tbl11] = tbl14} tbl8 = {[num7] = num5, [num4] = tbl9, [tbl12] = tbl24;
                                [tbl19] = tbl16} num1 = fn53(tbl8) fn53 = nil num1 = 9057667
                            end
                          else fn53 = "_G" tbl8 = tbl1[fn53] tbl12 = " \228d\6\15\206\402" num7 = tbl10[tbl3[1]] tbl9 = 31781371804111 num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] num1 = num1 and 1644147
                          end
                        else
                          if num1 < 11968332 then
                            if num1 < 11748685 then
                              num1 = tbl1["YPYPa2g66k6Mot"] tbl8 = {}
                            else tbl8 = {} num1 = fn53 fn53 = nil tbl10[tbl3[2]] = num1 num1 = tbl1["wZVWoZtEMgoD"]
                            end
                          else fn53 = fn15(fn53) num1 = 11252416
                          end
                        end
                      end
                    end
                  end
                end
              else
                if num1 < 14665412 then
                  if num1 < 13456075 then
                    if num1 < 12620150 then
                      if num1 < 12292536 then
                        if num1 < 12215228 then
                          if num1 < 12194879 then
                            if num1 < 12125629 then
                              num1 = 3063483
                            else num1 = tbl10[tbl3[1]] fn53 = -32.6 num7 = 19.3 num5 = 98.6 tbl8 = num1(fn53, num7, num5) num1 = tbl1["IFF6zwMjwnVror"] tbl8 = {}
                            end
                          else num1 = true num1 = num1 and 11066902
                          end
                        else
                          if num1 < 12227633 then
                            if num1 < 12216601 then
                              num1 = tbl1["lnBndtbpCIHan"] tbl8 = {} fn53 = nil
                            else num4 = "setfpscap" num5 = tbl1[num4] num1 = 6278284 tbl8 = num5
                            end
                          else tbl16 = 27979277054692 num5 = tbl10[tbl3[1]] tbl19 = "\243]V4\141{\219\8364\8" tbl12 = tbl10[tbl3[2]] num1 = 5654974 tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num7 = num5[num4] tbl8 = num7
                          end
                        end
                      else
                        if num1 < 12458306 then
                          if num1 < 12414316 then
                            if num1 < 12394529 then
                              num7 = "_G" fn53 = tbl1[num7] num5 = tbl10[tbl3[1]] tbl9 = "?4aO\202R\169k]\353" tbl24 = 2871894541625 num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl8 = fn53[num7] fn53 = tbl10[tbl3[3]] num1 = tbl8[fn53] num1 = num1 and 10527138
                            else tbl9 = 12709072082718 fn53 = "task" tbl8 = tbl1[fn53] num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl12 = "K\243\6\195" num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] fn53 = 700 tbl8 = num1(fn53) num1 = 14746840
                            end
                          else num1 = tbl10[tbl3[1]] num1 = num1 and 8793896
                          end
                        else
                          if num1 < 12570088 then
                            if num1 < 12498723 then
                              fn53 = tbl2[1] tbl8 = "_G" tbl9 = 7289465851202 num1 = tbl1[tbl8] tbl12 = " \213\1674i\170\192\196)\28}" num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl8 = num7[num4] num7 = fn53 num1[tbl8] = num7 num1 = fn53 and 5250705
                            else num7 = 5.56 fn53 = -227.55 num5 = 18.23 num1 = tbl10[tbl3[1]] tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["uD8k6H89d8sXv"]
                            end
                          else num1 = fn47(12108459, {num4}) tbl22 = {num1()} tbl8 = {fn46(tbl22)} num1 = tbl1["CKaizqXNXhXRrg"]
                          end
                        end
                      end
                    else
                      if num1 < 13032931 then
                        if num1 < 12848402 then
                          if num1 < 12744459 then
                            if num1 < 12717644 then
                              num5 = 2.97 num1 = tbl10[tbl3[1]] fn53 = 1270.9 num7 = 9.11 tbl8 = num1(fn53, num7, num5) num1 = tbl1["ddNWHJGOfP8aw"] tbl8 = {}
                            else fn53 = tbl2[1] tbl9 = "_G" tbl12 = tbl1[tbl9] tbl11 = "6xn(\27\180@\r(\201" tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] num5 = num1 tbl14 = 25413545258554 tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] num7 = num4 num1 = num4 and 1881042
                            end
                          else tbl9 = "task" tbl8 = tbl1[tbl9] tbl24 = tbl10[tbl3[3]] tbl19 = tbl10[tbl3[4]] tbl11 = "u\239A\t" tbl12 = nil tbl14 = 4498424432686 tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num1 = tbl8[tbl9] tbl9 = .04 tbl8 = num1(tbl9) num1 = 7488383
                          end
                        else
                          if num1 < 13017714 then
                            if num1 < 12897042 then
                              tbl24 = "\212$\186\8482\167+\194" tbl19 = 2870854190392 num1 = tbl12 num4[num1] = tbl8 tbl8 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) tbl16 = "\8249\221\227\195\2030\231XDL\248\8224o" num1 = tbl8[tbl9] tbl9 = tbl10[tbl3[1]] tbl24 = tbl10[tbl3[2]] tbl11 = 13995110553972 tbl19 = tbl24(tbl16, tbl11) tbl24 = "tostring" tbl12 = tbl9[tbl19] tbl9 = tbl1[tbl24] tbl24 = tbl9(fn53) tbl8 = tbl12..tbl24 num4[num1] = tbl8 tbl19 = 27177129275759 tbl24 = ":+y\206D\253" tbl8 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl9 = tbl12(tbl24, tbl19) num1 = tbl8[tbl9] tbl8 = num7 tbl11 = "\144\4+\127\215Sw\184\227\243gM" num4[num1] = tbl8 tbl24 = "\243 \209\6\223\204" tbl14 = 15144587795340 tbl8 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl19 = 31049075292282 tbl9 = tbl12(tbl24, tbl19) num1 = tbl8[tbl9] tbl12 = "game" tbl8 = tbl1[tbl12] tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl12 = "GetService" tbl12 = tbl8[tbl12] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl12 = tbl12(tbl8, tbl9) tbl8 = {num4} num4[num1] = tbl12 num1 = tbl1["7Cqk5xtkjlGDZj"]
                            else tbl8 = num7 num1 = num5 num1 = 4109513
                            end
                          else tbl8 = "Play" num1 = tbl10[tbl3[1]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 3516329
                          end
                        end
                      else
                        if num1 < 13173851 then
                          if num1 < 13117981 then
                            if num1 < 13043947 then
                              tbl19 = num1 num3 = "'Ovl$\179\352\211\14D\8222Q" tbl14 = "_G" tbl11 = tbl1[tbl14] fn51 = tbl10[tbl3[1]] tbl6 = tbl10[tbl3[2]] fn14 = 6988130389174 tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] tbl16 = tbl11[tbl14] num1 = tbl16 and 1390218 tbl24 = tbl16
                            else fn53 = tbl2[1] tbl8 = "tonumber" num1 = tbl1[tbl8] tbl8 = num1(fn53) num7 = tbl8 num1 = num7 and 340627
                            end
                          else tbl11 = tbl11 + tbl14 tbl6 = not fn51 tbl19 = tbl11 <= tbl16 tbl19 = tbl6 and tbl19 tbl6 = tbl11 >= tbl16 tbl6 = fn51 and tbl6 tbl19 = tbl6 or tbl19 tbl6 = 6361991 num1 = tbl19 and tbl6 tbl19 = 15652594 num1 = num1 or tbl19
                          end
                        else
                          if num1 < 13454703 then
                            if num1 < 13245149 then
                              tbl8 = "setfpscap" num1 = tbl1[tbl8] tbl12 = "math" num4 = tbl1[tbl12] tbl9 = tbl10[tbl3[1]] tbl11 = 13726623193335 tbl24 = tbl10[tbl3[2]] tbl16 = "\144\213\1\235," tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num5 = num4[tbl12] tbl9 = 240 tbl12 = 15 num4 = {num5(num7, tbl12, tbl9)} tbl8 = num1(fn46(num4)) num1 = 6389048
                            else num1 = tbl10[tbl3[3]] tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl14 = 9325525078262 tbl11 = "r:i\201\23" fn51 = 27015170814243 tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl14 = "_h\8249\200^8\24" tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl6 = 12156871005724 tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl16 = tbl10[tbl3[1]] fn51 = "\241H)\232\8222e\234" tbl11 = tbl10[tbl3[2]] num4 = "Notify" tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl6 = "\232C\82128\251\200\127\215\167\234\22\24\181\8211P\8216\732/\218q\220(\23'\230\185\r\160\215r\382" tbl11 = tbl10[tbl3[1]] tbl25 = 16326730030514 tbl14 = tbl10[tbl3[2]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] num4 = num1[num4] num3 = 17786096181338 tbl14 = tbl10[tbl3[1]] fn51 = tbl10[tbl3[2]] tbl25 = "kT\8216C\201\1P\191" tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl14 = 3 tbl12 = {[tbl9] = tbl24, [tbl19] = tbl16, [tbl11] = tbl14} num4 = num4(num1, tbl12) num1 = 2529856
                            end
                          else num5 = tbl10[tbl3[1]] fn53 = tbl2[1] num7 = fn53 == num5 num1 = num7 and 15867227 tbl8 = num7
                          end
                        end
                      end
                    end
                  else
                    if num1 < 14109759 then
                      if num1 < 13644848 then
                        if num1 < 13541548 then
                          if num1 < 13469664 then
                            if num1 < 13456723 then
                              tbl24 = "o\168\19/\7&3)\161G\"L=i" fn53 = tbl10[tbl3[1]] num7 = "FindFirstChild" num4 = tbl10[tbl3[2]] tbl19 = 25455579934285 tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num7 = fn53[num7] num7 = num7(fn53, num5) num1 = num7 and 5587640 tbl8 = num7
                            else tbl8 = tbl10[tbl3[1]] tbl16 = 14045629438348 tbl12 = 14526193834604 num7 = tbl10[tbl3[2]] num4 = "s890E" num5 = num7(num4, tbl12) num1 = tbl8[num5] tbl19 = "\8220I0\242" num4 = "Enum" num5 = tbl1[num4] tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num7 = num5[num4] num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl24 = "\222\168N\227\169\183\n\178\254Z" tbl19 = 12751269189425 tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] tbl19 = "'\179\174\129r\238\21" tbl8 = num7[num5] tbl24 = 22078645610537 fn53[num1] = tbl8 tbl9 = "9X89" num7 = "Instance" tbl8 = tbl1[num7] tbl16 = 22771976792428 num5 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num1 = tbl8[num7] num5 = tbl10[tbl3[1]] tbl9 = "\247\254\144\197\197--\244" tbl24 = 31290909718762 num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl12 = "#\402\381\8212\26" tbl8 = num1(num7, fn53) tbl9 = 12406652507793 num7 = tbl8 tbl8 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) num1 = tbl8[num4] num4 = "Color3" num5 = tbl1[num4] tbl12 = tbl10[tbl3[1]] tbl9 = tbl10[tbl3[2]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl8 = num5[num4] num4 = 3 tbl12 = 3 tbl9 = 3 num5 = tbl8(num4, tbl12, tbl9) tbl9 = 34161763925539 num7[num1] = num5 tbl12 = "\8224\2224\211\207F\3\239=" tbl8 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) tbl9 = 26401763061766 num1 = tbl8[num4] tbl8 = .9 num7[num1] = tbl8 tbl8 = tbl10[tbl3[1]] tbl12 = "\250\1766\144\169\223\193\177\167\200gv" num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) num1 = tbl8[num4] tbl8 = .175 num7[num1] = tbl8 num7 = nil num1 = 2554748
                            end
                          else num1 = num5 num1 = 10282318 tbl8 = num7
                          end
                        else
                          if num1 < 13631278 then
                            if num1 < 13566269 then
                              tbl9 = 29621984769505 tbl8 = "_G" num1 = tbl1[tbl8] tbl12 = "D\8249&\219\177\8224\n\167U" num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = num5(tbl12, tbl9) fn53 = tbl2[1] tbl8 = num7[num4] num7 = fn53 num1[tbl8] = num7 fn53 = nil num1 = tbl1["3QU5xOvhQyDN"] tbl8 = {}
                            else tbl8 = "l2" num1 = tbl1[tbl8] fn53 = "l1" tbl8 = tbl1[fn53] fn53 = "l1" tbl1[fn53] = num1 fn53 = "l2" tbl1[fn53] = tbl8 fn53 = tbl10[tbl3[1]] num1 = 3063483 num7 = fn53()
                            end
                          else num7, tbl12 = num5(fn53, num7) num1 = num7 and 1080761
                          end
                        end
                      else
                        if num1 < 13849830 then
                          if num1 < 13685923 then
                            if num1 < 13662783 then
                              fn20 = tbl10[num7] tbl8 = fn20 num1 = fn20 and 811920
                            else tbl8 = {} num1 = tbl1["wnUaat1xEBqO"] fn53 = nil
                            end
                          else tbl24 = 31112716794007 fn53 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl9 = "\218'\144\241\339\255" tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl8 = fn53[num7] tbl9 = 23943914187661 tbl12 = "\353\17\251\182(oY" num7 = tbl10[tbl3[2]] num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] tbl8 = "FireServer" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = tbl1["rvq4b3Re8jZdm"] tbl8 = {}
                          end
                        else
                          if num1 < 14052145 then
                            if num1 < 13925518 then
                              num5 = 1208.88 num1 = tbl10[tbl3[1]] num7 = 5.9 fn53 = 71.63 tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["LuGntFSwNcbZMl"]
                            else tbl8 = {} num1 = tbl1["zdLOByXoR5Hwc"]
                            end
                          else num7 = fn15(num7) tbl24 = fn15(tbl24) tbl12 = fn15(tbl12) tbl11 = fn15(tbl11) num7 = nil fn51 = nil tbl11 = tbl20() tbl6 = nil num3 = fn15(num3) num5 = fn15(num5) tbl14 = nil num5 = nil tbl24 = "math" tbl16 = fn15(tbl16) tbl25 = nil tbl19 = nil tbl9 = nil num4 = fn15(num4) tbl19 = "table" num4 = tbl20() tbl6 = {} tbl9 = "math" num1 = 7410641 tbl10[num4] = num7 num7 = tbl20() tbl14 = {} tbl10[num7] = num5 tbl12 = tbl1[tbl9] tbl9 = "floor" num5 = tbl12[tbl9] tbl12 = tbl20() tbl10[tbl12] = num5 tbl9 = tbl1[tbl24] fn51 = tbl20() tbl24 = "random" num5 = tbl9[tbl24] tbl24 = tbl1[tbl19] tbl19 = "remove" tbl25 = 1 num3 = 256 tbl9 = tbl24[tbl19] tbl16 = "string" tbl19 = tbl1[tbl16] tbl16 = "char" tbl24 = tbl19[tbl16] tbl19 = 0 tbl16 = tbl20() tbl10[tbl16] = tbl19 tbl19 = 2 tbl10[tbl11] = tbl19 tbl19 = {} tbl18 = num3 num3 = 1 fn12 = num3 tbl10[fn51] = tbl14 tbl14 = 0 num3 = 0 tbl5 = fn12 < num3 num3 = tbl25 - fn12
                          end
                        end
                      end
                    else
                      if num1 < 14417590 then
                        if num1 < 14267960 then
                          if num1 < 14245186 then
                            if num1 < 14215293 then
                              tbl14 = tbl10[tbl3[1]] num3 = 9002889744480 tbl25 = "O\8216\255\8222" fn51 = tbl10[tbl3[2]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl16 = tbl12[tbl11] tbl25 = "\212\200ky|" tbl14 = tbl10[tbl3[1]] num3 = 28357083902868 num1 = 15085228 fn51 = tbl10[tbl3[2]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl19 = tbl16 == tbl11 tbl9 = tbl19
                            else tbl19 = 25894812020506 fn53 = tbl20() tbl10[fn53] = tbl2[1] tbl8 = "Play" tbl24 = 14764733962971 num1 = tbl10[tbl3[1]] tbl8 = num1[tbl8] tbl8 = tbl8(num1) tbl8 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl9 = "\t\162\18K`" num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl11 = "\t\252\27" num1 = tbl8[num7] num7 = fn48(12445729, {tbl3[4];
                                  tbl3[1]}) tbl8 = "Connect" tbl9 = "\216KQ@\8240" tbl8 = num1[tbl8] tbl24 = 30026467112606 tbl8 = tbl8(num1, num7) tbl8 = tbl10[tbl3[4]] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num1 = tbl8[num7] tbl24 = 6361978751890 tbl8 = "Connect" num7 = fn13(14312154, {tbl3[4], fn53}) tbl8 = num1[tbl8] tbl8 = tbl8(num1, num7) num7 = "Instance" tbl8 = tbl1[num7] tbl9 = "\240\206\353" num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num1 = tbl8[num7] num5 = tbl10[tbl3[2]] tbl9 = "e$\221\215=\3\26#\251" num4 = tbl10[tbl3[3]] tbl24 = 17923585630362 tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl8 = num1(num7) num7 = tbl20() tbl9 = "\6n\191\192" tbl10[num7] = tbl8 num1 = tbl10[num7] tbl24 = 11480109208801 num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] tbl24 = "\163\11t\8250\242\"}\382-\168\210?\11F" num4 = tbl10[tbl3[2]] tbl14 = 19622041904049 tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num1[tbl8] = num5 num1 = tbl10[num7] num5 = tbl10[tbl3[2]] num4 = tbl10[tbl3[3]] tbl24 = 828722102657 tbl9 = "\1931|K\216\r" tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] tbl19 = 13827316996390 num5 = tbl10[tbl3[5]] num1[tbl8] = num5 num5 = "Instance" tbl8 = tbl1[num5] num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl24 = "\352\231\202" tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num1 = tbl8[num5] tbl19 = 26782547275959 num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl24 = "`~\710\8364x" tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num4 = tbl10[num7] tbl8 = num1(num5, num4) num5 = tbl20() tbl10[num5] = tbl8 num1 = tbl10[num5] tbl24 = "Bu\4x" num4 = tbl10[tbl3[2]] tbl19 = 442164003021 tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) tbl8 = num4[tbl9] tbl9 = "UDim2" tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] tbl16 = 150 tbl14 = 17076938055440 tbl24 = 350 tbl9 = 0 tbl19 = 0 tbl12 = num4(tbl9, tbl24, tbl19, tbl16) tbl24 = "\12\2396\31\175\18\236\205" num1[tbl8] = tbl12 tbl11 = "\243\163\243" num1 = tbl10[num5] tbl19 = 33665362378044 num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) tbl8 = num4[tbl9] tbl9 = "UDim2" tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] tbl9 = 0.5 tbl19 = 0.5 tbl24 = -175 tbl16 = -75 tbl12 = num4(tbl9, tbl24, tbl19, tbl16) num1[tbl8] = tbl12 num1 = tbl10[num5] tbl19 = 14604237183632 tbl14 = 24743857253634 tbl24 = "$n\191b\215\225\5\170\24\31R;B\195\157\180" num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) tbl8 = num4[tbl9] tbl9 = "Color3" tbl11 = "\8216\252\165\8218D\177\251" tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl22 = 22838987876747 tbl24 = 0 num4 = tbl12[tbl9] tbl19 = 5 tbl9 = 0 tbl12 = num4(tbl9, tbl24, tbl19) num1[tbl8] = tbl12 num1 = tbl10[num5] tbl24 = "L\8222L\246X\8226\227\19\216\187\160Wi\n^\163" num4 = tbl10[tbl3[2]] tbl14 = 26032214814554 tbl12 = tbl10[tbl3[3]] tbl19 = 25694806388413 tbl16 = 14204116556246 tbl9 = tbl12(tbl24, tbl19) tbl24 = "ql \338\244\228\27bzZU\12\238qh" tbl8 = num4[tbl9] tbl19 = 11420018382021 num4 = true num1[tbl8] = num4 fn51 = 17586740682749 num1 = tbl10[num5] num4 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) tbl8 = num4[tbl9] num4 = 0 num1[tbl8] = num4 num4 = "Instance" tbl8 = tbl1[num4] tbl12 = tbl10[tbl3[2]] tbl19 = "A\218\14" tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num1 = tbl8[num4] tbl16 = 19570445394841 tbl12 = tbl10[tbl3[2]] tbl19 = "\172.+\732\211|\15d" tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl19 = 33509252021491 tbl24 = "%`6<Z!\228\179-0\195\251" tbl12 = tbl10[num5] tbl8 = num1(num4, tbl12) num4 = tbl10[tbl3[2]] tbl11 = "\170\31\732" tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) num1 = num4[tbl9] num3 = 19624706171826 tbl9 = "UDim" tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] tbl9 = 0 tbl24 = 15 tbl12 = num4(tbl9, tbl24) num4 = "Instance" tbl8[num1] = tbl12 tbl16 = 1211428012596 tbl8 = tbl1[num4] tbl12 = tbl10[tbl3[2]] tbl19 = "\192\352\254" tbl9 = tbl10[tbl3[3]] fn53 = fn15(fn53) tbl24 = tbl9(tbl19, tbl16) tbl19 = "i\198)\196_\2183`\195X" num4 = tbl12[tbl24] num1 = tbl8[num4] tbl16 = 12851073750880 tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl6 = 19168829825758 tbl16 = 13962697218405 tbl12 = tbl10[num5] tbl8 = num1(num4, tbl12) tbl14 = 1000009777617 tbl24 = "\212!\8250\339" tbl19 = 4893472164070 num4 = tbl8 tbl8 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) tbl11 = "wh62" num1 = tbl8[tbl9] tbl19 = "\181\211v\248\230\8249\170\157.\216" tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) tbl8 = tbl12[tbl24] num4[num1] = tbl8 tbl19 = 34929719377801 tbl8 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl24 = "\8\23\2015" tbl9 = tbl12(tbl24, tbl19) num1 = tbl8[tbl9] tbl9 = "UDim2" tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl24 = 0 tbl19 = 1 tbl8 = tbl12[tbl9] tbl16 = 0 tbl9 = 1 tbl12 = tbl8(tbl9, tbl24, tbl19, tbl16) num4[num1] = tbl12 tbl8 = tbl10[tbl3[2]] tbl19 = 26369349726199 tbl24 = "cSP\1835" tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) tbl16 = 22517324065013 tbl14 = "\162u\141\8218/\204\240ji" num1 = tbl8[tbl9] tbl19 = "\249\231i\8226*z\r\248<m\179\208\185%\204\170\230fQ\171c\710\14t)\381r" tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) tbl8 = tbl12[tbl24] num4[num1] = tbl8 tbl8 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl24 = "z+\18\179f+\8218+\211" tbl19 = 35161773703157 tbl9 = tbl12(tbl24, tbl19) tbl24 = "Enum" num1 = tbl8[tbl9] tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) fn14 = 1443308061344 tbl24 = tbl19[tbl11] tbl11 = "h\252X\163" tbl12 = tbl9[tbl24] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl14 = 2097685922768 tbl16 = tbl19(tbl11, tbl14) tbl19 = 30003868726931 tbl14 = " 52\22N\2270E" tbl9 = tbl24[tbl16] tbl8 = tbl12[tbl9] num4[num1] = tbl8 tbl8 = tbl10[tbl3[2]] tbl24 = "\189\30\161\174\6I\183k\231$b\179\26\214S\381\197" tbl12 = tbl10[tbl3[3]] tbl11 = 6299605830517 fn51 = 20126922826908 tbl9 = tbl12(tbl24, tbl19) tbl24 = "\168\181\8482\220\216\29\222\236\143\192\219s\190\181\238\1687\168g\249z+" num1 = tbl8[tbl9] tbl8 = .45 num4[num1] = tbl8 tbl19 = 23948719434639 tbl8 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl9 = tbl12(tbl24, tbl19) tbl19 = 20021271553131 num1 = tbl8[tbl9] tbl8 = 1 num4[num1] = tbl8 tbl8 = tbl10[tbl3[2]] tbl12 = tbl10[tbl3[3]] tbl24 = "7T\253\206\163;" tbl9 = tbl12(tbl24, tbl19) tbl16 = "\238JV" num1 = tbl8[tbl9] tbl8 = 1 num4[num1] = tbl8 tbl12 = "Instance" tbl8 = tbl1[tbl12] tbl9 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl19 = tbl24(tbl16, tbl11) tbl12 = tbl9[tbl19] num1 = tbl8[tbl12] tbl9 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl11 = 14659159349930 tbl16 = "\"\710_\218\8211\8225\8\220" tbl19 = tbl24(tbl16, tbl11) tbl16 = 20849993655789 tbl12 = tbl9[tbl19] tbl9 = tbl10[num5] tbl8 = num1(tbl12, tbl9) tbl12 = tbl8 tbl8 = tbl10[tbl3[2]] tbl19 = "\219.\225I\2" tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num1 = tbl8[tbl24] tbl25 = 14477031332437 tbl24 = "Color3" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) tbl16 = 200 tbl24 = tbl19[tbl11] tbl19 = 250 tbl8 = tbl9[tbl24] tbl24 = 255 tbl9 = tbl8(tbl24, tbl19, tbl16) tbl16 = 6257334520673 tbl12[num1] = tbl9 tbl8 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl19 = "_W\247\171\30E#\8250[" tbl24 = tbl9(tbl19, tbl16) tbl14 = 4564592625741 tbl11 = "\172\27\232" tbl19 = "\213di\17U\2" tbl16 = 21292157675194 num1 = tbl8[tbl24] tbl8 = 2 tbl12[num1] = tbl8 tbl8 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl24 = tbl9(tbl19, tbl16) num1 = tbl8[tbl24] tbl8 = 2 tbl12[num1] = tbl8 tbl9 = "Instance" tbl8 = tbl1[tbl9] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num1 = tbl8[tbl9] tbl11 = " |\230\169\174\18\217\19y" tbl24 = tbl10[tbl3[2]] tbl14 = 4738324793502 tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl16 = "[gf\251" tbl24 = tbl10[num5] tbl8 = num1(tbl9, tbl24) tbl9 = tbl8 tbl8 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl11 = 3184723625419 fn51 = "\179\246U" tbl19 = tbl24(tbl16, tbl11) num1 = tbl8[tbl19] tbl19 = "UDim2" tbl12 = nil tbl24 = tbl1[tbl19] tbl16 = tbl10[tbl3[2]] tbl11 = tbl10[tbl3[3]] tbl14 = tbl11(fn51, tbl6) tbl11 = 0 tbl19 = tbl16[tbl14] tbl14 = 50 tbl6 = 13265603303457 tbl8 = tbl24[tbl19] tbl19 = 1 tbl16 = 0 tbl24 = tbl8(tbl19, tbl16, tbl11, tbl14) tbl11 = 29482182063520 tbl9[num1] = tbl24 tbl8 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl16 = "\218\8250o\234I\t\216t\170$:\238\170dA\4\236\21>\254\169E" tbl19 = tbl24(tbl16, tbl11) num1 = tbl8[tbl19] tbl16 = "=q\3\221" fn51 = "Pz\24\186\23\2011" tbl8 = 1 tbl11 = 28879530013832 tbl9[num1] = tbl8 tbl8 = tbl10[tbl3[2]] tbl14 = 30588848207780 tbl24 = tbl10[tbl3[3]] tbl19 = tbl24(tbl16, tbl11) num1 = tbl8[tbl19] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl11 = "\220\171\16\243.@m\7\232p," tbl16 = tbl19(tbl11, tbl14) tbl8 = tbl24[tbl16] tbl11 = 8501926514551 tbl9[num1] = tbl8 tbl16 = "6\161Y,\376N\0\224\198\31" tbl8 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl19 = tbl24(tbl16, tbl11) num1 = tbl8[tbl19] tbl19 = "Color3" tbl24 = tbl1[tbl19] tbl16 = tbl10[tbl3[2]] tbl11 = tbl10[tbl3[3]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl16 = 255 tbl11 = 255 tbl8 = tbl24[tbl19] tbl19 = 245 tbl24 = tbl8(tbl19, tbl16, tbl11) tbl16 = "Zv\8220\179,\376\240p" tbl9[num1] = tbl24 tbl8 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl11 = 28913728124056 tbl19 = tbl24(tbl16, tbl11) tbl16 = "\220\0V\243" num1 = tbl8[tbl19] tbl8 = 23 tbl11 = 34534141345489 tbl6 = "z\26\241\199" tbl9[num1] = tbl8 tbl8 = tbl10[tbl3[2]] tbl24 = tbl10[tbl3[3]] tbl19 = tbl24(tbl16, tbl11) num1 = tbl8[tbl19] tbl16 = "Enum" tbl19 = tbl1[tbl16] tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl16 = tbl10[tbl3[2]] tbl6 = 6580429769720 fn51 = "F\8\236%\202\178\203\30ty" tbl11 = tbl10[tbl3[3]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl14 = "Ar\211" tbl8 = tbl24[tbl19] tbl9[num1] = tbl8 tbl16 = "\30E\201\8212D\191" tbl8 = tbl10[tbl3[2]] tbl11 = 4243241404343 fn51 = 28439728550843 tbl24 = tbl10[tbl3[3]] tbl19 = tbl24(tbl16, tbl11) num1 = tbl8[tbl19] tbl24 = "Instance" tbl8 = 2 tbl9[num1] = tbl8 tbl8 = tbl1[tbl24] tbl25 = "\210\240\1" tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl9 = nil tbl11 = tbl16(tbl14, fn51) fn51 = 6325777042305 tbl24 = tbl19[tbl11] num1 = tbl8[tbl24] tbl19 = tbl10[tbl3[2]] tbl14 = "\248\163-\199\8249\20\22\232r" tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) tbl14 = "\202\376\178J" tbl24 = tbl19[tbl11] tbl19 = tbl10[num5] tbl8 = num1(tbl24, tbl19) tbl24 = tbl20() tbl10[tbl24] = tbl8 num1 = tbl10[tbl24] tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] fn51 = 5243251181961 tbl11 = tbl16(tbl14, fn51) tbl8 = tbl19[tbl11] tbl11 = "UDim2" tbl16 = tbl1[tbl11] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] num4 = nil tbl6 = 20 tbl14 = 0 tbl19 = tbl16[tbl11] fn51 = 0 tbl11 = 1 tbl16 = tbl19(tbl11, tbl14, fn51, tbl6) fn51 = 28843101107319 tbl14 = "\8249\402\161\402\220F\1294" num1[tbl8] = tbl16 num1 = tbl10[tbl24] tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl25 = "\246\8250\222" tbl11 = tbl16(tbl14, fn51) tbl8 = tbl19[tbl11] num3 = 5220652796287 tbl11 = "UDim2" tbl16 = tbl1[tbl11] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl6 = 0 tbl19 = tbl16[tbl11] fn51 = .45 tbl25 = "\r\1779)\23*\187" tbl11 = 0 tbl14 = 0 tbl16 = tbl19(tbl11, tbl14, fn51, tbl6) num1[tbl8] = tbl16 num1 = tbl10[tbl24] num3 = 15777686494387 tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl14 = "\1668{gd\193\17\353/5\240\243j\205\211\24\23\188I\239\240A" fn51 = 2027074749359 tbl11 = tbl16(tbl14, fn51) tbl8 = tbl19[tbl11] tbl19 = 1 num1[tbl8] = tbl19 num1 = tbl10[tbl24] fn51 = 30940787046471 tbl19 = tbl10[tbl3[2]] tbl14 = "K\165\288" tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) tbl8 = tbl19[tbl11] tbl6 = 40149418002 tbl16 = tbl10[tbl3[2]] fn51 = "\7J\8249\710\226S\236\212g^1\176\216\163_\23 " tbl11 = tbl10[tbl3[3]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] fn51 = 25975794183999 tbl14 = "\8217.MIl{\248#\2\144" num1[tbl8] = tbl19 num1 = tbl10[tbl24] tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) tbl8 = tbl19[tbl11] tbl11 = "Color3" tbl16 = tbl1[tbl11] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl19 = tbl16[tbl11] fn51 = 255 tbl11 = 255 tbl14 = 255 num3 = "Q\199\180u" tbl16 = tbl19(tbl11, tbl14, fn51) num1[tbl8] = tbl16 num1 = tbl10[tbl24] tbl19 = tbl10[tbl3[2]] fn51 = 6339755248520 tbl16 = tbl10[tbl3[3]] tbl14 = "F\352/\1688\206)\338" tbl11 = tbl16(tbl14, fn51) tbl8 = tbl19[tbl11] tbl19 = 16 tbl14 = "VP2:\27" num1[tbl8] = tbl19 num1 = tbl10[tbl24] tbl19 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] fn51 = 5450581428714 tbl11 = tbl16(tbl14, fn51) tbl14 = "Enum" tbl8 = tbl19[tbl11] tbl11 = tbl1[tbl14] fn51 = tbl10[tbl3[2]] tbl6 = tbl10[tbl3[3]] tbl25 = tbl6(num3, fn14) tbl14 = fn51[tbl25] tbl16 = tbl11[tbl14] tbl25 = "\7\6\193\18\252g" tbl14 = tbl10[tbl3[2]] num3 = 26466678091812 fn51 = tbl10[tbl3[3]] fn14 = "\246\339\\" tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl19 = tbl16[tbl11] num1[tbl8] = tbl19 fn51 = 11707915949387 num1 = tbl10[tbl24] tbl19 = tbl10[tbl3[2]] tbl14 = "\250\190\211i\127\169" tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) tbl8 = tbl19[tbl11] tbl19 = 3 num1[tbl8] = tbl19 fn51 = "8\180\12" tbl19 = "Instance" tbl8 = tbl1[tbl19] tbl16 = tbl10[tbl3[2]] tbl11 = tbl10[tbl3[3]] tbl6 = 22735465736539 tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] num1 = tbl8[tbl19] tbl16 = tbl10[tbl3[2]] tbl6 = 31031270717554 fn51 = "\168\8222\16\242\129" num3 = 25920189361958 tbl11 = tbl10[tbl3[3]] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl16 = tbl10[num5] tbl8 = num1(tbl19, tbl16) tbl14 = "\27\184T7" tbl19 = tbl8 tbl8 = tbl10[tbl3[2]] fn51 = 16446240742890 tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) tbl25 = "\204Vo" num1 = tbl8[tbl11] tbl11 = "UDim2" tbl16 = tbl1[tbl11] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] num3 = 10744050701195 fn51 = 0 tbl8 = tbl16[tbl11] tbl14 = 0 tbl11 = .8 tbl6 = 6 tbl16 = tbl8(tbl11, tbl14, fn51, tbl6) tbl19[num1] = tbl16 fn51 = 15015728438096 tbl14 = "\0\215\143\189\166\163\177\8221" tbl8 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) num1 = tbl8[tbl11] tbl11 = "UDim2" tbl16 = tbl1[tbl11] tbl14 = tbl10[tbl3[2]] tbl25 = "\t\185}" fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) fn51 = .8 tbl11 = tbl14[tbl6] tbl6 = 0 tbl8 = tbl16[tbl11] tbl11 = .1 num3 = 10420204540660 tbl14 = 0 tbl16 = tbl8(tbl11, tbl14, fn51, tbl6) tbl19[num1] = tbl16 tbl8 = tbl10[tbl3[2]] fn51 = 19615347286958 tbl25 = "\203\224\251\12\254:A" tbl16 = tbl10[tbl3[3]] tbl14 = "\174\194\188\224\338\31:B\21\163\21\181\203\223L\227" tbl11 = tbl16(tbl14, fn51) num1 = tbl8[tbl11] tbl11 = "Color3" tbl16 = tbl1[tbl11] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl14 = 182 tbl6 = "\30E\18" tbl25 = 32880950590415 tbl8 = tbl16[tbl11] fn51 = 193 tbl11 = 255 tbl16 = tbl8(tbl11, tbl14, fn51) tbl14 = "N\191\247\16\8222|" fn51 = 19245977232130 tbl19[num1] = tbl16 tbl8 = tbl10[tbl3[2]] tbl16 = tbl10[tbl3[3]] tbl11 = tbl16(tbl14, fn51) num1 = tbl8[tbl11] tbl8 = 3 tbl16 = "Instance" tbl19[num1] = tbl8 tbl8 = tbl1[tbl16] tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] num1 = tbl8[tbl16] tbl25 = 4149560559500 tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] tbl6 = "\19\231LX\204q\247G" fn51 = tbl14(tbl6, tbl25) tbl25 = 18595746472403 tbl16 = tbl11[fn51] tbl8 = num1(tbl16, tbl19) tbl16 = "Instance" tbl6 = "\206\191\6" tbl8 = tbl1[tbl16] tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl25 = 12173609817636 num1 = tbl8[tbl16] tbl11 = tbl10[tbl3[2]] tbl6 = "$\144\226\229\251" tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl8 = num1(tbl16, tbl19) tbl16 = tbl20() tbl10[tbl16] = tbl8 tbl25 = 10729990345604 num1 = tbl10[tbl16] tbl11 = tbl10[tbl3[2]] tbl6 = "\8221\208~~" tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl8 = tbl11[fn51] fn51 = "UDim2" tbl14 = tbl1[fn51] tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] num3 = 0 tbl25 = 1 fn14 = "\191\239\2004\168\227\r" tbl11 = tbl14[fn51] tbl6 = 0 fn51 = 0 tbl14 = tbl11(fn51, tbl6, tbl25, num3) tbl6 = "k2&\186*\205\8217g6I\8230\240\339\8216\161q" num1[tbl8] = tbl14 num1 = tbl10[tbl16] tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] tbl25 = 5428966263264 fn51 = tbl14(tbl6, tbl25) tbl8 = tbl11[fn51] fn51 = "Color3" tbl14 = tbl1[fn51] tbl22 = 17055767387910 tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] num3 = 25053672435090 tbl6 = 250 tbl11 = tbl14[fn51] tbl25 = 255 fn51 = 255 tbl14 = tbl11(fn51, tbl6, tbl25) tbl6 = "\232k\254x \184" num1[tbl8] = tbl14 num1 = tbl10[tbl16] tbl25 = 28082239058708 tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl8 = tbl11[fn51] tbl11 = 4 num1[tbl8] = tbl11 tbl11 = "Instance" tbl8 = tbl1[tbl11] tbl25 = "\233cs" tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl19 = nil num1 = tbl8[tbl11] tbl14 = tbl10[tbl3[2]] num3 = 10714496406397 tbl25 = "\214\240j\8212\224>\228\24" fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl14 = tbl10[tbl16] tbl8 = num1(tbl11, tbl14) tbl11 = "task" num3 = 33302891854995 tbl8 = tbl1[tbl11] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl25 = "lC\167\177\253" tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] num1 = tbl8[tbl11] tbl11 = fn13(3441719, {tbl3[6], tbl16;
                                  tbl3[2];
                                  tbl3[3], tbl24;
                                  tbl3[7], num5;
                                  num7}) tbl16 = fn15(tbl16) tbl8 = num1(tbl11) num7 = fn15(num7) tbl8 = {} num5 = fn15(num5) num1 = tbl1["E8pNdBuGqIXIz"] tbl24 = fn15(tbl24)
                            end
                          else num1 = tbl10[tbl3[1]] tbl14 = 26262866980805 num5 = tbl2[3] num7 = tbl2[2] num3 = 24644631407828 tbl25 = 8617868316589 tbl11 = "\172$\189" tbl9 = "TweenInfo" tbl12 = tbl1[tbl9] fn53 = tbl2[1] tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl6 = "\253\246\31 &#|\2v&[" tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] tbl16 = "Enum" tbl19 = tbl1[tbl16] tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl25 = "C\211\8220\30!r.\5#\201\26[<\223_" tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl8 = "Create" tbl16 = tbl10[tbl3[2]] fn51 = "\169\225\352\247-" tbl6 = 32000153287221 tbl11 = tbl10[tbl3[3]] tbl14 = tbl11(fn51, tbl6) tbl11 = "Enum" tbl8 = num1[tbl8] tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] tbl16 = tbl1[tbl11] tbl14 = tbl10[tbl3[2]] fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl6 = "7\169\\" tbl19 = tbl16[tbl11] tbl11 = tbl10[tbl3[2]] tbl14 = tbl10[tbl3[3]] tbl25 = 29060011111644 fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl12 = num4(num7, tbl9, tbl24) tbl8 = tbl8(num1, fn53, tbl12, num5) num4 = tbl8 num1 = "Play" num1 = num4[num1] tbl8 = {num4} num1 = num1(num4) num1 = tbl1["ul5djmA7HKRO"]
                          end
                        else
                          if num1 < 14378437 then
                            if num1 < 14340492 then
                              num1 = tbl10[tbl3[1]] num1 = num1 and 3443208
                            else tbl8 = {} num1 = tbl1["SCrBPd578Prf"]
                            end
                          else num1 = tbl10[tbl3[1]] tbl8 = "Play" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 4623229
                          end
                        end
                      else
                        if num1 < 14644691 then
                          if num1 < 14640704 then
                            if num1 < 14517475 then
                              num7 = 5.25 fn53 = -1226.98 num5 = 1240.85 num1 = tbl10[tbl3[1]] tbl8 = num1(fn53, num7, num5) tbl8 = {} num1 = tbl1["WjVheP9mHKUQ"]
                            else fn53 = nil num1 = 8480933
                            end
                          else tbl8 = "tonumber" fn53 = tbl2[1] num1 = tbl1[tbl8] tbl8 = num1(fn53) num7 = tbl8 num1 = num7 and 12221845 tbl8 = num7
                          end
                        else
                          if num1 < 14652186 then
                            if num1 < 14648842 then
                              num7 = "settings" tbl8 = tbl1[num7] num7 = tbl8() tbl9 = "(di\248\179\180\402\8249\8225" fn53 = tbl2[1] tbl24 = 34461684170415 num5 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) tbl8 = num5[tbl12] num1 = num7[tbl8] tbl12 = "\27~\252\186\19\194\143\234>\n\224\203" num7 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl9 = 33130553162819 num4 = num5(tbl12, tbl9) num5 = num1 tbl9 = 1 tbl12 = num1 tbl8 = num7[num4] num4 = fn53 and tbl9 fn53 = nil tbl12 = 5 num7 = num4 or tbl12 num1[tbl8] = num7 num1 = tbl1["KnOw75jb04s2Y"] tbl8 = {}
                            else num7 = num5 num1 = tbl10[tbl3[1]] tbl16 = 255 tbl19 = 0 tbl24 = num1(tbl19, tbl16) fn53[num7] = tbl24 num1 = 4696189 num7 = nil
                            end
                          else tbl24 = "GenerateGUID" tbl19 = false num1 = 12849884 tbl9 = tbl10[tbl3[3]] tbl24 = tbl9[tbl24] tbl24 = tbl24(tbl9, tbl19) tbl8 = tbl24
                          end
                        end
                      end
                    end
                  end
                else
                  if num1 < 15651294 then
                    if num1 < 15103838 then
                      if num1 < 14907710 then
                        if num1 < 14745016 then
                          if num1 < 14734325 then
                            if num1 < 14701250 then
                              num1 = tbl8 and 16508455
                            else tbl9 = "_G" tbl12 = tbl1[tbl9] tbl24 = tbl10[tbl3[1]] tbl19 = tbl10[tbl3[2]] tbl11 = "OW\1\166-\223\207D(m\220\219\27\166|\8250UL" tbl14 = 13462574831741 tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num1 = 5346630 num4 = tbl12[tbl9] num7 = num4
                            end
                          else tbl19 = 11781387965806 tbl24 = "\25\211i\"\8240\181\225" tbl8 = tbl10[tbl3[3]] num4 = "\30\196\8211ABOb" tbl12 = 11914873968044 num7 = tbl10[tbl3[4]] num5 = num7(num4, tbl12) num1 = tbl8[num5] num4 = tbl10[tbl3[3]] tbl12 = tbl10[tbl3[4]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num7 = fn53[num5] tbl8 = not num7 fn53[num1] = tbl8 num1 = 14623972
                          end
                        else
                          if num1 < 14820189 then
                            if num1 < 14772513 then
                              num1 = true num1 = num1 and 11737498
                            else tbl8 = "pairs" tbl12 = "GetDescendants" num1 = tbl1[tbl8] num4 = "game" num5 = tbl1[num4] tbl12 = num5[tbl12] num4 = {tbl12(num5)} num5 = {num1(fn46(num4))} fn53 = num5[2] tbl8 = num5[1] num7 = num5[3] num1 = 9316761 num5 = tbl8
                            end
                          else tbl11 = 20008764220517 tbl9 = tbl10[tbl3[1]] tbl16 = "\218\213a~x\26\222{" tbl24 = tbl10[tbl3[2]] tbl19 = tbl24(tbl16, tbl11) tbl16 = "Enum" tbl25 = 12594236987112 num1 = tbl9[tbl19] tbl19 = tbl1[tbl16] tbl11 = tbl10[tbl3[1]] tbl14 = tbl10[tbl3[2]] tbl6 = "\239G1j\25\143\710\219" fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] tbl6 = 9709677695401 tbl16 = tbl10[tbl3[1]] tbl11 = tbl10[tbl3[2]] fn51 = "\181\8249\11\195lZ4\25\253\252J\120" tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] tbl12[num1] = tbl9 num1 = 8356789
                          end
                        end
                      else
                        if num1 < 15037761 then
                          if num1 < 14967414 then
                            if num1 < 14925826 then
                              num1 = tbl10[tbl3[4]] tbl8 = "Play" tbl8 = num1[tbl8] tbl8 = tbl8(num1) num1 = 8960564
                            else num7 = num4 num1 = tbl12 num1 = 13479283
                            end
                          else tbl8 = "pairs" num1 = tbl1[tbl8] tbl12 = tbl10[tbl3[1]] tbl11 = "=\338\8225\5\25\226\221#\8240" tbl14 = 28262412989288 tbl24 = tbl10[tbl3[2]] tbl19 = tbl10[tbl3[3]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] tbl9 = "GetDescendants" tbl9 = num4[tbl9] tbl12 = {tbl9(num4)} num4 = {num1(fn46(tbl12))} tbl8 = num4[1] num5 = num4[3] num7 = num4[2] num1 = 6683176 num4 = tbl8
                          end
                        else
                          if num1 < 15086312 then
                            if num1 < 15080726 then
                              num7 = tbl10[tbl3[6]] num1 = num7 and 12238496 tbl8 = num7
                            else tbl8 = tbl9 num1 = tbl24 num1 = 4804388
                            end
                          else fn53 = tbl2[1] num1 = fn53 and 8237801
                          end
                        end
                      end
                    else
                      if num1 < 15353881 then
                        if num1 < 15208016 then
                          if num1 < 15177960 then
                            if num1 < 15112865 then
                              num1 = tbl1["Mw2PGyVJgpDVg"] tbl8 = {} fn53 = nil
                            else tbl16 = "_G" tbl19 = tbl1[tbl16] tbl6 = "\20\210\19\17\8225\255\218c\233f\222\176" tbl11 = tbl10[tbl3[2]] tbl9 = num1 tbl25 = 20258237474009 tbl14 = tbl10[tbl3[3]] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl24 = tbl19[tbl16] num1 = tbl24 and 6922516 tbl8 = tbl24
                            end
                          else tbl8 = "error" num1 = tbl1[tbl8] fn53 = "Tamper Detected!" tbl8 = num1(fn53) num1 = tbl1["wq3YKo5wbFHhzR"] tbl8 = {}
                          end
                        else
                          if num1 < 15316124 then
                            if num1 < 15268834 then
                              num1 = tbl10[tbl3[10]] num7 = tbl10[tbl3[11]] fn53[num1] = num7 num1 = tbl10[tbl3[12]] num7 = {num1(fn53)} tbl8 = {fn46(num7)} num1 = tbl1["E9zUEGqx75RH6w"]
                            else num1 = true tbl10[tbl3[1]] = num1 fn51 = 31223790139595 num5 = true tbl8 = tbl10[tbl3[5]] tbl24 = "Enum" tbl14 = "\8482\254RK\206\244\t" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[3]] tbl16 = tbl10[tbl3[4]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] num7 = "SendKeyEvent" tbl24 = tbl10[tbl3[3]] tbl14 = 15918409112820 tbl19 = tbl10[tbl3[4]] tbl11 = "\173w\204" tbl16 = tbl19(tbl11, tbl14) num7 = tbl8[num7] tbl9 = tbl24[tbl16] tbl24 = "game" num4 = tbl12[tbl9] tbl9 = tbl1[tbl24] tbl19 = 33018322271247 tbl24 = "\211ZE\157" tbl12 = false num7 = num7(tbl8, num5, num4, tbl12, tbl9) fn51 = 1777052287803 num5 = "task" num7 = tbl1[num5] num4 = tbl10[tbl3[3]] tbl12 = tbl10[tbl3[4]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] tbl8 = num7[num5] num5 = .05 num7 = tbl8(num5) tbl8 = tbl10[tbl3[5]] num5 = false tbl14 = "\2183\8364Z\8250L\230" tbl24 = "Enum" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[3]] tbl16 = tbl10[tbl3[4]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl11 = "QS~" num7 = "SendKeyEvent" tbl12 = tbl9[tbl24] num1 = 7363289 tbl14 = 17352932630416 num7 = tbl8[num7] tbl24 = tbl10[tbl3[3]] tbl19 = tbl10[tbl3[4]] tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] tbl19 = 34501554192066 num4 = tbl12[tbl9] tbl12 = false tbl24 = "game" tbl9 = tbl1[tbl24] num7 = num7(tbl8, num5, num4, tbl12, tbl9) num5 = "task" num7 = tbl1[num5] tbl24 = "a\1j\193" num4 = tbl10[tbl3[3]] tbl12 = tbl10[tbl3[4]] tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] tbl8 = num7[num5] num5 = .3 num7 = tbl8(num5) tbl8 = false tbl10[tbl3[1]] = tbl8
                            end
                          else num5 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl19 = "\240\223\18\2129\246G\7\22" tbl9 = tbl10[tbl3[3]] tbl16 = 30148189075158 tbl24 = tbl9(tbl19, tbl16) num1 = 2482325 num4 = tbl12[tbl24] num7 = num5[num4] tbl8 = num7
                          end
                        end
                      else
                        if num1 < 15449880 then
                          if num1 < 15417704 then
                            if num1 < 15367618 then
                              tbl14 = tbl10[tbl3[2]] num3 = 6973720005807 tbl25 = "\180\212" fn51 = tbl10[tbl3[3]] tbl6 = fn51(tbl25, num3) tbl11 = tbl14[tbl6] tbl22 = 2602261267643 fn51 = "game" tbl16 = tbl9[tbl11] tbl14 = tbl1[fn51] num1 = 11489629 fn14 = "\218\8212K\199K" tbl6 = tbl10[tbl3[2]] tbl25 = tbl10[tbl3[3]] num3 = tbl25(fn14, tbl22) fn51 = tbl6[num3] tbl11 = tbl14[fn51] tbl19 = tbl16 ~= tbl11 tbl24 = tbl19
                            else num1 = tbl10[tbl3[1]] num7 = 5.2 fn53 = -1598.4 num5 = 1647.7 tbl8 = num1(fn53, num7, num5) num1 = tbl1["s1mdJHgtEkdY"] tbl8 = {}
                            end
                          else tbl24 = 5207674603897 fn53 = tbl2[1] num7 = "_G" tbl8 = tbl1[num7] num5 = tbl10[tbl3[1]] tbl9 = "nc\8224\163p\209\6v\20\223" num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num1 = tbl8[num7] num7 = fn53 tbl8 = tbl10[tbl3[3]] num1[tbl8] = num7 num1 = fn53 and 14920717
                          end
                        else
                          if num1 < 15535372 then
                            if num1 < 15461749 then
                              tbl12 = tbl10[tbl3[1]] num1 = 422965 tbl9 = tbl10[tbl3[2]] tbl16 = 800155451764 tbl19 = "\8220\243[\189\230\165\243\207dH\197\8364_" tbl24 = tbl9(tbl19, tbl16) fn51 = 26396050059267 num4 = tbl12[tbl24] num5 = fn53[num4] tbl14 = "\201\18\249\2101\141o\353\1-a\732\8221" tbl24 = "Enum" tbl9 = tbl1[tbl24] tbl19 = tbl10[tbl3[1]] tbl16 = tbl10[tbl3[2]] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl12 = tbl9[tbl24] tbl24 = tbl10[tbl3[1]] tbl11 = "\246\237\200\352=" tbl19 = tbl10[tbl3[2]] tbl14 = 17729928814656 tbl16 = tbl19(tbl11, tbl14) tbl9 = tbl24[tbl16] num4 = tbl12[tbl9] num7 = num5 == num4 tbl8 = num7
                            else num1 = tbl1["Hb8ewP7cmUYv"] num7 = nil fn53 = nil tbl8 = {}
                            end
                          else tbl24 = not tbl12 num1 = tbl24 and 3152305
                          end
                        end
                      end
                    end
                  else
                    if num1 < 15965354 then
                      if num1 < 15734483 then
                        if num1 < 15676328 then
                          if num1 < 15669061 then
                            if num1 < 15654385 then
                              tbl24 = nil num1 = 5762685 tbl9 = nil num4 = nil
                            else num1 = false tbl10[tbl3[4]] = num1 num1 = 14348461
                            end
                          else num1 = 6945413 tbl9 = tbl10[tbl12] tbl8 = tbl9
                          end
                        else
                          if num1 < 15713767 then
                            if num1 < 15701447 then
                              num7 = "task" fn53 = tbl1[num7] tbl9 = "\190\193SK" tbl24 = 13586685401270 num5 = tbl10[tbl3[1]] num4 = tbl10[tbl3[2]] tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] num1 = fn53[num7] num7 = 5 fn53 = num1(num7) num1 = 9667905
                            else tbl18 = "l2" num1 = tbl1[tbl18] tbl18 = "l1" tbl1[tbl18] = num1 num1 = 2988398
                            end
                          else num1 = tbl8 and 5120053
                          end
                        end
                      else
                        if num1 < 15866731 then
                          if num1 < 15853110 then
                            if num1 < 15738861 then
                              num1 = 6842619 num4 = "HttpPost" num5 = tbl1[num4] fn53 = num5
                            else fn53 = fn15(fn53) tbl8 = {} num1 = tbl1["4nd10g1vDhEOh3"]
                            end
                          else num1 = tbl9 num1 = tbl8 and 11333620
                          end
                        else
                          if num1 < 15935096 then
                            if num1 < 15867797 then
                              num7 = tbl10[tbl3[2]] tbl8 = num7 num1 = 345352
                            else num1 = true num1 = num1 and 8394393
                            end
                          else num1 = tbl1["4lEbj5ZGOwto"] tbl8 = {}
                          end
                        end
                      end
                    else
                      if num1 < 16446179 then
                        if num1 < 16219629 then
                          if num1 < 16196862 then
                            if num1 < 16008337 then
                              tbl8 = {} num1 = tbl1["UsZRolIvjbjHPu"] fn53 = nil
                            else num7 = fn53 num5 = num1 num1 = fn53 and 11518145
                            end
                          else tbl19 = "'\234t[" tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] tbl16 = 30173184128738 tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] tbl19 = "" num5 = fn53[num4] tbl16 = 7530033909170 tbl12 = tbl10[tbl3[2]] tbl9 = tbl10[tbl3[3]] num1 = 2577488 tbl24 = tbl9(tbl19, tbl16) num4 = tbl12[tbl24] num7 = num5 ~= num4 tbl8 = num7
                          end
                        else
                          if num1 < 16409950 then
                            if num1 < 16328213 then
                              num1 = {} num7 = 1 fn53 = num1 num5 = tbl10[tbl3[9]] num4 = num5 num5 = 1 num1 = 4696189 tbl12 = num5 num5 = 0 tbl9 = tbl12 < num5 num5 = num7 - tbl12
                            else fn53 = tbl10[tbl3[1]] num5 = tbl10[tbl3[2]] tbl9 = "]\181\212OG&" num4 = tbl10[tbl3[3]] tbl24 = 19091294560954 tbl12 = num4(tbl9, tbl24) num7 = num5[tbl12] tbl9 = 18590045446608 tbl8 = fn53[num7] num7 = tbl10[tbl3[2]] tbl12 = "\198\141f\230M\206\252W" num5 = tbl10[tbl3[3]] num4 = num5(tbl12, tbl9) fn53 = num7[num4] num1 = tbl8[fn53] tbl8 = "FireServer" fn53 = tbl10[tbl3[4]] tbl8 = num1[tbl8] tbl8 = tbl8(num1, fn53) num1 = tbl1["KQP5cuBk98KpYn"] tbl8 = {}
                            end
                          else num1 = tbl8 and 5875792
                          end
                        end
                      else
                        if num1 < 16484179 then
                          if num1 < 16470662 then
                            if num1 < 16464145 then
                              num1 = 6910783
                            else num1 = fn53 tbl10[tbl3[3]] = num1 num1 = 15969870
                            end
                          else num1 = 10357465
                          end
                        else
                          if num1 < 16639364 then
                            if num1 < 16610877 then
                              num5 = "task" tbl19 = 9123941994648 tbl8 = tbl1[num5] num4 = tbl10[tbl3[1]] tbl12 = tbl10[tbl3[2]] tbl24 = "\26b\222\8240" tbl9 = tbl12(tbl24, tbl19) num5 = num4[tbl9] num1 = tbl8[num5] num5 = .1 tbl8 = num1(num5) tbl8 = .1 num1 = num7 + tbl8 num7 = num1 num1 = 3863470
                            else fn12 = tbl20() tbl5 = "setmetatable" tbl21 = {} num3 = tbl20() tbl25 = {} tbl18 = fn47(3395290, {num3;
                                  tbl16, tbl11, tbl12}) tbl10[num3] = tbl25 tbl25 = tbl20() tbl24 = nil tbl9 = nil tbl10[tbl25] = tbl18 tbl12 = fn15(tbl12) tbl19 = nil num5 = nil fn49 = "__index" tbl18 = {} tbl10[fn12] = tbl18 tbl18 = tbl1[tbl5] fn52 = nil tbl13 = tbl10[fn12] n = "__metatable" tbl7 = {[fn49] = tbl13, [n] = fn52} tbl5 = tbl18(tbl21, tbl7) tbl18 = fn17(477437, {fn12;
                                  num3;
                                  fn51;
                                  tbl16;
                                  tbl11;
                                  tbl25}) tbl14 = nil tbl10[num7] = tbl5 num3 = fn15(num3) fn12 = fn15(fn12) tbl16 = fn15(tbl16) tbl14 = "\205Q\178\208_\21_" fn51 = fn15(fn51) tbl11 = fn15(tbl11) tbl10[num4] = tbl18 tbl25 = fn15(tbl25) tbl16 = 24371842477141 tbl6 = nil fn51 = 19380051862336 tbl19 = "\20\234o\20\710\382\8217O\193\8482TU#\24" tbl12 = tbl10[num7] tbl9 = tbl10[num4] tbl24 = tbl9(tbl19, tbl16) tbl9 = "game" num5 = tbl12[tbl24] tbl12 = tbl1[tbl9] tbl19 = tbl10[num7] tbl16 = tbl10[num4] tbl11 = tbl16(tbl14, fn51) tbl24 = tbl19[tbl11] tbl9 = "GetService" tbl9 = tbl12[tbl9] tbl9 = tbl9(tbl12, tbl24) tbl12 = tbl20() tbl10[tbl12] = tbl9 tbl24 = tbl10[tbl12] fn51 = "\18M\161\229\24\144\16Cco\231" tbl6 = 27167466369386 tbl16 = tbl10[num7] tbl25 = 1833585902421 tbl11 = tbl10[num4] tbl14 = tbl11(fn51, tbl6) tbl19 = tbl16[tbl14] tbl9 = tbl24[tbl19] tbl19 = "game" tbl24 = tbl20() tbl6 = "_\8224\18\15\192\220b" tbl10[tbl24] = tbl9 tbl9 = tbl1[tbl19] tbl11 = tbl10[num7] tbl14 = tbl10[num4] fn51 = tbl14(tbl6, tbl25) tbl16 = tbl11[fn51] tbl19 = "GetService" tbl14 = num1 tbl19 = tbl9[tbl19] tbl6 = "gethui" tbl19 = tbl19(tbl9, tbl16) tbl16 = num1 tbl9 = tbl20() tbl10[tbl9] = tbl19 fn51 = tbl1[tbl6] num1 = fn51 and 6299019 tbl11 = fn51
                            end
                          else tbl8 = {} num1 = tbl1["yAEI75zfDzyc"]
                          end
                        end
                      end
                    end
                  end
                end
              end
            end
          end
          num1 = # tbl4
          return fn46(tbl8)
        end, function (tbl1) fn53[tbl1] = fn53[tbl1] - 1
          if false [tbl1] then
            fn53[tbl1], tbl10[tbl1] = nil, nil
          end
        end, function (tbl1, fn45)
          local fn46 = num5(fn45)
          local tbl2 = function (tbl2, tbl3, tbl4)
            return num1(tbl1, {tbl2, tbl3, tbl4}, fn45, fn46)
          end
          return tbl2
        end, function (tbl1, fn45)
          local fn46 = num5(fn45)
          local tbl2 = function (...)
            return num1(tbl1, {...}, fn45, fn46)
          end
          return tbl2
        end, function (tbl1, fn45)
          local fn46 = num5(fn45)
          local tbl2 = function ()
            return num1(tbl1, {}, fn45, fn46)
          end
          return tbl2
        end, function (tbl1, fn45)
          local fn46 = num5(fn45)
          local tbl2 = function (tbl2, tbl3, tbl4, fn50)
            return num1(tbl1, {tbl2, tbl3, tbl4, fn50}, fn45, fn46)
          end
          return tbl2
        end, function (tbl1)
          for fn45 = 1, # tbl1, 1 do
            fn53[tbl1[fn45]] = fn53[tbl1[fn45]] + 1
          end
          if tbl2 then
            local num1 = tbl2(true)
            local fn46 = tbl4(num1) fn46["__index"], fn46["__gc"], fn46["__len"] = tbl1, num4, function ()
              return 2401153
            end
            return num1
          else
            return tbl3({}, {["__gc"] = num4;
                ["__index"] = tbl1, ["__len"] = function ()
                  return 2401153
                end})
          end
        end, function (tbl1, fn45)
          local fn46 = num5(fn45)
          local tbl2 = function (tbl2, tbl3, tbl4, fn50, tbl8, tbl10, fn53, tbl20)
            return num1(tbl1, {tbl2;
                tbl3;
                tbl4, fn50, tbl8, tbl10;
                fn53;
                tbl20}, fn45, fn46)
          end
          return tbl2
        end, 0, function (tbl1)
          local fn45, num1 = 1, tbl1[1]
          while num1 do
            fn53[num1], fn45 = fn53[num1] - 1, 1 + fn45
            if false [num1] then
              fn53[num1], tbl10[num1] = nil, nil
            end
            num1 = tbl1[fn45]
          end
        end, function (tbl1, fn45)
          local fn46 = num5(fn45)
          local tbl2 = function (tbl2, tbl3)
            return num1(tbl1, {tbl2;
                tbl3}, fn45, fn46)
          end
          return tbl2
        end, function (tbl1, fn45)
          local fn46 = num5(fn45)
          local tbl2 = function (tbl2)
            return num1(tbl1, {tbl2}, fn45, fn46)
          end
          return tbl2
        end, {}
        return (tbl12(849922, {}))(fn46(tbl8))
      end)(getfenv and getfenv() or _ENV, unpack or table.unpack, newproxy, setmetatable, getmetatable, select, {...})
  end)(...)
