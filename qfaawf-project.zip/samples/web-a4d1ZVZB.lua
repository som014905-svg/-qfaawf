Zakater Hub:
loadstring(game:HttpGet("https://raw.githubusercontent.com/zakater5/LuaRepo/main/YBA/v3.lua"))()

Xenon Hub:
loadstring(game:HttpGet("https://raw.githubusercontent.com/SnaxScripts/Scripts/main/yba%20xenon"))()

Kolgie V6 Hub:
loadstring(game:HttpGet("https://raw.githubusercontent.com/kolgie/YBA-GUI/main/yba-gui-obfuscated.lua"))()

YCY Hub:
loadstring(game:HttpGet"https://raw.githubusercontent.com/NukeVsCity/hackscript123/main/gui")()

Nuke City Hub:
loadstring(game:HttpGet("https://raw.githubusercontent.com/NukeVsCity/Scripts2024/main/ybaredguiforpc"))()

Yaki Hub:
loadstring(game:HttpGet("https://raw.githubusercontent.com/Yaki-0/Yaki-s-Hub/main/AUT.lua", true))()

YSA Hub:
loadstring(game:HttpGet("https://raw.githubusercontent.com/Tobias020108Back/YBA-AUT/main/YBA-GUI-Rewrite.lua"))()

Tobias Hub:
loadstring(game:HttpGet("https://raw.githubusercontent.com/Tobias020108Back/YBA-AUT/main/Yba/All/In/One/NonAutoExec"))()